"""Synthetic Delphi (Streamlit).

This UI wraps the `synthetic_delphi` package and focuses on:
- Clear mapping between panel modes and participant configuration
- Explicit response length/structure policies (separate from token limits)
- Comprehensive model selection (including OpenAI) with optional live model list fetch
- Run monitoring and an auditable trail of prompts/responses
- Save/load of full study settings (including optional API keys)

Run:
  streamlit run app.py
"""

from __future__ import annotations

import json
import base64
import os
import copy
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
import requests
import streamlit as st
import streamlit.components.v1 as components

from synthetic_delphi import DelphiStudyRunner, SQLiteStore, OpenAICompatibleProvider, MockProvider
from synthetic_delphi.schemas import AgentProfile, DelphiConfig, MasterAgentConfig, RunOptions, StudyRunSpec


APP_DIR = Path(__file__).resolve().parent
COHORT_DIR = APP_DIR / "cohorts"
COHORT_DIR.mkdir(parents=True, exist_ok=True)


def _safe_slug(text: str, *, fallback: str = "project") -> str:
    """Create a filesystem-safe slug for filenames (Windows-friendly)."""
    t = (text or "").strip()
    if not t:
        return fallback
    out: list[str] = []
    for ch in t:
        if ch.isalnum():
            out.append(ch.lower())
        elif ch in (" ", "-", "_", "."):
            out.append("-")
        # drop other punctuation/symbols
    s = "".join(out)
    while "--" in s:
        s = s.replace("--", "-")
    s = s.strip("-.")
    return s or fallback


# -------------------------
# Defaults
# -------------------------

DEFAULT_OPENAI_MODEL_CHOICES = [
    # Reasoning/frontier
    "gpt-5.2",
    "gpt-5.2-pro",
    "gpt-5.1",
    "gpt-5",
    "gpt-5-mini",
    "gpt-5-nano",
    # General multimodal
    "gpt-4.1",
    "gpt-4.1-mini",
    "gpt-4.1-nano",
    "gpt-4o",
    "gpt-4o-mini",
    # Reasoning family (legacy/alt)
    "o3",
    "o3-pro",
    "o4-mini",
    "o1",
    "o1-pro",
]

REASONING_EFFORT_CHOICES = [None, "minimal", "low", "medium", "high", "xhigh"]
VERBOSITY_CHOICES = ["low", "medium", "high"]


# -------------------------
# Helpers
# -------------------------


def _read_version() -> str:
    """Best-effort version reader.

    Avoids crashing the app on Windows when the VERSION file cannot be read due to
    OS permissions/locking (e.g., Microsoft Store Python sandboxing).
    """
    p = APP_DIR / "VERSION.txt"
    try:
        if p.exists() and p.is_file():
            # Some environments can raise PermissionError on read; fail open.
            return p.read_text(encoding="utf-8", errors="ignore").strip()
    except (PermissionError, OSError):
        pass

    # Fallback to package metadata if available
    try:
        import importlib.metadata as _im
        return _im.version("synthetic_delphi")
    except Exception:
        return "unknown"


APP_VERSION = _read_version()


def _now_stamp() -> str:
    # Python 3.12+ deprecates datetime.utcnow(); use timezone-aware UTC.
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _cohort_files() -> List[Path]:
    return sorted(COHORT_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)


def _fetch_model_ids(base_url: str, api_key: str) -> Tuple[Optional[List[str]], Optional[str]]:
    """Fetch /v1/models from an OpenAI-compatible endpoint."""
    try:
        url = base_url.rstrip("/") + "/v1/models"
        headers = {"Authorization": f"Bearer {api_key}"}
        r = requests.get(url, headers=headers, timeout=20)
        if r.status_code >= 400:
            return None, f"HTTP {r.status_code}: {r.text[:200]}"
        payload = r.json()
        data = payload.get("data", [])
        ids = []
        for x in data:
            mid = x.get("id")
            if isinstance(mid, str) and mid.strip():
                ids.append(mid.strip())
        ids = sorted(set(ids))
        return ids, None
    except Exception as e:
        return None, str(e)


def _ensure_state() -> None:
    if "agents" not in st.session_state:
        st.session_state.agents = [
            {
                "agent_id": "P1",
                "name": "Participant 1",
                "provider": "openai_compat",
                "base_url": "https://api.openai.com",
                "api_key": "",
                "model": "gpt-4o",
                "system_prompt": "You are a careful expert panelist. Provide clear, justified responses.",
                "temperature": 0.2,
                "max_tokens": 1200,
                "reasoning_effort": None,
                "verbosity": "medium",
                # Panel-mode fields
                "discipline": "",
                "persona_name": "",
                "persona_description": "",
            },
            {
                "agent_id": "P2",
                "name": "Participant 2",
                "provider": "openai_compat",
                "base_url": "https://api.openai.com",
                "api_key": "",
                "model": "gpt-4o",
                "system_prompt": "You are a careful expert panelist. Provide clear, justified responses.",
                "temperature": 0.2,
                "max_tokens": 1200,
                "reasoning_effort": None,
                "verbosity": "medium",
                "discipline": "",
                "persona_name": "",
                "persona_description": "",
            },
            {
                "agent_id": "P3",
                "name": "Participant 3",
                "provider": "openai_compat",
                "base_url": "https://api.openai.com",
                "api_key": "",
                "model": "gpt-4o",
                "system_prompt": "You are a careful expert panelist. Provide clear, justified responses.",
                "temperature": 0.2,
                "max_tokens": 1200,
                "reasoning_effort": None,
                "verbosity": "medium",
                "discipline": "",
                "persona_name": "",
                "persona_description": "",
            },
        ]

    if "master" not in st.session_state:
        st.session_state.master = {
            "provider": "openai_compat",
            "base_url": "https://api.openai.com",
            "api_key": "",
            "model": "gpt-4o",
            "system_prompt": "You are the Delphi facilitator. Be neutral, structured, and faithful to participant inputs.",
            "temperature": 0.1,
            "max_tokens": 1800,
            "reasoning_effort": None,
            "verbosity": "medium",
        }

    if "global_provider" not in st.session_state:
        # Optional convenience: set shared provider credentials once and reuse for participants.
        st.session_state.global_provider = {
            "provider": "openai_compat",
            "base_url": "https://api.openai.com",
            "api_key": "",
            # Optional shared model defaults (can be applied to participants via toggles in the UI)
            "model": "gpt-4o",
            "temperature": 0.2,
            "max_tokens": 1200,
            "reasoning_effort": None,
            "verbosity": "medium",
            "use_key_for_participants": True,
            "use_key_for_master": False,
            "apply_model_defaults_to_participants": False,
            "force_override_participant_keys": False,
        }

    if "config" not in st.session_state:
        # Note: these are parsed by DelphiConfig; we keep dicts in session_state.
        st.session_state.config = {
            "template": "item_rating",
            "max_rounds": 3,
            "min_rounds": 2,
            "quorum_fraction": 0.7,
            "stage_deadline_s": 240,
            "retries": 1,
            "consensus_iqr_threshold": 1.0,
            "stability_median_threshold": 0.5,
            "questionnaire_followup": True,
            "iconic_minds_scope_guardrails": True,
            "forecast_weight_by_confidence": True,
            "forecast_beta_pooling": True,
            "forecast_beta_draws": 20000,
            "priority_top_k": 10,
            # response length
            "response_length_mode": "guided",
            "participant_policy": {
                "overall": {"min_words": 120, "target_words": 200, "max_words": 260, "strict": False},
                "field_policies": {},
            },
            "master_policy": {
                "overall": {"min_words": 1200, "target_words": 2500, "max_words": 3000, "strict": False},
                "field_policies": {},
            },
            "stage_policies_participant": {},
            "stage_policies_master": {},
            "generate_word_report": True,
            # Optional naming
            "report_title": "Synthetic Delphi — Consultancy Report",
            # panel mode
            "ai_delphi_model": "digital_oracle",
        }

    if "spec" not in st.session_state:
        st.session_state.spec = {
            "project_name": "",
            "topic": "AI governance in public services",
            "problem_statement": "Define a robust, implementable AI governance programme for a mid-sized public agency.",
            "research_question": "What governance mechanisms and practices are most effective and feasible?",
            "study_goal": "Generate, rate, and refine governance recommendations with consensus and stability.",
            "template": "item_rating",
            "n_seed_items": 0,
            "seed_items": [],
            "rating_dimensions": [
                {"name": "Importance", "description": "How important is this item to achieving the study goal?"},
                {"name": "Feasibility", "description": "How feasible is implementation within 12 months?"},
            ],
            "master_instructions": "",
            "include_final_synthesis": True,
            # template-specific
            "questionnaire": [],
            "forecast_questions": [],
            "scenario_time_horizon": "5 years",
            "n_scenarios": 4,
        }

    if "db_path" not in st.session_state:
        st.session_state.db_path = str(APP_DIR / "study_db.sqlite3")

    if "model_cache" not in st.session_state:
        st.session_state.model_cache = {}  # (provider, base_url) -> [model ids]

    if "run_log" not in st.session_state:
        st.session_state.run_log = []

    if "last_run_id" not in st.session_state:
        st.session_state.last_run_id = None


def _export_settings(include_api_keys: bool) -> Dict[str, Any]:
    # IMPORTANT: deep-copy session state so scrubbing secrets does not mutate the live UI.
    data = {
        "app_version": APP_VERSION,
        "saved_at": _now_stamp(),
        "agents": copy.deepcopy(st.session_state.agents),
        "master": copy.deepcopy(st.session_state.master),
        "config": copy.deepcopy(st.session_state.config),
        "spec": copy.deepcopy(st.session_state.spec),
        "db_path": str(st.session_state.db_path),
        "global_provider": copy.deepcopy(st.session_state.get("global_provider", {}) or {}),
    }
    if not include_api_keys:
        for a in data.get("agents", []):
            if isinstance(a, dict):
                a["api_key"] = ""
        if isinstance(data.get("master"), dict):
            data["master"]["api_key"] = ""
        if isinstance(data.get("global_provider"), dict):
            data["global_provider"]["api_key"] = ""
    return data


def _prime_widget_state_from_loaded_settings() -> None:
    """Ensure Streamlit widgets reflect loaded cohort values.

    Streamlit widgets prefer existing st.session_state[key] values over the provided
    `value=` defaults. When loading a cohort, we therefore prime the widget keys used
    throughout the app so the UI reflects what was loaded (including API keys when saved).
    """
    # Global provider widgets
    gp = st.session_state.get("global_provider", {}) or {}
    st.session_state["gp_provider"] = gp.get("provider", "openai_compat")
    st.session_state["gp_base"] = gp.get("base_url", "https://api.openai.com")
    st.session_state["gp_key"] = gp.get("api_key", "")
    st.session_state["gp_use_part"] = bool(gp.get("use_key_for_participants", True))
    st.session_state["gp_force"] = bool(gp.get("force_override_participant_keys", False))
    st.session_state["gp_use_master"] = bool(gp.get("use_key_for_master", False))
    st.session_state["gp_apply_model"] = bool(gp.get("apply_model_defaults_to_participants", False))
    st.session_state["gp_temp"] = float(gp.get("temperature", 0.2))
    st.session_state["gp_mt"] = int(gp.get("max_tokens", 1200))
    st.session_state["gp_re"] = gp.get("reasoning_effort", None)
    st.session_state["gp_vb"] = gp.get("verbosity", "medium")

    g_model = gp.get("model", "gpt-4o")
    if g_model in DEFAULT_OPENAI_MODEL_CHOICES:
        st.session_state["gp_model"] = g_model
    else:
        st.session_state["gp_model"] = "(custom)"
        st.session_state["gp_model_custom"] = g_model

    # Master widgets
    m = st.session_state.get("master", {}) or {}
    st.session_state["master_prov"] = m.get("provider", "openai_compat")
    st.session_state["master_base"] = m.get("base_url", "https://api.openai.com")
    st.session_state["master_key"] = m.get("api_key", "")
    st.session_state["master_model"] = m.get("model", "gpt-4o")
    st.session_state["master_temp"] = float(m.get("temperature", 0.2))
    st.session_state["master_mtok"] = int(m.get("max_tokens", 1200))
    st.session_state["master_re"] = m.get("reasoning_effort", None)
    st.session_state["master_vb"] = m.get("verbosity", "medium")

    # Project naming widgets
    try:
        sp = st.session_state.get("spec", {}) or {}
        cf = st.session_state.get("config", {}) or {}
        st.session_state["project_name_in"] = (sp.get("project_name") or "")
        st.session_state["report_title_in"] = (cf.get("report_title") or "Synthetic Delphi — Consultancy Report")
    except Exception:
        pass
    # Participants widgets
    agents = st.session_state.get("agents", []) or []
    for idx, a in enumerate(agents):
        if not isinstance(a, dict):
            continue
        st.session_state[f"aid_{idx}"] = a.get("agent_id", f"P{idx+1}")
        st.session_state[f"aname_{idx}"] = a.get("name", f"Participant {idx+1}")
        st.session_state[f"disc_{idx}"] = a.get("discipline", "")
        st.session_state[f"pname_{idx}"] = a.get("persona_name", "")
        st.session_state[f"pdesc_{idx}"] = a.get("persona_description", "")
        st.session_state[f"sys_{idx}"] = a.get("system_prompt", "")
        st.session_state[f"agent_{idx}_prov"] = a.get("provider", "openai_compat")
        st.session_state[f"agent_{idx}_base"] = a.get("base_url", "https://api.openai.com")
        st.session_state[f"agent_{idx}_key"] = a.get("api_key", "")
        a_model = a.get("model", "gpt-4o")
        # Let the widget decide custom vs. built-in; just set the current string.
        st.session_state[f"agent_{idx}_model"] = a_model
        st.session_state[f"agent_{idx}_temp"] = float(a.get("temperature", 0.2))
        st.session_state[f"agent_{idx}_mtok"] = int(a.get("max_tokens", 1200))
        st.session_state[f"agent_{idx}_re"] = a.get("reasoning_effort", None)
        st.session_state[f"agent_{idx}_vb"] = a.get("verbosity", "medium")


def _import_settings(data: Dict[str, Any]) -> None:
    # Be forgiving: only overwrite what exists.
    if isinstance(data.get("agents"), list):
        agents_in = copy.deepcopy(data["agents"])
        if len(agents_in) > 30:
            st.session_state._import_notice = f"Loaded cohort has {len(agents_in)} participants; truncated to 30."
            agents_in = agents_in[:30]
        st.session_state.agents = agents_in
    if isinstance(data.get("master"), dict):
        st.session_state.master = copy.deepcopy(data["master"])
    if isinstance(data.get("config"), dict):
        st.session_state.config = copy.deepcopy(data["config"])
    if isinstance(data.get("spec"), dict):
        st.session_state.spec = copy.deepcopy(data["spec"])
        # Back-compat: older cohorts used "questionnaire_items".
        if isinstance(st.session_state.spec, dict):
            if (not st.session_state.spec.get("questionnaire")) and st.session_state.spec.get("questionnaire_items"):
                st.session_state.spec["questionnaire"] = list(st.session_state.spec.get("questionnaire_items") or [])
    if isinstance(data.get("db_path"), str) and data["db_path"].strip():
        st.session_state.db_path = data["db_path"].strip()
    if isinstance(data.get("global_provider"), dict):
        st.session_state.global_provider = copy.deepcopy(data["global_provider"])

    _prime_widget_state_from_loaded_settings()


def _build_objects() -> Tuple[List[AgentProfile], MasterAgentConfig, DelphiConfig, StudyRunSpec]:
    """Build Pydantic objects from UI state.

    Applies global provider defaults if configured:
    - If a participant api_key is blank and a global api_key is present, the global key is used.
    - Optional: apply global model defaults to participants.
    """
    gp: Dict[str, Any] = st.session_state.get("global_provider", {}) or {}
    g_key = (gp.get("api_key") or "").strip()
    force_keys = bool(gp.get("force_override_participant_keys", False))
    use_key_for_participants = bool(gp.get("use_key_for_participants", True))
    use_key_for_master = bool(gp.get("use_key_for_master", False))
    apply_model_defaults = bool(gp.get("apply_model_defaults_to_participants", False))

    agents_dicts: List[Dict[str, Any]] = []
    for a in st.session_state.agents:
        ad = dict(a)
        # Global key fallback/override
        if g_key and use_key_for_participants:
            if force_keys or not (ad.get("api_key") or "").strip():
                ad["api_key"] = g_key
        # Optional shared model defaults
        if apply_model_defaults:
            for k in ["provider", "base_url", "model", "temperature", "max_tokens", "reasoning_effort", "verbosity"]:
                gv = gp.get(k, None)
                if gv is not None and gv != "":
                    ad[k] = gv
        # Always fall back to global base_url/provider if agent left them blank
        if (not (ad.get("base_url") or "").strip()) and (gp.get("base_url") or "").strip():
            ad["base_url"] = gp["base_url"]
        if (not (ad.get("provider") or "").strip()) and (gp.get("provider") or "").strip():
            ad["provider"] = gp["provider"]
        agents_dicts.append(ad)

    master_dict = dict(st.session_state.master)
    if g_key and use_key_for_master and not (master_dict.get("api_key") or "").strip():
        master_dict["api_key"] = g_key
    # Keep master model independent by default.
    if (not (master_dict.get("base_url") or "").strip()) and (gp.get("base_url") or "").strip():
        master_dict["base_url"] = gp["base_url"]
    if (not (master_dict.get("provider") or "").strip()) and (gp.get("provider") or "").strip():
        master_dict["provider"] = gp["provider"]

    agents = [AgentProfile(**a) for a in agents_dicts]
    master = MasterAgentConfig(**master_dict)
    config = DelphiConfig(**st.session_state.config)

    # Back-compat: older UI used "questionnaire_items".
    spec_dict = dict(st.session_state.spec or {})
    if (not spec_dict.get("questionnaire")) and spec_dict.get("questionnaire_items"):
        spec_dict["questionnaire"] = list(spec_dict.get("questionnaire_items") or [])

    spec = StudyRunSpec(**spec_dict)
    return agents, master, config, spec



def _policy_editor(policy_dict: Dict[str, Any], *, key_prefix: str) -> Dict[str, Any]:
    """Edit a ResponsePolicy stored as dict."""
    overall = policy_dict.get("overall", {}) or {}
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        min_words = st.number_input("Min words", min_value=0, max_value=5000, value=int(overall.get("min_words", 0)), key=f"{key_prefix}_min")
    with col2:
        target_words = st.number_input("Target words", min_value=0, max_value=5000, value=int(overall.get("target_words", 0)), key=f"{key_prefix}_tgt")
    with col3:
        max_words = st.number_input("Max words", min_value=0, max_value=5000, value=int(overall.get("max_words", 0)), key=f"{key_prefix}_max")
    with col4:
        strict = st.checkbox("Strict enforcement", value=bool(overall.get("strict", False)), key=f"{key_prefix}_strict")

    # Normalize
    if max_words and target_words > max_words:
        target_words = max_words
    if min_words and target_words < min_words:
        target_words = min_words
    if max_words and min_words > max_words:
        min_words = max_words

    policy_dict["overall"] = {"min_words": int(min_words), "target_words": int(target_words), "max_words": int(max_words), "strict": bool(strict)}

    st.caption("Optional: per-field word targets (applies to structured JSON fields such as 'justification' or 'overall_comment').")
    fp = policy_dict.get("field_policies", {}) or {}
    rows = []
    for field, spec in fp.items():
        rows.append(
            {
                "field": field,
                "min_words": int(spec.get("min_words", 0)),
                "target_words": int(spec.get("target_words", 0)),
                "max_words": int(spec.get("max_words", 0)),
                "strict": bool(spec.get("strict", False)),
            }
        )
    df = pd.DataFrame(rows)
    if df.empty:
        df = pd.DataFrame([{"field": "", "min_words": 0, "target_words": 0, "max_words": 0, "strict": False}])

    edited = st.data_editor(
        df,
        num_rows="dynamic",
        width="stretch",
        key=f"{key_prefix}_fp",
        column_config={
            "field": st.column_config.TextColumn("Field"),
            "min_words": st.column_config.NumberColumn("Min", min_value=0, max_value=5000, step=5),
            "target_words": st.column_config.NumberColumn("Target", min_value=0, max_value=5000, step=5),
            "max_words": st.column_config.NumberColumn("Max", min_value=0, max_value=5000, step=5),
            "strict": st.column_config.CheckboxColumn("Strict"),
        },
    )

    fp_out: Dict[str, Any] = {}
    for _, r in edited.iterrows():
        field = str(r.get("field", "")).strip()
        if not field:
            continue
        fp_out[field] = {
            "min_words": int(r.get("min_words", 0) or 0),
            "target_words": int(r.get("target_words", 0) or 0),
            "max_words": int(r.get("max_words", 0) or 0),
            "strict": bool(r.get("strict", False)),
        }
    policy_dict["field_policies"] = fp_out
    return policy_dict



def _stage_key_catalog(template: str) -> List[Tuple[str, str]]:
    """
    Stage keys exposed for per-stage override controls.

    Important: these stage keys MUST match the internal stage_key values used in synthetic_delphi/pipeline.py.
    If they diverge, per-stage overrides (word-count policies, structure policies, etc.) will not apply.

    Note: report_polish is the post-synthesis step that generates the proofread Word report (.docx).
    """
    stages: List[Tuple[str, str]] = []

    if template == "item_rating":
        stages = [
            ("item_elicitation", "Round 1 — Item elicitation (participants)"),
            ("item_rating_round", "Round 2+ — Item rating (participants)"),
            ("controlled_feedback", "Between rounds — Controlled feedback (master)"),
            ("final_synthesis", "Final — Synthesis (master)"),
        ]

    elif template == "questionnaire_ai_delphi":
        stages = [
            ("questionnaire_round", "Per round — Questionnaire response (participants)"),
            ("controlled_feedback", "Between rounds — Controlled feedback (master)"),
            ("final_synthesis", "Final — Synthesis (master)"),
        ]

    elif template == "recursive_reasoning":
        stages = [
            ("recursive_understanding_round", "Round 1 — Understanding + reasoning (participants; no solutions)"),
            ("recursive_understanding_digest", "Between rounds — Pooled understanding digest (master)"),
            ("recursive_solution_round", "Round 2 — Proposed solution + reasoning (participants)"),
            ("recursive_solution_digest", "Between rounds — Pooled proposed solutions digest (master)"),
            ("recursive_final_round", "Round 3 — Final solution + final reasoning (participants)"),
            ("final_synthesis", "Final — Synthesis (master)"),
        ]

    elif template == "forecasting":
        stages = [
            ("forecast_round", "Per round — Forecast response (participants)"),
            ("forecast_feedback", "Between rounds — Controlled feedback (master)"),
        ]

    elif template == "priority_ranking":
        stages = [
            ("priority_round", "Per round — Ranking response (participants)"),
            ("priority_feedback", "Between rounds — Controlled feedback (master)"),
        ]

    elif template == "sensemaking":
        stages = [
            ("sensemaking_round1", "Round 1 — Sensemaking (participants)"),
            ("sensemaking_consolidation", "Between rounds — Consolidate sensemaking (master)"),
            ("sensemaking_validation", "Round 2 — Validation / refinement (participants)"),
            ("sensemaking_synthesis", "Final — Sensemaking synthesis (master)"),
        ]

    elif template == "idea_generation":
        stages = [
            ("idea_elicitation", "Round 1 — Idea elicitation (participants)"),
            ("idea_consolidation", "Between rounds — Consolidate and cluster ideas (master)"),
        ]

    elif template == "criteria_standards":
        stages = [
            ("criteria_elicitation", "Round 1 — Criteria elicitation (participants; if no seed statements)"),
            ("criteria_consolidation", "Between rounds — Consolidate criteria (master)"),
            ("criteria_rating", "Round 2 — Criteria rating (participants)"),
        ]

    elif template == "policy_guidelines":
        stages = [
            ("guidelines_elicitation", "Round 1 — Guideline elicitation (participants; if no seed statements)"),
            ("guidelines_consolidation", "Between rounds — Consolidate guidelines (master)"),
            ("guidelines_rating", "Round 2 — Guideline rating (participants)"),
        ]

    elif template == "risk_register":
        stages = [
            ("risk_elicitation", "Round 1 — Risk elicitation (participants)"),
            ("risk_consolidation", "Between rounds — Consolidate risks (master)"),
            ("risk_rating", "Round 2 — Risk rating (participants)"),
        ]

    elif template == "instrument_development":
        stages = [
            ("instrument_elicitation", "Round 1 — Item elicitation (participants)"),
            ("instrument_consolidation", "Between rounds — Consolidate instrument (master)"),
            ("instrument_rating", "Round 2 — Item rating (participants)"),
        ]

    elif template == "scenario_building":
        stages = [
            ("scenario_drivers", "Round 1 — Drivers and uncertainties (participants)"),
            ("scenario_generation", "Between rounds — Generate scenarios (master)"),
            ("scenario_review", "Round 2 — Scenario review (participants)"),
        ]

    if stages:
        stages.append(("report_polish", "Post-synthesis — Finalize Word report (.docx) (master)"))

    return stages




TEMPLATE_EXPLAINERS: Dict[str, str] = {
    "item_rating": "Use this to elicit candidate items (Round 1), consolidate them, then iterate rating rounds until consensus/stability. Output includes item statistics and a ranked short-list.",
    "questionnaire_ai_delphi": "Use this to ask a fixed set of questions across rounds. The master can generate controlled feedback and optional follow-up prompts to probe disagreement.",
    "recursive_reasoning": (
        "Use this when you want the panel to recursively converge on a solution. "
        "Round 1 pools how panelists understand the problem/question(s) and their reasoning only (no solutions). "
        "Round 2 proposes solutions with reasoning. Round 3 finalises a solution with final reasoning. "
        "The master then synthesises agreements/disagreements and convergences/divergences."
    ),
    "forecasting": "Use this to elicit probabilistic forecasts (and confidence) for binary questions, then aggregate and iterate with feedback.",
    "priority_ranking": "Use this when the goal is ordering: participants rank items; the system aggregates (e.g., Borda) and can iterate to improve agreement.",
    "sensemaking": "Use this for structured scoping: participants propose glossary terms, assumptions, boundaries, and uncertainties; the master consolidates a shared scope map.",
    "idea_generation": "Use this for divergent exploration: participants generate ideas; the master consolidates themes and duplicates.",
    "criteria_standards": "Use this to generate and refine evaluation criteria / standards, optionally with rating rounds on acceptability/feasibility.",
    "scenario_building": "Use this to co-produce scenarios over a time horizon: key drivers, uncertainties, and internally consistent scenario narratives.",
    "policy_guidelines": "Use this to draft policy/guideline statements, consolidate, and optionally rate them for acceptability and feasibility.",
    "risk_register": "Use this to build a risk register: risks, causes, impacts, mitigations, owners, and residual risk ratings.",
    "instrument_development": "Use this to draft and refine a research instrument (items, constructs, response formats) with panel critique and revision rounds.",
}


def _template_explainer(template_id: str) -> str:
    return TEMPLATE_EXPLAINERS.get(template_id, "")

def _panel_mode_explainer(mode: str) -> str:
    if mode == "digital_oracle":
        return (
            "Digital Oracle treats each participant as a generic expert panelist. "
            "Only each participant's system prompt (and general study instructions) shape their behaviour. "
            "Use this when you want disciplinary neutrality or when you are simulating an anonymous expert panel."
        )
    if mode == "persona_panel":
        return (
            "Persona Panel makes each participant behave like a role-based persona (e.g., a clinician, regulator, CIO). "
            "The UI fields 'Discipline/Role' and 'Persona description' are injected into the system prompt in addition to any "
            "participant system prompt you provide."
        )
    if mode == "iconic_minds":
        return (
            "Iconic Minds makes each participant imitate a specific named thinker or practitioner. "
            "The fields 'Persona name' and 'Persona description' are injected into the system prompt. "
            "Scope guardrails (toggle in Study design) constrain the persona to domain-relevant outputs and reduce hallucinated biographical claims."
        )
    return ""


def _glossary_block() -> None:
    with st.expander("Glossary: key technical terms", expanded=False):
        st.markdown(
            """
- **Max tokens**: an API cap on the number of tokens the model may emit. It does *not* prescribe a desired answer length.
- **Response length mode**:
  - *tokens_only*: only max_tokens applies; no word-count guidance or enforcement.
  - *guided*: the pipeline appends word-count guidance to prompts; no hard enforcement.
  - *strict*: the pipeline enforces word-count constraints via automatic reprompting when outputs are too short/long.
- **Quorum fraction**: the minimum fraction of active participants that must return valid outputs for a stage to be considered successful.
  - Example: with 10 participants and a quorum fraction of 0.7, at least 7 valid responses are required.
- **Consensus IQR threshold** (item-rating): consensus is met when the **interquartile range (IQR)** of ratings for each item/dimension is at or below this threshold.
- **Stability median threshold** (item-rating): stability is met when the absolute change in **median** rating between rounds is at or below this threshold for all shared items/dimensions.
- **Reasoning effort / thinking mode**: a model-side compute budget (when supported) that may improve deliberation quality. This is separate from response structuring/word-count policies.
"""
        )



def _inject_branding() -> None:
    """Apply lightweight UX styling and branded header."""
    st.markdown(
        """
<style>
/* Layout */
.block-container { padding-top: 2.2rem; padding-bottom: 2.5rem; max-width: 1200px; }
[data-testid="stSidebar"] .block-container { padding-top: 1.25rem; }

/* Header */
.sd-hero {
  border: 1px solid rgba(49, 51, 63, 0.12);
  border-radius: 16px;
  padding: 18px 18px 14px 18px;
  margin: 0 0 16px 0;
  background: rgba(255, 255, 255, 0.65);
}
.sd-title { font-size: 30px; font-weight: 700; margin: 0; }
.sd-sub { font-size: 14px; opacity: 0.85; margin-top: 6px; line-height: 1.35; }
.sd-meta { font-size: 12px; opacity: 0.75; margin-top: 10px; }

/* Controls */
[data-testid="stExpander"] { border-radius: 12px; }
.stButton>button { border-radius: 10px; }

/* Tables */
[data-testid="stDataFrame"] { border-radius: 12px; overflow: hidden; }
</style>
        """,
        unsafe_allow_html=True,
    )

    st.markdown(
        """
<div class="sd-hero">
  <div class="sd-title">Synthetic Delphi</div>
  <div class="sd-sub">
    A professional, auditable pipeline for running Delphi-style studies with synthetic panels across multiple frontier models.
  </div>
  <div class="sd-meta">Created by Shane McLoughlin</div>
</div>
        """,
        unsafe_allow_html=True,
    )

    # Best-effort: open in a new browser window once (may be blocked by pop-up settings).
    try:
        qp = dict(st.query_params) if hasattr(st, "query_params") else {}
        if not qp.get("window"):
            components.html(
                """
<script>
(function(){
  try {
    var u = new URL(window.location.href);
    if(!u.searchParams.get('window')){
      u.searchParams.set('window','1');
      window.open(u.toString(), 'SyntheticDelphi', 'noopener,noreferrer');
    }
  } catch(e) {}
})();
</script>
                """,
                height=0,
            )
    except Exception:
        pass


def _rtf_escape(s: str) -> str:
    """
    Escape text for RTF and emit ASCII-only output.

    Word will often assume Windows-1252 for \\ansi RTF. If we write UTF-8 bytes
    directly, “smart quotes” can appear as mojibake (e.g., â€œ ... â€).
    To avoid this, we emit non-ASCII characters using RTF \\uN? escapes.
    """
    s = (s or "")
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    out: list[str] = []
    for ch in s:
        if ch == "\\":  # backslash
            out.append(r"\\")
            continue
        if ch == "{":
            out.append(r"\{")
            continue
        if ch == "}":
            out.append(r"\}")
            continue
        if ch == "\n":
            out.append("\n")
            continue

        code = ord(ch)
        if 32 <= code < 127:
            out.append(ch)
            continue

        # RTF \u expects a signed 16-bit integer. For codepoints beyond BMP,
        # emit surrogate pairs.
        if code > 0xFFFF:
            cp = code - 0x10000
            hi = 0xD800 + (cp >> 10)
            lo = 0xDC00 + (cp & 0x3FF)
            for u in (hi, lo):
                signed = u if u <= 32767 else (u - 65536)
                out.append(f"\\u{signed}?")
        else:
            signed = code if code <= 32767 else (code - 65536)
            out.append(f"\\u{signed}?")
    return "".join(out)


def _to_rtf_paragraphs(text: str) -> str:
    esc = _rtf_escape(text)
    # Convert line breaks to paragraph breaks.
    return esc.replace("\n", r"\par ")


def _build_consultancy_rtf(run_id: str, store: SQLiteStore) -> bytes:
    """Create a consultancy-style RTF report for a given run (Word-friendly).

    The report is generated as ASCII-only RTF with \\uN? escapes for non-ASCII so that
    Microsoft Word opens it cleanly on Windows without mojibake.
    """
    rec = store.get_study_record(run_id) or {}
    spec = (rec.get("spec") or {})
    cfg = (rec.get("config") or {})
    agents = rec.get("agents") or []
    master = rec.get("master") or {}

    created_at = rec.get("created_at") or _now_stamp()
    project_name = (spec.get("project_name") or "").strip()
    report_title = (cfg.get("report_title") or "Synthetic Delphi — Consultancy Report").strip()
    title = (spec.get("title") or "Synthetic Delphi Study").strip()
    topic = (spec.get("topic") or "").strip()
    problem = (spec.get("problem_statement") or "").strip()

    template = (cfg.get("template") or "").strip()
    mode = (cfg.get("ai_delphi_model") or "").strip()
    quorum_fraction = cfg.get("quorum_fraction")
    max_rounds = cfg.get("max_rounds")
    min_rounds = cfg.get("min_rounds")

    final = store.get_artifact(run_id, "final_result") or {}
    rounds_completed = final.get("rounds_completed")
    quorum_reached = final.get("quorum_reached")

    # -------------------------
    # Findings extraction
    # -------------------------
    findings_lines: list[str] = []
    if template == "questionnaire_ai_delphi":
        qres = store.get_artifact(run_id, "questionnaire_results") or {}
        fr = qres.get("final_report") or {}
        overall = str(fr.get("overall_synthesis", "")).strip()
        if overall:
            findings_lines.append("Overall synthesis:")
            findings_lines.append(overall)
            findings_lines.append("")
        per_q = fr.get("per_question") or []
        if isinstance(per_q, list) and per_q:
            findings_lines.append("Per-question synthesis:")
            qq = qres.get("questionnaire") or []
            for q in per_q:
                qi = q.get("question_index")
                try:
                    qi_int = int(qi)
                except Exception:
                    qi_int = None
                qtxt = ""
                if qi_int and 1 <= qi_int <= len(qq):
                    qtxt = str(qq[qi_int - 1]).strip()
                consensus = str(q.get("consensus", "")).strip()
                disagreements = str(q.get("disagreements", "")).strip()
                implications = str(q.get("implications", "")).strip()
                findings_lines.append("")
                findings_lines.append(f"Q{qi_int}: {qtxt}" if qi_int else "Question:")
                if consensus:
                    findings_lines.append(f"- Consensus: {consensus}")
                if disagreements:
                    findings_lines.append(f"- Key disagreements: {disagreements}")
                if implications:
                    findings_lines.append(f"- Implications: {implications}")
    elif template == "priority_ranking":
        pres = store.get_artifact(run_id, "priority_results") or {}
        items = pres.get("items") or []
        topk = pres.get("final_top_k") or []
        W = pres.get("final_kendalls_w")
        if topk and items:
            findings_lines.append("Final priority list (top-k):")
            for i, idx in enumerate(topk, start=1):
                try:
                    item_txt = str(items[int(idx) - 1]).strip()
                except Exception:
                    item_txt = str(idx)
                findings_lines.append(f"{i}. {item_txt}")
            findings_lines.append("")
        if W is not None:
            findings_lines.append(f"Agreement (Kendall's W): {W}")
    elif template == "forecasting":
        fres = store.get_artifact(run_id, "forecasting_results") or {}
        md = str(fres.get("final_table_md", "")).strip()
        if md:
            findings_lines.append("Final aggregated forecasts (table):")
            findings_lines.append(md)
    elif template == "recursive_reasoning":
        rr = store.get_artifact(run_id, "recursive_reasoning_results") or {}
        fr = rr.get("final_report") or {}
        summary = str(fr.get("summary", "")).strip()
        answer = str(fr.get("recommended_answer", "")).strip()
        agreements = fr.get("agreements") or []
        disagreements = fr.get("disagreements") or []
        convergences = fr.get("convergences") or []
        divergences = fr.get("divergences") or []
        if summary:
            findings_lines.append("Summary:")
            findings_lines.append(summary)
            findings_lines.append("")
        if answer:
            findings_lines.append("Recommended answer:")
            findings_lines.append(answer)
            findings_lines.append("")
        if isinstance(agreements, list) and agreements:
            findings_lines.append("Agreements:")
            for x in agreements:
                xs = str(x).strip()
                if xs:
                    findings_lines.append(f"- {xs}")
            findings_lines.append("")
        if isinstance(disagreements, list) and disagreements:
            findings_lines.append("Disagreements:")
            for x in disagreements:
                xs = str(x).strip()
                if xs:
                    findings_lines.append(f"- {xs}")
            findings_lines.append("")
        if isinstance(convergences, list) and convergences:
            findings_lines.append("Convergences:")
            for x in convergences:
                xs = str(x).strip()
                if xs:
                    findings_lines.append(f"- {xs}")
            findings_lines.append("")
        if isinstance(divergences, list) and divergences:
            findings_lines.append("Divergences:")
            for x in divergences:
                xs = str(x).strip()
                if xs:
                    findings_lines.append(f"- {xs}")
            findings_lines.append("")

    elif template == "item_rating":
        ires = store.get_artifact(run_id, "item_rating_results") or {}
        stats = ires.get("final_stats") or {}
        try:
            dim_names: list[str] = []
            if stats and isinstance(stats, dict):
                first_item = next(iter(stats.values()))
                if isinstance(first_item, dict):
                    dim_names = list(first_item.keys())
            dim0 = dim_names[0] if dim_names else None
            scored: list[tuple[float, float, str]] = []
            if dim0:
                for it, dims in stats.items():
                    if isinstance(dims, dict) and dim0 in dims and isinstance(dims[dim0], dict):
                        med = dims[dim0].get("median")
                        iqr = dims[dim0].get("iqr")
                        if med is not None:
                            scored.append((float(med), float(iqr or 999), str(it)))
                scored.sort(key=lambda x: (-x[0], x[1], x[2]))
                if scored:
                    findings_lines.append(f"Top items by median rating ({dim0}):")
                    for med, iqr, it in scored[:10]:
                        findings_lines.append(f"- {it} (median={med}, IQR={iqr})")
        except Exception:
            pass
    else:
        out = (final.get("outputs") or {})
        if out:
            findings_lines.append("Outputs (excerpt):")
            findings_lines.append(json.dumps(out, indent=2)[:6000])

    if not findings_lines:
        findings_lines = ["(No findings were available to summarise for this run.)"]

    # -------------------------
    # Method summary
    # -------------------------
    method_lines: list[str] = []
    method_lines.append(f"Template: {template or '(unspecified)'}")
    if template in TEMPLATE_EXPLAINERS:
        method_lines.append(f"Template purpose: {TEMPLATE_EXPLAINERS[template]}")
    method_lines.append(f"AI-Delphi panel mode: {mode or '(unspecified)'}")
    method_lines.append(f"Rounds: min={min_rounds}, max={max_rounds}, completed={rounds_completed}")
    method_lines.append(f"Quorum fraction: {quorum_fraction}")
    method_lines.append(f"Quorum reached: {quorum_reached}")

    rmode = cfg.get("response_length_mode")
    method_lines.append(f"Response length mode: {rmode}")
    try:
        pp = cfg.get("participant_policy", {}).get("overall", {})
        mp = cfg.get("master_policy", {}).get("overall", {})
        if pp:
            method_lines.append(
                "Participant word-count policy: "
                f"min={pp.get('min_words')}, target={pp.get('target_words')}, max={pp.get('max_words')}, strict={pp.get('strict')}"
            )
        if mp:
            method_lines.append(
                "Master word-count policy: "
                f"min={mp.get('min_words')}, target={mp.get('target_words')}, max={mp.get('max_words')}, strict={mp.get('strict')}"
            )
    except Exception:
        pass

    # -------------------------
    # Participants
    # -------------------------
    enabled_agents = [a for a in agents if a.get("enabled", True)]
    participant_lines: list[str] = []

    master_name = master.get("name", "Master Researcher")
    master_model = master.get("model", "")
    participant_lines.append("Master facilitator:")
    master_desc = f"- {master_name}: model={master_model}"
    if master.get("reasoning_effort"):
        master_desc += f", thinking={master.get('reasoning_effort')}"
    if master.get("verbosity"):
        master_desc += f", verbosity={master.get('verbosity')}"
    participant_lines.append(master_desc)
    participant_lines.append("")
    participant_lines.append(f"Participants (n={len(enabled_agents)}):")
    for a in enabled_agents:
        nm = a.get("name") or a.get("agent_id")
        aid = a.get("agent_id")
        mid = a.get("model") or ""
        role = a.get("discipline") or a.get("persona_name") or ""
        participant_lines.append(f"- {nm} ({aid}): model={mid}" + (f", role/persona={role}" if role else ""))

    # -------------------------
    # Abstract
    # -------------------------
    abstract = (
        f"This report summarises a Synthetic Delphi run titled '{title}'. "
        f"The study addressed the topic '{topic}' using the '{template}' pipeline and the '{mode}' panel mode. "
        f"The run completed {rounds_completed} round(s) and quorum was {'reached' if quorum_reached else 'not reached'}."
    ).strip()
    if problem:
        abstract += " Problem statement: " + problem

    # -------------------------
    # RTF assembly
    # -------------------------
    rtf: list[str] = []
    rtf.append(r"{\rtf1\ansi\ansicpg1252\uc1\deff0{\fonttbl{\f0 Calibri;}{\f1 Consolas;}}")
    rtf.append(r"\paperw11906\paperh16838\margl1440\margr1440\margt1440\margb1440")
    rtf.append(r"\pard\sa160\sl276\slmult1\fs24")

    # Cover header
    rtf.append(r"\fs48\b " + _to_rtf_paragraphs(report_title or "Synthetic Delphi — Consultancy Report") + r"\b0\fs24\par")
    rtf.append(r"\fs28 Synthetic Delphi\fs24\par")
    if project_name:
        rtf.append(_to_rtf_paragraphs(f"Project: {project_name}") + r"\par")
    rtf.append(r"\par")

    rtf.append(_to_rtf_paragraphs(f"Study title: {title}") + r"\par")
    if topic:
        rtf.append(_to_rtf_paragraphs(f"Topic: {topic}") + r"\par")
    rtf.append(_to_rtf_paragraphs(f"Run ID: {run_id}") + r"\par")
    rtf.append(_to_rtf_paragraphs(f"Generated: {created_at} (UTC)") + r"\par")
    rtf.append(_to_rtf_paragraphs("Created by: Shane McLoughlin") + r"\par")
    rtf.append(r"\par")

    # Abstract
    rtf.append(r"\fs30\b 1. Abstract\b0\fs24\par")
    rtf.append(_to_rtf_paragraphs(abstract) + r"\par\par")

    # Method
    rtf.append(r"\fs30\b 2. Method\b0\fs24\par")
    for ln in method_lines:
        rtf.append(_to_rtf_paragraphs(f"- {ln}") + r"\par")
    rtf.append(r"\par")

    # Participants
    rtf.append(r"\fs30\b 3. Participants\b0\fs24\par")
    for ln in participant_lines:
        if ln == "":
            rtf.append(r"\par")
        else:
            rtf.append(_to_rtf_paragraphs(ln) + r"\par")
    rtf.append(r"\par")

    # Findings
    rtf.append(r"\fs30\b 4. Findings\b0\fs24\par")
    for ln in findings_lines:
        if ln == "":
            rtf.append(r"\par")
            continue
        # If a line looks like a Markdown table row, render in monospace for readability.
        if "|" in ln and ln.strip().startswith("|"):
            rtf.append(r"\f1 " + _to_rtf_paragraphs(ln) + r"\f0\par")
        else:
            rtf.append(_to_rtf_paragraphs(ln) + r"\par")
    rtf.append(r"\par")

    # Appendix: execution summary
    exec_sum = store.get_artifact(run_id, "execution_summary") or {}
    if isinstance(exec_sum, dict) and exec_sum:
        rtf.append(r"\fs30\b Appendix A. Execution summary\b0\fs24\par")
        metrics = exec_sum.get("metrics") or {}
        if isinstance(metrics, dict) and metrics:
            for k, v in metrics.items():
                rtf.append(_to_rtf_paragraphs(f"- {k}: {v}") + r"\par")
            rtf.append(r"\par")

    rtf.append("}")
    return ("".join(rtf)).encode("ascii", errors="strict")




# -------------------------
# UI
# -------------------------


def main() -> None:
    st.set_page_config(page_title="Synthetic Delphi", layout="wide", initial_sidebar_state="expanded")
    _ensure_state()

    _inject_branding()
    st.caption(f"Version {APP_VERSION}. Cohorts saved under {COHORT_DIR}.")
    if getattr(st.session_state, "_import_notice", None):
        st.warning(st.session_state._import_notice)
        del st.session_state._import_notice


    # Sidebar: cohort manager
    with st.sidebar:
        st.header("Project")
        st.caption(f"Synthetic Delphi v{APP_VERSION}")

        # Project/report naming (persisted in cohort files)
        st.session_state.spec["project_name"] = st.text_input(
            "Project name",
            value=st.session_state.spec.get("project_name", ""),
            key="project_name_in",
            help="A human-friendly project label used in saved cohorts and report metadata.",
        )
        st.session_state.config["report_title"] = st.text_input(
            "Report title",
            value=st.session_state.config.get("report_title", "Synthetic Delphi — Consultancy Report"),
            key="report_title_in",
            help="Title used in generated RTF/Word reports.",
        )
        with st.expander("Build info", expanded=False):
            try:
                from pathlib import Path as _Path
                st.write("App folder:")
                st.code(str(_Path(__file__).resolve().parent))
                st.write("App file:")
                st.code(str(_Path(__file__).resolve()))
            except Exception:
                pass

        with st.expander("Available templates", expanded=False):
            # Self-check for users: if a template is missing here, you are running a different build/folder.
            for tid in [
                "item_rating",
                "questionnaire_ai_delphi",
                "recursive_reasoning",
                "forecasting",
                "priority_ranking",
                "sensemaking",
                "idea_generation",
                "criteria_standards",
                "policy_guidelines",
                "risk_register",
                "instrument_development",
                "scenario_building",
            ]:
                st.markdown(f"- `{tid}`")
        files = _cohort_files()
        if files:
            sel = st.selectbox("Load saved cohort", ["(select)"] + [p.name for p in files])
            if sel and sel != "(select)" and st.button("Load cohort", width="stretch"):
                payload = json.loads((COHORT_DIR / sel).read_text(encoding="utf-8"))
                _import_settings(payload)
                st.success(f"Loaded {sel}")
                st.rerun()
        else:
            st.caption("No saved cohorts yet.")

        st.divider()
        # Default filename: prefer project name if provided.
        _pn = st.session_state.spec.get("project_name") or ""
        _default_save = f"{_safe_slug(_pn, fallback='cohort')}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.json"
        save_name = st.text_input("Save as", value=_default_save)
        include_keys = st.checkbox("Include API keys", value=False, help="If enabled, API keys are written to disk in plain text JSON.")
        if st.button("Save cohort", width="stretch"):
            name = save_name.strip() or "cohort.json"
            if not name.lower().endswith(".json"):
                name += ".json"
            out = _export_settings(include_keys)
            (COHORT_DIR / name).write_text(json.dumps(out, indent=2), encoding="utf-8")
            st.success(f"Saved {name}")

        st.divider()
        st.header("Study Set-Up")
        step = st.radio(
            "Navigate",
            ["1) Participants", "2) Study design", "3) Instruments", "4) Run & results"],
            index=0,
        )

    if step.startswith("1"):
        _page_participants()
    elif step.startswith("2"):
        _page_design()
    elif step.startswith("3"):
        _page_instruments()
    else:
        _page_run_results()


def _page_participants() -> None:
    st.header("Participants")

    mode = st.session_state.config.get("ai_delphi_model", "digital_oracle")
    st.info(_panel_mode_explainer(mode))

    # Master (facilitator) config is shown here so users can see the full end-to-end mapping.
    with st.expander("Master facilitator model settings", expanded=False):
        _render_model_block(st.session_state.master, key_prefix="master")

    with st.expander("Global provider defaults (optional)", expanded=False):
        gp = st.session_state.get("global_provider", {})
        st.caption(
            "If you are using the same provider/model for most participants, set credentials once here. "
            "Participants can still override their own settings."
        )
        gcols = st.columns([1, 2, 2])
        gp["provider"] = gcols[0].selectbox(
            "Global provider",
            options=["openai_compat", "anthropic_compat", "google_compat", "local_http"],
            index=["openai_compat", "anthropic_compat", "google_compat", "local_http"].index(gp.get("provider", "openai_compat")),
            key="gp_provider",
        )
        gp["base_url"] = gcols[1].text_input("Global base URL", value=gp.get("base_url", "https://api.openai.com"), key="gp_base")
        gp["api_key"] = gcols[2].text_input("Global API key", value=gp.get("api_key", ""), type="password", key="gp_key")

        gcols2 = st.columns([1, 1, 1, 1])
        gp["use_key_for_participants"] = gcols2[0].checkbox(
            "Use global key for participants",
            value=bool(gp.get("use_key_for_participants", True)),
            key="gp_use_part",
            help="If enabled, the global API key will be used for participants (either as a fallback or an override, depending on the next option).",
        )
        gp["force_override_participant_keys"] = gcols2[1].checkbox(
            "Force override participant keys",
            value=bool(gp.get("force_override_participant_keys", False)),
            key="gp_force",
            help="If enabled, the global API key overwrites any per-participant key. If disabled, participants with a non-empty key keep it.",
        )
        gp["use_key_for_master"] = gcols2[2].checkbox(
            "Use global key for master",
            value=bool(gp.get("use_key_for_master", False)),
            key="gp_use_master",
            help="If enabled and the master key is blank, the global key is used for the facilitator.",
        )
        gp["apply_model_defaults_to_participants"] = gcols2[3].checkbox(
            "Apply global model defaults to participants",
            value=bool(gp.get("apply_model_defaults_to_participants", False)),
            key="gp_apply_model",
            help="If enabled, participants inherit global model/base_url/provider/temperature/max_tokens unless you manually override them later.",
        )

        st.caption("Optional: shared model defaults")
        mc = st.columns([1, 1, 1, 1])
        gp["model"] = mc[0].selectbox("Global model", options=DEFAULT_OPENAI_MODEL_CHOICES + ["(custom)"], index=(DEFAULT_OPENAI_MODEL_CHOICES + ["(custom)"]).index(gp.get("model", "gpt-4o")) if gp.get("model", "gpt-4o") in (DEFAULT_OPENAI_MODEL_CHOICES + ["(custom)"]) else 0, key="gp_model")
        if gp["model"] == "(custom)":
            gp["model"] = mc[1].text_input("Custom model id", value=gp.get("model", ""), key="gp_model_custom")
        else:
            mc[1].write("")


        gmodel_l = str(gp.get("model", "") or "").lower()
        if gmodel_l.startswith("gpt-5"):
            gp["temperature"] = 1.0
            try:
                mc[2].number_input(
                    "Global temperature (fixed for this model)",
                    min_value=1.0,
                    max_value=1.0,
                    value=1.0,
                    step=0.1,
                    key="gp_temp",
                    disabled=True,
                    help="This model only supports the default temperature (1.0).",
                )
            except TypeError:
                mc[2].number_input(
                    "Global temperature (fixed for this model)",
                    min_value=1.0,
                    max_value=1.0,
                    value=1.0,
                    step=0.1,
                    key="gp_temp",
                    help="This model only supports the default temperature (1.0).",
                )
                mc[2].caption("Fixed at 1.0 for this model.")
        else:
            gp["temperature"] = float(
                mc[2].slider(
                    "Global temperature",
                    0.0,
                    1.0,
                    float(gp.get("temperature", 0.2)),
                    0.05,
                    key="gp_temp",
                )
            )

        gp["max_tokens"] = int(
            mc[3].number_input(
                "Global max tokens",
                min_value=64,
                max_value=64000,
                value=int(gp.get("max_tokens", 1200)),
                step=64,
                key="gp_mt",
            )
)

        mc2 = st.columns(2)
        gp["reasoning_effort"] = mc2[0].selectbox("Global reasoning effort", options=REASONING_EFFORT_CHOICES, index=REASONING_EFFORT_CHOICES.index(gp.get("reasoning_effort", None)), key="gp_re")
        gp["verbosity"] = mc2[1].selectbox("Global verbosity", options=VERBOSITY_CHOICES, index=VERBOSITY_CHOICES.index(gp.get("verbosity", "medium")), key="gp_vb")

        st.session_state.global_provider = gp

        if st.button("Apply global API key to all participants now", width="stretch"):
            gk = (gp.get("api_key") or "").strip()
            if not gk:
                st.warning("Global API key is blank.")
            else:
                for a in st.session_state.agents:
                    a["api_key"] = gk
                st.success("Copied global API key into all participant records.")
                st.rerun()

    st.info(
        "Conversation isolation: each participant is treated as a separate chat thread. "
        "The runner sends independent message histories per agent and stage, and tags API calls with a per-agent identifier."
    )

    st.subheader("Panelists")

    col_add, col_fetch = st.columns([1, 2])
    
    with col_add:
        max_panelists = 30
        n_current = len(st.session_state.agents)
        st.caption(f"{n_current}/{max_panelists} participants configured.")
        if st.button("Add participant", disabled=(n_current >= max_panelists)):
            if n_current >= max_panelists:
                st.warning(f"Participant limit reached ({max_panelists}). Remove an existing participant to add another.")
            else:
                existing = {a.get("agent_id") for a in st.session_state.agents}
                next_n = 1
                while f"P{next_n}" in existing:
                    next_n += 1
                st.session_state.agents.append(
                    {
                        "agent_id": f"P{next_n}",
                        "name": f"Participant {next_n}",
                        "provider": "openai_compat",
                        "base_url": "https://api.openai.com",
                        "api_key": "",
                        "model": "gpt-4o",
                        "system_prompt": "You are a careful expert panelist. Provide clear, justified responses.",
                        "temperature": 0.2,
                        "max_tokens": 1200,
                        "reasoning_effort": None,
                        "verbosity": "medium",
                        "discipline": "",
                        "persona_name": "",
                        "persona_description": "",
                    }
                )
                st.rerun()
    
    with col_fetch:
        st.caption(
            "Tip: you can fetch the available model IDs from your provider's /v1/models endpoint using the Fetch button inside each participant." 
            "This is the most reliable way to see all OpenAI model IDs available to your account." 
        )

    for idx, a in enumerate(st.session_state.agents):
        with st.expander(f"{a.get('agent_id','?')} — {a.get('name','Participant')}", expanded=False):
            cols = st.columns([1, 1, 1])
            a["agent_id"] = cols[0].text_input("Agent ID", value=a.get("agent_id", f"P{idx+1}"), key=f"aid_{idx}")
            a["name"] = cols[1].text_input("Display name", value=a.get("name", f"Participant {idx+1}"), key=f"aname_{idx}")
            if cols[2].button("Remove", key=f"rm_{idx}"):
                st.session_state.agents.pop(idx)
                st.rerun()

            _render_model_block(a, key_prefix=f"agent_{idx}")

            st.divider()
            st.subheader("Panel-mode persona fields")
            st.caption("These fields are used differently depending on the AI-Delphi panel mode.")

            pcols = st.columns(3)
            a["discipline"] = pcols[0].text_input("Discipline / role", value=a.get("discipline", ""), key=f"disc_{idx}")
            a["persona_name"] = pcols[1].text_input("Persona name (Iconic Minds)", value=a.get("persona_name", ""), key=f"pname_{idx}")
            a["persona_description"] = pcols[2].text_input("Persona description", value=a.get("persona_description", ""), key=f"pdesc_{idx}")

            st.text_area(
                "System prompt (additional instructions)",
                value=a.get("system_prompt", ""),
                key=f"sys_{idx}",
                height=120,
                help="This prompt is always applied. In persona modes, the persona description is appended to this context.",
            )
            a["system_prompt"] = st.session_state.get(f"sys_{idx}", a.get("system_prompt", ""))


def _render_model_block(target: Dict[str, Any], *, key_prefix: str) -> None:
    cols = st.columns([1, 1, 1])
    target["provider"] = cols[0].selectbox(
        "Provider",
        options=["openai_compat", "anthropic_compat", "google_compat", "local_http"],
        index=["openai_compat", "anthropic_compat", "google_compat", "local_http"].index(target.get("provider", "openai_compat")),
        key=f"{key_prefix}_prov",
        help="Providers are OpenAI-compatible HTTP endpoints by default in this app.",
    )
    target["base_url"] = cols[1].text_input(
        "Base URL",
        value=target.get("base_url", "https://api.openai.com"),
        key=f"{key_prefix}_base",
        help="Example: https://api.openai.com (OpenAI). For gateways/proxies, use the gateway base URL.",
    )
    target["api_key"] = cols[2].text_input(
        "API key",
        value=target.get("api_key", ""),
        type="password",
        key=f"{key_prefix}_key",
        help="Leave blank to use the global API key (if configured). Stored in memory; optional to save to disk via Cohort manager.",
    )

    cache_key = (target.get("provider", "openai_compat"), target.get("base_url", ""))
    cached = st.session_state.model_cache.get(cache_key)

    cols2 = st.columns([1, 1, 1, 1])
    if cols2[0].button("Fetch models", key=f"{key_prefix}_fetch"):
        gp = st.session_state.get("global_provider", {}) or {}
        eff_key = (target.get("api_key") or "").strip() or (gp.get("api_key") or "").strip()
        eff_base = (target.get("base_url") or "").strip() or (gp.get("base_url") or "").strip()
        ids, err = _fetch_model_ids(eff_base, eff_key)
        if err:
            st.warning(f"Could not fetch models: {err}")
        else:
            st.session_state.model_cache[cache_key] = ids
            st.success(f"Fetched {len(ids)} models")
            st.rerun()

    model_choices = cached if cached else DEFAULT_OPENAI_MODEL_CHOICES
    # Always allow custom
    model_choices = model_choices + ["(custom)"]

    current = target.get("model", "")
    if current and current not in model_choices:
        model_choices = [current] + model_choices

    sel = cols2[1].selectbox("Model", options=model_choices, index=model_choices.index(current) if current in model_choices else 0, key=f"{key_prefix}_model")
    if sel == "(custom)":
        target["model"] = cols2[2].text_input("Custom model id", value=current, key=f"{key_prefix}_model_custom")
    else:
        target["model"] = sel
        cols2[2].write("")



    # Temperature: some newer models (e.g., GPT-5 family) only support the default value (1.0).
    model_l = str(target.get("model", "") or "").lower()
    if model_l.startswith("gpt-5"):
        target["temperature"] = 1.0
        try:
            cols2[3].number_input(
                "Temperature (fixed for this model)",
                min_value=1.0,
                max_value=1.0,
                value=1.0,
                step=0.1,
                key=f"{key_prefix}_temp",
                disabled=True,
                help="This model only supports the default temperature (1.0).",
            )
        except TypeError:
            cols2[3].number_input(
                "Temperature (fixed for this model)",
                min_value=1.0,
                max_value=1.0,
                value=1.0,
                step=0.1,
                key=f"{key_prefix}_temp",
                help="This model only supports the default temperature (1.0).",
            )
            cols2[3].caption("Fixed at 1.0 for this model.")
    else:
        target["temperature"] = float(
            cols2[3].slider(
                "Temperature",
                0.0,
                1.0,
                float(target.get("temperature", 0.2)),
                0.05,
                key=f"{key_prefix}_temp",
            )
        )

    cols3 = st.columns([1, 1, 1])
    target["max_tokens"] = int(cols3[0].number_input("Max tokens", min_value=64, max_value=64000, value=int(target.get("max_tokens", 1200)), step=64, key=f"{key_prefix}_mt"))
    target["reasoning_effort"] = cols3[1].selectbox(
        "Reasoning effort",
        options=REASONING_EFFORT_CHOICES,
        index=REASONING_EFFORT_CHOICES.index(target.get("reasoning_effort", None)),
        key=f"{key_prefix}_re",
        help="If your chosen model supports reasoning effort, this increases internal thinking compute. It does not change word-count policies.",
    )
    target["verbosity"] = cols3[2].selectbox(
        "Verbosity",
        options=VERBOSITY_CHOICES,
        index=VERBOSITY_CHOICES.index(target.get("verbosity", "medium")),
        key=f"{key_prefix}_vb",
        help="A lightweight control for how expansive responses are, independent from strict word counts.",
    )
def _page_design() -> None:
    st.header("Study design")

    _glossary_block()

    cfg = st.session_state.config
    spec = st.session_state.spec

    st.subheader("AI-Delphi panel mode")
    cfg["ai_delphi_model"] = st.selectbox(
        "Panel mode",
        options=["digital_oracle", "persona_panel", "iconic_minds"],
        index=["digital_oracle", "persona_panel", "iconic_minds"].index(cfg.get("ai_delphi_model", "digital_oracle")),
        help="This changes how participant persona fields are injected into the prompt context.",
    )


    st.info(_panel_mode_explainer(cfg["ai_delphi_model"]))

    # Iconic Minds guardrails are optional; provide an explicit toggle.
    if cfg["ai_delphi_model"] == "iconic_minds":
        cfg["iconic_minds_scope_guardrails"] = st.checkbox(
            "Enable Iconic Minds scope guardrails",
            value=bool(cfg.get("iconic_minds_scope_guardrails", True)),
            help=(
                "When enabled, the app adds conservative scope guardrails to iconic persona prompts. "
                "This reduces hallucinated biography and keeps responses on-topic. "
                "Turn off if you want maximal stylistic imitation."
            ),
        )
    else:
        # Stored for cohort persistence; used only when Panel mode is Iconic Minds.
        cfg["iconic_minds_scope_guardrails"] = bool(cfg.get("iconic_minds_scope_guardrails", True))

    st.divider()
    st.subheader("Study template")

    template_ids = [
        "item_rating",
        "questionnaire_ai_delphi",
        "recursive_reasoning",
        "forecasting",
        "priority_ranking",
        "sensemaking",
        "idea_generation",
        "criteria_standards",
        "policy_guidelines",
        "risk_register",
        "instrument_development",
        "scenario_building",
    ]

    def _tpl_label(x: str) -> str:
        labels = {
            "item_rating": "Item rating (classical Delphi)",
            "questionnaire_ai_delphi": "Questionnaire (AI-Delphi)",
            "recursive_reasoning": "Recursive reasoning (pool understanding → propose → finalise)",
            "forecasting": "Forecasting",
            "priority_ranking": "Priority ranking",
            "sensemaking": "Sensemaking / scoping",
            "idea_generation": "Idea generation",
            "criteria_standards": "Criteria / standards",
            "policy_guidelines": "Policy / guideline drafting",
            "risk_register": "Risk register",
            "instrument_development": "Instrument development",
            "scenario_building": "Scenario building",
        }
        return labels.get(x, x)

    current_tpl = st.session_state.config.get("template", st.session_state.spec.get("template", "item_rating"))
    chosen = st.selectbox(
        "Pipeline template",
        options=template_ids,
        index=template_ids.index(current_tpl) if current_tpl in template_ids else 0,
        format_func=_tpl_label,
        help="This determines the end-to-end pipeline executed when you run the study.",
    )
    # Keep both config and spec aligned (spec is saved as narrative inputs; config controls the runner).
    cfg["template"] = chosen
    spec["template"] = chosen

    expl = _template_explainer(chosen)
    if expl:
        st.info(expl)

    cols = st.columns(2)
    spec["topic"] = cols[0].text_input("Topic", value=spec.get("topic", ""))
    spec["study_goal"] = cols[1].text_input("Study goal", value=spec.get("study_goal", ""))

    spec["problem_statement"] = st.text_area("Problem statement", value=spec.get("problem_statement", ""), height=120)
    spec["research_question"] = st.text_area("Research question", value=spec.get("research_question", ""), height=80)

    st.divider()
    st.subheader("Round control")
    c1, c2, c3, c4 = st.columns(4)
    cfg["min_rounds"] = int(c1.number_input("Min rounds", min_value=1, max_value=6, value=int(cfg.get("min_rounds", 2))))
    cfg["max_rounds"] = int(c2.number_input("Max rounds", min_value=1, max_value=6, value=int(cfg.get("max_rounds", 3))))
    cfg["quorum_fraction"] = float(c3.slider("Quorum fraction", min_value=0.1, max_value=1.0, value=float(cfg.get("quorum_fraction", 0.7)), step=0.05))
    cfg["stage_deadline_s"] = int(c4.number_input("Stage deadline (seconds)", min_value=30, max_value=3600, value=int(cfg.get("stage_deadline_s", 240)), step=10))

    st.caption(
        "Quorum is evaluated per stage (e.g., Round 1 elicitation; Round 2 rating). If quorum is not met, the study stops and results are still saved for audit." 
    )

    st.subheader("Reporting")
    cfg["generate_word_report"] = st.checkbox(
        "Generate proofread Word report (.docx) after synthesis",
        value=bool(cfg.get("generate_word_report", True)),
        help="Adds a final post-synthesis step where the master facilitator performs a proofread-only pass (spelling/grammar/layout) and produces a downloadable Word report. If the proofread step fails, a draft Word report is still generated.",
    )

    st.divider()
    st.subheader("Stopping criteria (item-rating pipelines)")
    c1, c2 = st.columns(2)
    cfg["consensus_iqr_threshold"] = float(c1.slider("Consensus IQR threshold", 0.0, 5.0, float(cfg.get("consensus_iqr_threshold", 1.0)), 0.1))
    cfg["stability_median_threshold"] = float(c2.slider("Stability median threshold", 0.0, 5.0, float(cfg.get("stability_median_threshold", 0.5)), 0.1))

    st.divider()
    st.subheader("Response length and structure")
    st.markdown(
        """
    Max tokens is an API limit; it does not specify how long answers *should* be. This section lets you set a **response length policy**
    (expressed in words) separately from the model's token cap.
    """
    )
    cfg["response_length_mode"] = st.selectbox(
        "Response length mode",
        options=["tokens_only", "guided", "strict"],
        index=["tokens_only", "guided", "strict"].index(cfg.get("response_length_mode", "guided")),
        help="Strict mode automatically reprompts outputs that violate word-count constraints. Guided mode provides targets but does not reprompt.",
    )

    st.caption("Tip: The response policy controls are split across tabs. Click **Participant policy**, **Master policy**, and **Per-stage overrides** above for additional options.")

    tabs = st.tabs(["Participant policy", "Master policy", "Per-stage overrides"])

    with tabs[0]:
        st.caption("Applies to participant responses across stages unless overridden.")
        cfg["participant_policy"] = _policy_editor(cfg.get("participant_policy", {}), key_prefix="pp")

    with tabs[1]:
        st.caption("Applies to master facilitator outputs (consolidations, feedback, synthesis) unless overridden.")
        cfg["master_policy"] = _policy_editor(cfg.get("master_policy", {}), key_prefix="mp")

    with tabs[2]:
        st.caption("Override response policies for specific stage keys (participant vs master).")
        stage_keys = _stage_key_catalog(spec.get("template", "item_rating"))
        if not stage_keys:
            st.info("No stage key catalog available for this template.")
        else:
            sp_p = cfg.get("stage_policies_participant", {}) or {}
            sp_m = cfg.get("stage_policies_master", {}) or {}
            for sk, label in stage_keys:
                with st.expander(f"{sk} — {label}", expanded=False):
                    c1, c2 = st.columns(2)
                    with c1:
                        use_p = st.checkbox("Override participant policy", value=(sk in sp_p), key=f"ovp_{sk}", help="If enabled, this stage uses its own participant policy. If disabled, it inherits from the Participant policy tab.")
                        if use_p:
                            sp_p[sk] = _policy_editor(sp_p.get(sk, cfg.get("participant_policy", {})), key_prefix=f"ovp_pol_{sk}")
                        else:
                            sp_p.pop(sk, None)
                    with c2:
                        use_m = st.checkbox("Override master policy", value=(sk in sp_m), key=f"ovm_{sk}", help="If enabled, this stage uses its own master policy. If disabled, it inherits from the Master policy tab.")
                        if use_m:
                            sp_m[sk] = _policy_editor(sp_m.get(sk, cfg.get("master_policy", {})), key_prefix=f"ovm_pol_{sk}")
                        else:
                            sp_m.pop(sk, None)
            cfg["stage_policies_participant"] = sp_p
            cfg["stage_policies_master"] = sp_m

    st.divider()
    st.subheader("Master facilitator instructions")
    spec["master_instructions"] = st.text_area(
        "Additional facilitator instructions",
        value=spec.get("master_instructions", ""),
        height=120,
        help="Optional constraints on how the master consolidates, summarizes, and generates feedback.",
    )


def _page_instruments() -> None:
    st.header("Instruments")
    spec = st.session_state.spec

    # Some template parameters live in the config (DelphiConfig), not the spec.
    cfg = st.session_state.config

    template = spec.get("template", "item_rating")

    if template == "item_rating":
        st.subheader("Item elicitation settings")
        st.caption("Used only if you do not provide seed items.")
        spec["items_per_agent"] = int(
            st.number_input(
                "Items per participant (Round 1)",
                min_value=1,
                max_value=50,
                value=int(spec.get("items_per_agent", 6)),
            )
        )

        st.subheader("Rating dimensions")
        dims = spec.get("rating_dimensions", []) or []
        df = pd.DataFrame(dims)
        if df.empty:
            df = pd.DataFrame([{"name": "Importance", "description": "How important is this?"}])
        edited = st.data_editor(df, num_rows="dynamic", width="stretch", key="dims")
        spec["rating_dimensions"] = [
            {"name": str(r.get("name", "")).strip(), "description": str(r.get("description", "")).strip()}
            for _, r in edited.iterrows()
            if str(r.get("name", "")).strip()
        ]

        st.subheader("Seed items (optional)")
        st.caption("If provided, Round 1 elicitation is skipped and these items are rated directly.")
        raw = st.text_area("Seed items (one per line)", value="\n".join(spec.get("seed_items", []) or []), height=160)
        spec["seed_items"] = [x.strip() for x in raw.splitlines() if x.strip()]

    elif template == "priority_ranking":
        st.subheader("Item elicitation settings")
        st.caption("Used only if you do not provide seed items.")
        spec["items_per_agent"] = int(
            st.number_input(
                "Items per participant (Round 1)",
                min_value=1,
                max_value=50,
                value=int(spec.get("items_per_agent", 6)),
            )
        )

        st.subheader("Ranking settings")
        cfg["priority_top_k"] = int(
            st.number_input(
                "Top-k items each participant ranks each round",
                min_value=2,
                max_value=30,
                value=int(cfg.get("priority_top_k", 10)),
            )
        )

        st.subheader("Seed items (optional)")
        st.caption("If provided, Round 1 elicitation is skipped and the panel ranks these items.")
        raw = st.text_area("Seed items (one per line)", value="\n".join(spec.get("seed_items", []) or []), height=160)
        spec["seed_items"] = [x.strip() for x in raw.splitlines() if x.strip()]

    elif template == "questionnaire_ai_delphi":
        st.subheader("Questionnaire")
        st.caption("Enter the questionnaire questions (one per line). These are the fixed prompts participants will answer each round.")
        existing = spec.get("questionnaire", []) or spec.get("questionnaire_items", []) or []
        raw = st.text_area("Questions (one per line)", value="\n".join(existing), height=220)
        spec["questionnaire"] = [x.strip() for x in raw.splitlines() if x.strip()]

        st.session_state.config["questionnaire_followup"] = st.checkbox(
            "Include follow-up prompts for low agreement", value=bool(st.session_state.config.get("questionnaire_followup", True))
        )
        spec["include_final_synthesis"] = st.checkbox("Include final synthesis", value=bool(spec.get("include_final_synthesis", True)))

    elif template == "recursive_reasoning":
        st.subheader("Recursive reasoning")
        st.caption(
            "Enter the problem questions (one per line). Stage 1 collects ONLY panelists' understanding and reasoning; "
            "Stage 2 collects proposed solutions + reasoning; Stage 3 collects final solutions + reasoning."
        )
        existing = spec.get("questionnaire", []) or spec.get("questionnaire_items", []) or []
        raw = st.text_area("Questions (one per line)", value="\n".join(existing), height=220)
        spec["questionnaire"] = [x.strip() for x in raw.splitlines() if x.strip()]
        # Recursive reasoning is fixed 3 rounds and always ends with a synthesis.
        spec["include_final_synthesis"] = True


    elif template == "forecasting":
        st.subheader("Forecast questions")
        raw = st.text_area("Questions (one per line)", value="\n".join(spec.get("forecast_questions", []) or []), height=220)
        spec["forecast_questions"] = [x.strip() for x in raw.splitlines() if x.strip()]

        cfg = st.session_state.config
        c1, c2, c3 = st.columns(3)
        cfg["forecast_weight_by_confidence"] = c1.checkbox("Weight by confidence", value=bool(cfg.get("forecast_weight_by_confidence", True)))
        cfg["forecast_beta_pooling"] = c2.checkbox("Beta pooling", value=bool(cfg.get("forecast_beta_pooling", True)))
        cfg["forecast_beta_draws"] = int(c3.number_input("Beta draws", min_value=1000, max_value=200000, value=int(cfg.get("forecast_beta_draws", 20000)), step=1000))

    elif template == "scenario_building":
        st.subheader("Scenario settings")
        spec["scenario_time_horizon"] = st.text_input("Time horizon", value=spec.get("scenario_time_horizon", "5 years"))
        spec["n_scenarios"] = int(st.number_input("Number of scenarios", min_value=2, max_value=12, value=int(spec.get("n_scenarios", 4))))

    elif template == "idea_generation":
        st.subheader("Idea elicitation settings")
        spec["items_per_agent"] = int(
            st.number_input(
                "Ideas per participant",
                min_value=1,
                max_value=50,
                value=int(spec.get("items_per_agent", 10)),
            )
        )

    elif template in ("criteria_standards", "policy_guidelines"):
        st.subheader("Seed statements (optional)")
        st.caption("If provided, Round 1 elicitation is skipped and the panel rates these statements directly.")
        raw = st.text_area("Statements (one per line)", value="\n".join(spec.get("seed_statements", []) or []), height=180)
        spec["seed_statements"] = [x.strip() for x in raw.splitlines() if x.strip()]

        st.subheader("Elicitation volume")
        spec["statements_per_agent"] = int(
            st.number_input(
                "Statements per participant (if no seed statements)",
                min_value=1,
                max_value=50,
                value=int(spec.get("statements_per_agent", 6)),
            )
        )

    elif template == "risk_register":
        st.subheader("Risk elicitation settings")
        spec["risks_per_agent"] = int(
            st.number_input(
                "Risks per participant",
                min_value=1,
                max_value=50,
                value=int(spec.get("risks_per_agent", 8)),
            )
        )

    elif template == "instrument_development":
        st.subheader("Constructs (required)")
        st.caption("Provide the constructs you want the panel to generate measurement items for.")
        raw = st.text_area("Constructs (one per line)", value="\n".join(spec.get("constructs", []) or []), height=180)
        spec["constructs"] = [x.strip() for x in raw.splitlines() if x.strip()]

        spec["items_per_construct_per_agent"] = int(
            st.number_input(
                "Items per construct per participant",
                min_value=1,
                max_value=20,
                value=int(spec.get("items_per_construct_per_agent", 3)),
            )
        )

    elif template == "sensemaking":
        st.info("This template does not require additional instruments.")


def _page_run_results() -> None:
    st.header("Run & Results")

    # DB settings
    st.subheader("Storage")
    st.session_state.db_path = st.text_input("SQLite DB path", value=st.session_state.db_path, help="All runs are stored here for audit.")

    # Build objects and validate
    try:
        agents, master, config, spec = _build_objects()
    except Exception as e:
        st.error(f"Configuration error: {e}")
        return

    st.divider()
    st.subheader("Run study")

    # Template-specific pre-validation (avoid hard crashes from pipeline ValueErrors)
    validation_errors: List[str] = []
    if config.template == "item_rating":
        if not getattr(spec, "rating_dimensions", None):
            validation_errors.append(
                "Item-rating template requires at least one rating dimension. Go to Step 3 (Instruments) and add a dimension (e.g., Importance, Feasibility)."
            )
    if config.template == "questionnaire_ai_delphi":
        if not getattr(spec, "questionnaire", None):
            validation_errors.append(
                "Questionnaire template requires at least one question. Go to Step 3 (Instruments) and add questions (one per line)."
            )
    if config.template == "recursive_reasoning":
        if not getattr(spec, "questionnaire", None):
            validation_errors.append(
                "Recursive reasoning template requires at least one question. Go to Step 3 (Instruments) and add questions (one per line)."
            )
    if config.template == "forecasting":
        if not getattr(spec, "forecast_questions", None):
            validation_errors.append(
                "Forecasting template requires at least one forecast question. Go to Step 3 (Instruments) and add questions (one per line)."
            )
    if config.template == "instrument_development":
        if not getattr(spec, "constructs", None):
            validation_errors.append(
                "Instrument development template requires at least one construct. Go to Step 3 (Instruments) and add constructs (one per line)."
            )

    can_run = len(validation_errors) == 0
    if not can_run:
        for msg in validation_errors:
            st.error(msg)

    log_placeholder = st.empty()

    def _progress_hook(ev: Dict[str, Any]) -> None:
        # UI-safe: called only from main thread in this implementation.
        st.session_state.run_log.append({"ts": _now_stamp(), **(ev or {})})
        # Render a concise live view
        last = st.session_state.run_log[-20:]
        lines = []
        for x in last:
            t = x.get("type") or x.get("event") or ""
            if t in ("STAGE_STARTED", "STAGE_FINISHED"):
                lines.append(f"- {x.get('type')} — {x.get('stage_name','')} ({x.get('stage_key','')})")
            elif t in ("RUN_STARTED", "RUN_FINISHED"):
                lines.append(f"- {x.get('type')} — run_id={x.get('run_id','')}")
        if lines:
            log_placeholder.markdown("\n".join(lines))

    col1, col2 = st.columns([1, 2])
    with col1:
        if st.button("Run study now", type="primary", width="stretch", disabled=(not can_run)):
            st.session_state.run_log = []

            # Provider: the runner is provider-agnostic; each agent carries credentials and model.
            # Select a concrete provider implementation based on the master's provider kind.
            provider = MockProvider() if master.provider == "mock" else OpenAICompatibleProvider()
            store = SQLiteStore(st.session_state.db_path)
            runner = DelphiStudyRunner(store=store, provider=provider)

            opts = RunOptions(run_id=None, late_policy="exclude", progress_hook=_progress_hook)

            try:
                with st.spinner("Running study pipeline..."):
                    result = runner.run(spec=spec, agents=agents, master=master, config=config, options=opts)
                    run_id = result.run_id
            except Exception as e:
                st.exception(e)
                return

            st.session_state.last_run_id = run_id
            st.success(f"Study run completed. run_id = {run_id}")

    with col2:
        st.markdown(
            """
**What happens when you run a study:**
- The pipeline executes stages (elicitation, consolidation, rating, feedback, synthesis) based on your selected template.
- Every stage writes an auditable trail to the SQLite DB: stage status, API calls, messages (prompts/responses), task success/failure, and artifacts.
- Response length policies are applied independently of max_tokens; in strict mode, the system may reprompt to enforce word counts.
"""
        )

    st.divider()
    st.subheader("Audit trail and artifacts")

    run_id = st.text_input("Run ID", value=st.session_state.last_run_id or "", help="Load results for any prior run stored in the DB.")
    if not run_id.strip():
        st.info("Run a study or enter an existing run_id to view results.")
        return

    store = SQLiteStore(st.session_state.db_path)

    rec = store.get_study_record(run_id.strip())
    if rec:
        with st.expander("Study inputs (as saved)", expanded=False):
            st.json(rec)

    exec_sum = store.load_artifact(run_id.strip(), "execution_summary")
    agents_data = None
    stages_data = None
    if isinstance(exec_sum, dict):
        agents_data = exec_sum.get("agent_summary") or exec_sum.get("agents")
        stages_data = exec_sum.get("stage_summary") or exec_sum.get("stages")

    # UX order: health tables + report first, then the full executive/execution JSON.
    st.markdown("#### Agent-level health")
    if agents_data:
        try:
            dfa = pd.DataFrame(agents_data)
            if not dfa.empty:
                st.dataframe(dfa, width="stretch")
            else:
                st.caption("No agent health records for this run.")
        except Exception:
            st.caption("No agent health records for this run.")
    else:
        st.caption("No agent health records for this run.")

    st.markdown("#### Stage-level health")
    if stages_data:
        try:
            dfs = pd.DataFrame(stages_data)
            if not dfs.empty:
                st.dataframe(dfs, width="stretch")
            else:
                st.caption("No stage health records for this run.")
        except Exception:
            st.caption("No stage health records for this run.")
    else:
        st.caption("No stage health records for this run.")

    st.markdown("#### Report")
    st.caption("Download a professionally formatted RTF report (suitable for Microsoft Word) summarising the study inputs, method, participants, and findings.")
    try:
        rtf_bytes = _build_consultancy_rtf(run_id.strip(), store)
        # Use the saved report title/project name to create a meaningful filename.
        _rec = store.get_study_record(run_id.strip()) or {}
        _spec = _rec.get("spec") or {}
        _cfg = _rec.get("config") or {}
        _pn = str(_spec.get("project_name") or "").strip()
        _rt = str(_cfg.get("report_title") or "").strip()
        _fname = f"{_safe_slug(_pn, fallback='synthetic-delphi')}_{_safe_slug(_rt, fallback='report')}_{run_id.strip()}.rtf"
        st.download_button(
            "Download report (RTF)",
            data=rtf_bytes,
            file_name=_fname,
            mime="application/rtf",
            width="stretch",
        )
        # Word (.docx) report: generated by the pipeline after synthesis (if enabled).
        try:
            docx_art = store.load_artifact(run_id.strip(), "polished_report_docx")
            if isinstance(docx_art, dict) and docx_art.get("b64"):
                docx_bytes = base64.b64decode(docx_art["b64"])
                _docx_name = f"{_safe_slug(_pn, fallback='synthetic-delphi')}_{_safe_slug(_rt, fallback='report')}_{run_id.strip()}.docx"
                st.download_button(
                    "Download report (Word .docx)",
                    data=docx_bytes,
                    file_name=_docx_name,
                    mime=str(docx_art.get("mime") or "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
                    width="stretch",
                )
                if docx_art.get("polished_by_llm") is True:
                    st.caption("Word report: proofread-only pass applied by the master facilitator.")
                else:
                    st.caption("Word report: draft generated (proofread pass not applied or was rejected to prevent rewriting).")
            else:
                st.caption("Word report not available for this run (enable it in Study design → Reporting, then rerun).")
        except Exception:
            st.caption("Word report not available for this run.")

    except Exception as e:
        st.warning(f"Report generation unavailable: {e}")

    st.markdown("#### Executive summary")
    if exec_sum:
        with st.expander("Executive summary (full pipeline record)", expanded=False):
            st.json(exec_sum)
    else:
        st.caption("No execution summary artifact found for this run (older runs may not include it).")

    # Artifacts
    arts = store.list_artifacts(run_id.strip())
    if arts:
        names = [a["name"] for a in arts]
        sel = st.selectbox("Artifact", options=names)
        art = store.load_artifact(run_id.strip(), sel)
        with st.expander("Artifact content", expanded=True):
            st.json(art)
    else:
        st.caption("No artifacts recorded for this run.")

    # Stages
    st.markdown("#### Stages")
    stages = store.list_stages(run_id.strip())
    if stages:
        df = pd.DataFrame(stages)
        st.dataframe(df, width="stretch")
    else:
        st.caption("No stages found.")

    # Events
    with st.expander("Events", expanded=False):
        evs = store.list_events(run_id.strip(), limit=500)
        st.dataframe(pd.DataFrame(evs), width="stretch")

    # Messages explorer
    with st.expander("Messages (prompts/responses)", expanded=False):
        stage_ids = sorted({s.get("stage_id") for s in (stages or []) if s.get("stage_id")})
        agents_ids = sorted({a.get("agent_id") for a in (rec.get("agents", []) if rec else []) if a.get("agent_id")})
        c1, c2, c3 = st.columns(3)
        stage_filter = c1.selectbox("Stage", options=["(any)"] + stage_ids)
        agent_filter = c2.selectbox("Agent", options=["(any)"] + agents_ids + ["MASTER"])
        limit = int(c3.number_input("Limit", min_value=10, max_value=5000, value=200, step=10))

        stage_id = None if stage_filter == "(any)" else stage_filter
        agent_id = None if agent_filter == "(any)" else agent_filter

        msgs = store.list_messages(run_id.strip(), stage_id=stage_id, agent_id=agent_id, limit=limit, order="ASC")
        if msgs:
            dfm = pd.DataFrame(msgs)
            st.dataframe(dfm.drop(columns=["content"], errors="ignore"), width="stretch")
            mid = st.selectbox("Select message to view", options=[m["msg_id"] for m in msgs])
            msel = next((m for m in msgs if m["msg_id"] == mid), None)
            if msel:
                st.code(msel.get("content", ""), language="markdown")
            # Download
            dl = json.dumps(msgs, indent=2)
            st.download_button("Download messages as JSON", data=dl, file_name=f"messages_{run_id.strip()}.json")
        else:
            st.caption("No messages matching your filters.")

    store.close()


if __name__ == "__main__":
    main()
