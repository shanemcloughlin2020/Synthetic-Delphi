from __future__ import annotations

from typing import Any, Dict, List, Optional

import json

from .schemas import AIDelphiModel


def apply_iconic_minds_guardrails(system_prompt: str) -> str:
    guard = '''Guardrails for Iconic-Minds emulation:
- Only infer views within the person's publicly known domains of expertise.
- Do NOT attribute controversial positions not evidenced by their public record.
- If asked outside scope, explicitly say it is outside the persona's evidenced domain and respond cautiously.
- Avoid stereotyping; distinguish speculation from evidence.
'''
    if guard in system_prompt:
        return system_prompt
    if not system_prompt.strip():
        return guard
    return system_prompt.strip() + "\n\n" + guard


def persona_system_prompt(
    ai_delphi_model: AIDelphiModel,
    persona_name: str,
    persona_description: str,
    iconic_guardrails: bool = True,
) -> str:
    base = f"You are simulating the persona: {persona_name}.\n{persona_description.strip()}"
    if ai_delphi_model == "iconic_minds" and iconic_guardrails:
        base = apply_iconic_minds_guardrails(base)
    return base


def prompt_generate_expert_list(topic: str, categories: List[str]) -> List[Dict[str, str]]:
    cats = "\n".join([f"{i+1}. {c}" for i, c in enumerate(categories)])
    user = (
        f"Make a list of famous people who are most recommended to participate in a Delphi study about: {topic}.\n"
        f"Please provide at least three names for each of the following categories:\n{cats}\n\n"
        "Return ONLY JSON with this schema: {\"categories\": [{\"name\": \"...\", \"people\": [\"...\", ...]}]}"
    )
    return [
        {"role": "system", "content": "You are a careful assistant. Output only valid JSON."},
        {"role": "user", "content": user},
    ]


def prompt_generate_persona_prompt(expert_name: str) -> List[Dict[str, str]]:
    user = (
        f"Could you write a system prompt about {expert_name} so that I can ask you to assume their persona? "
        "Expand it with relevant background information, areas of expertise, key opinions, tone of communication, "
        "and any other details that would help you more easily assume their persona.\n\n"
        "Return ONLY JSON with schema: {\"system_prompt\": \"...\"}"
    )
    return [
        {"role": "system", "content": "You are a careful assistant. Output only valid JSON."},
        {"role": "user", "content": user},
    ]


def prompt_generate_persona_panel(
    topic: str,
    disciplines: List[str],
    region: str = "",
) -> List[Dict[str, str]]:
    """Generate fictional-but-plausible expert personas for a Persona Panel Delphi.

    The AI-Delphi paper frames Persona Panel as generic professional personas from
    multiple disciplines (rather than named public figures). This helper returns
    one persona per discipline.
    """
    region_txt = f" (context: {region})" if region.strip() else ""
    ds = "\n".join([f"- {d}" for d in disciplines if d.strip()])
    user = (
        f"Create a Delphi panel for the topic: {topic}{region_txt}.\n"
        "Generate ONE fictional expert persona for each discipline below.\n\n"
        f"Disciplines:\n{ds}\n\n"
        "For each persona, provide: (1) a short display name, (2) discipline, (3) a 3–6 bullet bio, "
        "(4) typical assumptions/biases, (5) a concise SYSTEM PROMPT that will condition an LLM to behave as this persona.\n\n"
        "Return ONLY JSON with schema: {\"personas\": [{\"name\":\"...\",\"discipline\":\"...\",\"bio_bullets\":[\"...\"],\"assumptions\":[\"...\"],\"system_prompt\":\"...\"}, ...]}"
    )
    return [
        {"role": "system", "content": "You are a careful assistant. Output only valid JSON."},
        {"role": "user", "content": user},
    ]


def prompt_round1_elicit_items(topic: str, problem_statement: str, items_per_agent: int) -> List[Dict[str, str]]:
    user = (
        f"You are participating in a Delphi study on the topic: {topic}.\n"
        f"Context/problem: {problem_statement or '(none provided)'}\n\n"
        f"Task: Propose {items_per_agent} candidate items (e.g., drivers, factors, indicators, statements) relevant to the topic. "
        "Each item should be concise and distinct. Provide a short rationale for each.\n\n"
        "Return ONLY JSON with schema: {\"items\": [{\"text\": \"...\", \"rationale\": \"...\"}, ...]}"
    )
    return [{"role": "user", "content": user}]


def prompt_master_consolidate_items(topic: str, raw_items: List[str]) -> List[Dict[str, str]]:
    joined = "\n".join([f"- {x}" for x in raw_items])
    user = (
        f"You are the Delphi facilitator. Topic: {topic}.\n"
        "Task: Consolidate the following items by merging near-duplicates and standardizing wording. "
        "Do not invent new items; only merge and lightly edit. Keep the set as small as possible without losing meaning.\n\n"
        f"Items:\n{joined}\n\n"
        "Return ONLY JSON with schema: {\"items\": [\"...\", ...]}"
    )
    return [{"role": "user", "content": user}]


def prompt_round_rating(
    topic: str,
    problem_statement: str,
    items: List[str],
    dimensions: List[Dict[str, str]],
    round_index: int,
    feedback: Optional[str] = None,
) -> List[Dict[str, str]]:
    dim_txt = "\n".join([f"- {d['name']}: {d.get('description','')}".strip() for d in dimensions])
    items_txt = "\n".join([f"{i+1}. {it}" for i, it in enumerate(items)])
    fb = ""
    if feedback:
        fb = f"\n\nControlled group feedback from prior round (anonymized):\n{feedback}\n"
    user = (
        f"You are participating in a Delphi study on: {topic}.\n"
        f"Context/problem: {problem_statement or '(none provided)'}\n"
        f"Round: {round_index}\n"
        f"{fb}\n"
        "Task: Rate each item on each dimension using integer ratings. Provide a brief justification per item.\n"
        f"Dimensions:\n{dim_txt}\n\n"
        f"Items:\n{items_txt}\n\n"
        "Return ONLY JSON with schema: "
        "{"
        "\"ratings\": ["
        "{\"item_index\": 1, \"scores\": {\"Importance\": 5}, \"justification\": \"...\"},"
        " ...],"
        "\"overall_comment\": \"...\""
        "}"
    )
    return [{"role": "user", "content": user}]


def prompt_master_feedback_item_rating(round_index: int, stats_markdown: str, rationale_themes: str) -> List[Dict[str, str]]:
    user = (
        f"You are the Delphi facilitator. Prepare controlled feedback for the next round (Round {round_index+1}).\n"
        "You must be neutral, concise, and focus on dispersion and reasons.\n\n"
        f"Quantitative summary (per item):\n{stats_markdown}\n\n"
        f"Qualitative themes across rationales:\n{rationale_themes}\n\n"
        "Return ONLY JSON with schema: {\"feedback\": \"...\"}"
    )
    return [{"role": "user", "content": user}]


def prompt_round_questionnaire(
    topic: str,
    problem_statement: str,
    questionnaire: List[str],
    round_index: int,
    per_question_feedback: Optional[Dict[int, str]] = None,
) -> List[Dict[str, str]]:
    q_txt = []
    for idx, q in enumerate(questionnaire, start=1):
        fb = ""
        if per_question_feedback and idx in per_question_feedback:
            fb = f"\n  Group feedback: {per_question_feedback[idx]}"
        q_txt.append(f"{idx}. {q}{fb}")
    block = "\n\n".join(q_txt)
    user = (
        f"Dear participant, you have been invited to participate in a Delphi survey on: {topic}.\n"
        f"Context/problem: {problem_statement or '(none provided)'}\n"
        f"Round: {round_index}\n\n"
        "Please answer each question carefully and concretely.\n\n"
        f"Questionnaire:\n{block}\n\n"
        "Return your answers in JSON ONLY: {\"answers\": [{\"question_index\": 1, \"answer\": \"...\"}, ...]}"
    )
    return [{"role": "user", "content": user}]



def prompt_master_feedback_questionnaire(
    question_index: int,
    question_text: str,
    answers: List[str],
    propose_followups: bool,
) -> List[Dict[str, str]]:
    joined = "\n".join([f"- {a}" for a in answers])

    schema = (
        '{"agreement": ["..."], "disagreements": ["..."], "missing_considerations": ["..."], '
        '"summary": "...", "followups": ["..."]}'
    )

    followup_note = (
        "Include 1–3 clarification questions in followups (as short, actionable questions)."
        if propose_followups
        else "Return followups as an empty list."
    )

    return [
        {
            "role": "system",
            "content": (
                "You are a Delphi master facilitator. You must provide controlled feedback for the next Delphi round. "
                "Be fair, neutral, and concise. Do not invent participant identities. "
                "Return valid JSON only."
            ),
        },
        {
            "role": "user",
            "content": (
                f"Question {question_index}: {question_text}\n\n"
                "Participant answers:\n"
                f"{joined}\n\n"
                "Task: analyse the answers and prepare controlled feedback for the next Delphi round.\n"
                "- Identify points of agreement (as short bullets).\n"
                "- Identify key disagreements / divergences (as short bullets).\n"
                "- Identify missing considerations or perspectives (as short bullets).\n"
                "- Provide a brief narrative summary (2–6 sentences).\n"
                f"- {followup_note}\n\n"
                f"Return ONLY JSON using this schema: {schema}"
            ),
        },
    ]


def prompt_round_forecasting(
    topic: str,
    problem_statement: str,
    questions: List[str],
    round_index: int,
    feedback: Optional[str] = None,
) -> List[Dict[str, str]]:
    qs = "\n".join([f"{i+1}. {q}" for i, q in enumerate(questions)])
    fb = f"\n\nControlled group feedback (anonymized):\n{feedback}\n" if feedback else ""
    user = (
        f"You are participating in a Delphi forecasting study on: {topic}.\n"
        f"Context/problem: {problem_statement or '(none provided)'}\n"
        f"Round: {round_index}\n"
        f"{fb}\n"
        "Task: For each question, provide your best probability estimate that the event occurs (0-100). "
        "Also provide a confidence rating (1-5) and a brief rationale.\n\n"
        f"Questions:\n{qs}\n\n"
        "Return ONLY JSON with schema: {\"forecasts\": [{\"question_index\": 1, \"probability\": 55, \"confidence\": 3, \"rationale\": \"...\"}, ...]}"
    )
    return [{"role": "user", "content": user}]


def prompt_master_feedback_forecasting(
    round_index: int,
    aggregated_table_md: str,
    rationale_themes: str,
) -> List[Dict[str, str]]:
    user = (
        f"You are the Delphi facilitator. Prepare controlled feedback for the next forecasting round (Round {round_index+1}).\n"
        "Be neutral and concise. Highlight dispersion, central tendency, and major reasons for disagreement.\n\n"
        f"Aggregated quantitative summary (per question):\n{aggregated_table_md}\n\n"
        f"Qualitative rationale themes (anonymized):\n{rationale_themes}\n\n"
        "Return ONLY JSON with schema: {\"feedback\": \"...\"}"
    )
    return [{"role": "user", "content": user}]


def prompt_round_rank_items(
    topic: str,
    problem_statement: str,
    items: List[str],
    top_k: int,
    round_index: int,
    feedback: Optional[str] = None,
) -> List[Dict[str, str]]:
    items_txt = "\n".join([f"{i+1}. {it}" for i, it in enumerate(items)])
    fb = f"\n\nControlled group feedback (anonymized):\n{feedback}\n" if feedback else ""
    user = (
        f"You are participating in a Delphi priority-setting study on: {topic}.\n"
        f"Context/problem: {problem_statement or '(none provided)'}\n"
        f"Round: {round_index}\n"
        f"{fb}\n"
        f"Task: Select and RANK your top {top_k} items from the list below. "
        "Return the ranked list as item indices in descending priority (rank 1 = highest). "
        "Also provide a brief overall rationale for your top choices.\n\n"
        f"Items:\n{items_txt}\n\n"
        "Return ONLY JSON with schema: {\"ranked_item_indices\": [3, 1, 2, ...], \"rationale\": \"...\"}"
    )
    return [{"role": "user", "content": user}]


def prompt_master_feedback_priority(
    round_index: int,
    borda_table_md: str,
    contested_items: str,
) -> List[Dict[str, str]]:
    user = (
        f"You are the Delphi facilitator. Prepare controlled feedback for the next priority-setting round (Round {round_index+1}).\n"
        "Be neutral. Highlight where rankings converge and where they diverge (contested items).\n\n"
        f"Aggregated ranking summary:\n{borda_table_md}\n\n"
        f"Contested items and reasons (anonymized):\n{contested_items}\n\n"
        "Return ONLY JSON with schema: {\"feedback\": \"...\"}"
    )
    return [{"role": "user", "content": user}]


def prompt_round_sensemaking_elicit(topic: str, problem_statement: str, round_index: int, feedback: Optional[str] = None) -> List[Dict[str, str]]:
    fb = f"\n\nControlled group feedback (anonymized):\n{feedback}\n" if feedback else ""
    user = (
        f"You are participating in a Delphi sensemaking exercise on: {topic}.\n"
        f"Context/problem: {problem_statement or '(none provided)'}\n"
        f"Round: {round_index}\n"
        f"{fb}\n"
        "Task: Help scope and clarify this domain. Provide (1) key concepts with short definitions, "
        "(2) key assumptions, (3) boundaries (in-scope vs out-of-scope), (4) critical uncertainties/open questions.\n\n"
        "Return ONLY JSON with schema: {\"concepts\": [{\"term\":\"...\",\"definition\":\"...\"}, ...], "
        "\"assumptions\": [\"...\"], "
        "\"boundaries\": {\"in_scope\": [\"...\"], \"out_of_scope\": [\"...\"]}, "
        "\"uncertainties\": [\"...\"]}"
    )
    return [{"role": "user", "content": user}]


def prompt_master_consolidate_sensemaking(topic: str, raw_payloads: List[Dict[str, str]]) -> List[Dict[str, str]]:
    # raw_payloads are JSON strings or compact text blocks
    joined = "\n\n".join([f"---\n{p}" for p in raw_payloads])
    user = (
        f"You are the Delphi facilitator. Topic: {topic}.\n"
        "Task: Consolidate the panel's sensemaking inputs into a single, coherent scope map. "
        "Merge duplicates; standardize wording; do not invent new concepts beyond what is supported.\n\n"
        f"Inputs:\n{joined}\n\n"
        "Return ONLY JSON with schema: {\"glossary\": [{\"term\":\"...\",\"definition\":\"...\"}], "
        "\"assumptions\": [\"...\"], "
        "\"in_scope\": [\"...\"], \"out_of_scope\": [\"...\"], "
        "\"uncertainties\": [\"...\"], "
        "\"notes\": \"...\"}"
    )
    return [{"role": "user", "content": user}]


def prompt_round_risk_elicit(topic: str, problem_statement: str, risks_per_agent: int, round_index: int, feedback: Optional[str] = None) -> List[Dict[str, str]]:
    fb = f"\n\nControlled group feedback (anonymized):\n{feedback}\n" if feedback else ""
    user = (
        f"You are participating in a Delphi risk identification study on: {topic}.\n"
        f"Context/problem: {problem_statement or '(none provided)'}\n"
        f"Round: {round_index}\n"
        f"{fb}\n"
        f"Task: Propose {risks_per_agent} risks/failure modes relevant to the topic. For each, provide: "
        "(a) concise risk statement, (b) likely causes, (c) likely impacts, (d) candidate mitigations/controls.\n\n"
        "Return ONLY JSON with schema: {\"risks\": [{\"risk\":\"...\",\"causes\":[\"...\"],\"impacts\":[\"...\"],\"mitigations\":[\"...\"],\"rationale\":\"...\"}, ...]}"
    )
    return [{"role": "user", "content": user}]


def prompt_master_consolidate_risks(topic: str, raw_risks: List[Dict[str, str]]) -> List[Dict[str, str]]:
    joined = "\n".join([f"- {r}" for r in raw_risks])
    user = (
        f"You are the Delphi facilitator. Topic: {topic}.\n"
        "Task: Consolidate the following risk entries into a non-duplicative risk register. "
        "Merge near-duplicates; standardize wording; preserve key causes/impacts/mitigations.\n\n"
        f"Risk inputs:\n{joined}\n\n"
        "Return ONLY JSON with schema: {\"risks\": [{\"risk_id\":\"R1\",\"risk\":\"...\",\"causes\":[\"...\"],\"impacts\":[\"...\"],\"mitigations\":[\"...\"]}, ...]}"
    )
    return [{"role": "user", "content": user}]


def prompt_round_risk_rating(
    topic: str,
    problem_statement: str,
    risks: List[Dict[str, str]],
    round_index: int,
    feedback: Optional[str] = None,
) -> List[Dict[str, str]]:
    fb = f"\n\nControlled group feedback (anonymized):\n{feedback}\n" if feedback else ""
    lines = []
    for i, r in enumerate(risks, start=1):
        lines.append(f"{i}. {r.get('risk_id','R?')} — {r.get('risk','')}\n   Causes: {', '.join(r.get('causes',[])[:3])}\n   Impacts: {', '.join(r.get('impacts',[])[:3])}\n   Mitigations: {', '.join(r.get('mitigations',[])[:3])}")
    risk_txt = "\n\n".join(lines)
    user = (
        f"You are participating in a Delphi risk assessment study on: {topic}.\n"
        f"Context/problem: {problem_statement or '(none provided)'}\n"
        f"Round: {round_index}\n"
        f"{fb}\n"
        "Task: For each risk, rate Likelihood (1-5) and Impact (1-5). Provide a brief justification.\n\n"
        f"Risks:\n{risk_txt}\n\n"
        "Return ONLY JSON with schema: {\"ratings\": [{\"risk_index\": 1, \"likelihood\": 3, \"impact\": 4, \"justification\": \"...\"}, ...]}"
    )
    return [{"role": "user", "content": user}]


def prompt_round_instrument_elicit(
    topic: str,
    problem_statement: str,
    constructs: List[str],
    items_per_construct_per_agent: int,
    round_index: int,
    feedback: Optional[str] = None,
) -> List[Dict[str, str]]:
    fb = f"\n\nControlled group feedback (anonymized):\n{feedback}\n" if feedback else ""
    c_txt = "\n".join([f"- {c}" for c in constructs])
    user = (
        f"You are participating in a Delphi instrument development study on: {topic}.\n"
        f"Context/problem: {problem_statement or '(none provided)'}\n"
        f"Round: {round_index}\n"
        f"{fb}\n"
        "Task: For each construct, propose survey items (statements) that could measure the construct. "
        "Items should be clear, non-double-barreled, and appropriate for a 5- or 7-point agreement scale.\n"
        f"Provide {items_per_construct_per_agent} items per construct.\n\n"
        f"Constructs:\n{c_txt}\n\n"
        "Return ONLY JSON with schema: {\"items\": [{\"construct\":\"...\",\"item_text\":\"...\",\"rationale\":\"...\"}, ...]}"
    )
    return [{"role": "user", "content": user}]


def prompt_master_consolidate_instrument(topic: str, raw_items: List[Dict[str, str]], constructs: List[str]) -> List[Dict[str, str]]:
    joined = "\n".join([f"- {r}" for r in raw_items])
    c_txt = ", ".join(constructs)
    user = (
        f"You are the Delphi facilitator. Topic: {topic}.\n"
        f"Constructs: {c_txt}\n"
        "Task: Consolidate the proposed survey items. Remove duplicates; standardize wording; keep items mapped to constructs. "
        "Do not invent entirely new constructs.\n\n"
        f"Raw proposed items:\n{joined}\n\n"
        "Return ONLY JSON with schema: {\"instrument\": {\"constructs\": [{\"name\":\"...\",\"items\": [\"...\", ...]}, ...]}}"
    )
    return [{"role": "user", "content": user}]


def prompt_round_instrument_rating(
    topic: str,
    problem_statement: str,
    instrument: Dict[str, Any],
    round_index: int,
    feedback: Optional[str] = None,
) -> List[Dict[str, str]]:
    fb = f"\n\nControlled group feedback (anonymized):\n{feedback}\n" if feedback else ""
    # flatten items
    lines = []
    idx = 0
    for c in instrument.get("constructs", []):
        cname = c.get("name", "")
        for it in c.get("items", []):
            idx += 1
            lines.append(f"{idx}. [{cname}] {it}")
    items_txt = "\n".join(lines)
    user = (
        f"You are participating in a Delphi instrument validation study on: {topic}.\n"
        f"Context/problem: {problem_statement or '(none provided)'}\n"
        f"Round: {round_index}\n"
        f"{fb}\n"
        "Task: Rate each item on Relevance (1-5) and Clarity (1-5). Provide an edit suggestion if needed.\n\n"
        f"Items:\n{items_txt}\n\n"
        "Return ONLY JSON with schema: {\"ratings\": [{\"item_index\": 1, \"relevance\": 4, \"clarity\": 5, \"edit_suggestion\": \"...\"}, ...]}"
    )
    return [{"role": "user", "content": user}]


def prompt_round_scenario_drivers(topic: str, problem_statement: str, round_index: int, feedback: Optional[str] = None) -> List[Dict[str, str]]:
    fb = f"\n\nControlled group feedback (anonymized):\n{feedback}\n" if feedback else ""
    user = (
        f"You are participating in a Delphi scenario-building exercise on: {topic}.\n"
        f"Context/problem: {problem_statement or '(none provided)'}\n"
        f"Round: {round_index}\n"
        f"{fb}\n"
        "Task: Provide key drivers, critical uncertainties, and possible interactions that shape futures in this domain.\n\n"
        "Return ONLY JSON with schema: {\"drivers\": [\"...\"], \"critical_uncertainties\": [\"...\"], \"interactions\": [\"...\"]}"
    )
    return [{"role": "user", "content": user}]


def prompt_master_generate_scenarios(topic: str, time_horizon: str, driver_inputs: List[Dict[str, Any]], n_scenarios: int) -> List[Dict[str, str]]:
    joined = "\n\n".join([f"---\n{d}" for d in driver_inputs])
    user = (
        f"You are the Delphi facilitator. Topic: {topic}. Time horizon: {time_horizon}.\n"
        f"Task: Using the panel's inputs, generate {n_scenarios} distinct, plausible scenarios. Each scenario must include: "
        "(a) a short name, (b) 5-8 bullet narrative, (c) key drivers/assumptions, (d) signposts/indicators.\n\n"
        f"Panel inputs:\n{joined}\n\n"
        "Return ONLY JSON with schema: {\"scenarios\": [{\"name\":\"...\",\"narrative_bullets\":[\"...\"],\"drivers\":[\"...\"],\"signposts\":[\"...\"]}, ...]}"
    )
    return [{"role": "user", "content": user}]


def prompt_round_scenario_review(topic: str, scenarios: List[Dict[str, Any]], round_index: int, feedback: Optional[str] = None) -> List[Dict[str, str]]:
    fb = f"\n\nControlled group feedback (anonymized):\n{feedback}\n" if feedback else ""
    sc_lines = []
    for i, s in enumerate(scenarios, start=1):
        sc_lines.append(
            f"{i}. {s.get('name','Scenario')}\n" +
            "   " + " ".join(["- " + b for b in (s.get('narrative_bullets') or [])][:5])
        )
    sc_txt = "\n\n".join(sc_lines)
    user = (
        f"You are reviewing scenarios for a Delphi study on: {topic}.\n"
        f"Round: {round_index}\n"
        f"{fb}\n"
        "Task: For each scenario, rate Plausibility (1-5) and Internal Coherence (1-5), and provide critique and improvements.\n\n"
        f"Scenarios:\n{sc_txt}\n\n"
        "Return ONLY JSON with schema: {\"reviews\": [{\"scenario_index\": 1, \"plausibility\": 4, \"coherence\": 3, \"critique\": \"...\", \"improvements\": [\"...\"]}, ...]}"
    )
    return [{"role": "user", "content": user}]


def prompt_round_guidelines_elicit(topic: str, problem_statement: str, statements_per_agent: int, round_index: int, feedback: Optional[str] = None) -> List[Dict[str, str]]:
    fb = f"\n\nControlled group feedback (anonymized):\n{feedback}\n" if feedback else ""
    user = (
        f"You are participating in a Delphi policy/guideline study on: {topic}.\n"
        f"Context/problem: {problem_statement or '(none provided)'}\n"
        f"Round: {round_index}\n"
        f"{fb}\n"
        f"Task: Propose up to {statements_per_agent} guideline/policy recommendations. Each should be a clear, actionable statement. "
        "Provide a short rationale and any conditions/assumptions.\n\n"
        "Return ONLY JSON with schema: {\"statements\": [{\"text\":\"...\",\"rationale\":\"...\",\"conditions\":[\"...\"]}, ...]}"
    )
    return [{"role": "user", "content": user}]


def prompt_master_consolidate_statements(topic: str, raw_statements: List[str]) -> List[Dict[str, str]]:
    joined = "\n".join([f"- {s}" for s in raw_statements])
    user = (
        f"You are the Delphi facilitator. Topic: {topic}.\n"
        "Task: Consolidate the following recommendations by merging duplicates and standardizing wording. "
        "Do not invent new recommendations beyond merging and minor edits.\n\n"
        f"Statements:\n{joined}\n\n"
        "Return ONLY JSON with schema: {\"statements\": [\"...\", ...]}"
    )
    return [{"role": "user", "content": user}]


def prompt_round_guidelines_rating(topic: str, problem_statement: str, statements: List[str], round_index: int, feedback: Optional[str] = None) -> List[Dict[str, str]]:
    fb = f"\n\nControlled group feedback (anonymized):\n{feedback}\n" if feedback else ""
    st_txt = "\n".join([f"{i+1}. {s}" for i, s in enumerate(statements)])
    user = (
        f"You are participating in a Delphi guideline validation study on: {topic}.\n"
        f"Context/problem: {problem_statement or '(none provided)'}\n"
        f"Round: {round_index}\n"
        f"{fb}\n"
        "Task: For each statement, rate Acceptability (1-5) and Feasibility (1-5). Provide a brief critique and any suggested edits.\n\n"
        f"Statements:\n{st_txt}\n\n"
        "Return ONLY JSON with schema: {\"ratings\": [{\"statement_index\": 1, \"acceptability\": 4, \"feasibility\": 3, \"critique\": \"...\", \"edit_suggestion\": \"...\"}, ...]}"
    )
    return [{"role": "user", "content": user}]


# -------------------------
# Recursive reasoning template prompts
# -------------------------


def prompt_recursive_understanding(
    *,
    topic: str,
    problem_statement: str,
    questions: List[str],
    round_index: int = 1,
) -> List[Dict[str, str]]:
    """Round 1: participants explain their understanding and reasoning ONLY (no solutions)."""
    q_txt = "\n".join([f"{i+1}. {q}" for i, q in enumerate(questions)])
    user = (
        "You are a Delphi panelist in a recursive reasoning study.\n"
        f"Topic: {topic}\n"
        f"Problem statement: {problem_statement or '(none provided)'}\n"
        f"Round: {round_index} (UNDERSTANDING ONLY)\n\n"
        "Task:\n"
        "1) Explain how you understand the problem statement and the questions (interpretation, assumptions, framing).\n"
        "2) Explain your reasoning for this understanding (why you interpret it this way).\n\n"
        "Important constraints:\n"
        "- Do NOT propose solutions or answers in this round.\n"
        "- Do NOT critique other panelists (you have not seen them yet).\n\n"
        f"Questions:\n{q_txt}\n\n"
        'Return ONLY JSON with schema: {"understanding": "...", "reasoning": "..."}'
    )
    return [{"role": "user", "content": user}]


def prompt_master_recursive_understanding_digest(
    *,
    topic: str,
    problem_statement: str,
    questions: List[str],
    understandings: List[Dict[str, Any]],
) -> List[Dict[str, str]]:
    """Master collates Round 1 and prepares controlled feedback for Round 2."""
    q_txt = "\n".join([f"{i+1}. {q}" for i, q in enumerate(questions)])
    entries: List[str] = []
    for u in understandings:
        aid = str(u.get("agent_id", "")).strip() or "P"
        und = str(u.get("understanding", "")).strip()
        rea = str(u.get("reasoning", "")).strip()
        entries.append(f"[{aid}]\nUNDERSTANDING: {und}\nREASONING: {rea}")

    user = (
        "You are the Delphi master facilitator for a recursive reasoning study.\n"
        f"Topic: {topic}\n"
        f"Problem statement: {problem_statement or '(none provided)'}\n\n"
        "You have collected panelists' understanding of the problem/questions and their reasoning (Round 1).\n"
        "Collate these into controlled, anonymised group feedback for the next round.\n\n"
        f"Questions:\n{q_txt}\n\n"
        "Return ONLY JSON with schema: {\"summary\": \"...\", \"agreements\": [\"...\"], \"disagreements\": [\"...\"], \"missing_considerations\": [\"...\"], \"clarification_questions\": [\"...\"]}\n\n"
        "Panelist inputs (anonymised):\n" + "\n\n".join(entries)
    )
    return [{"role": "user", "content": user}]


def prompt_recursive_solution(
    *,
    topic: str,
    problem_statement: str,
    questions: List[str],
    understanding_digest: Dict[str, Any],
    round_index: int = 2,
) -> List[Dict[str, str]]:
    """Round 2: propose a solution/answer and reasoning after reviewing pooled understandings."""
    q_txt = "\n".join([f"{i+1}. {q}" for i, q in enumerate(questions)])
    digest_txt = json.dumps(understanding_digest, ensure_ascii=False, indent=2)
    user = (
        "You are a Delphi panelist in a recursive reasoning study.\n"
        f"Topic: {topic}\n"
        f"Problem statement: {problem_statement or '(none provided)'}\n"
        f"Round: {round_index} (PROPOSED SOLUTION)\n\n"
        "You have received anonymised group feedback summarising how the panel currently understands the problem/questions.\n"
        "Task:\n"
        "1) Review the digest.\n"
        "2) Propose a solution/answer that addresses the main interpretations and concerns raised.\n"
        "3) Provide your reasoning for the proposed solution.\n\n"
        f"Questions:\n{q_txt}\n\n"
        "Controlled group digest (Round 1):\n" + digest_txt + "\n\n"
        'Return ONLY JSON with schema: {"solution": "...", "reasoning": "..."}'
    )
    return [{"role": "user", "content": user}]


def prompt_master_recursive_solution_digest(
    *,
    topic: str,
    problem_statement: str,
    questions: List[str],
    solutions: List[Dict[str, Any]],
) -> List[Dict[str, str]]:
    """Master collates Round 2 solutions and prepares controlled feedback for Round 3."""
    q_txt = "\n".join([f"{i+1}. {q}" for i, q in enumerate(questions)])
    entries: List[str] = []
    for s in solutions:
        aid = str(s.get("agent_id", "")).strip() or "P"
        sol = str(s.get("solution", "")).strip()
        rea = str(s.get("reasoning", "")).strip()
        entries.append(f"[{aid}]\nSOLUTION: {sol}\nREASONING: {rea}")

    user = (
        "You are the Delphi master facilitator for a recursive reasoning study.\n"
        f"Topic: {topic}\n"
        f"Problem statement: {problem_statement or '(none provided)'}\n\n"
        "You have collected panelists' proposed solutions and reasoning (Round 2).\n"
        "Collate these into controlled, anonymised group feedback for the final round.\n\n"
        f"Questions:\n{q_txt}\n\n"
        "Return ONLY JSON with schema: {\"summary\": \"...\", \"agreements\": [\"...\"], \"disagreements\": [\"...\"], \"missing_considerations\": [\"...\"], \"clarification_questions\": [\"...\"]}\n\n"
        "Panelist inputs (anonymised):\n" + "\n\n".join(entries)
    )
    return [{"role": "user", "content": user}]


def prompt_recursive_final(
    *,
    topic: str,
    problem_statement: str,
    questions: List[str],
    solution_digest: Dict[str, Any],
    round_index: int = 3,
) -> List[Dict[str, str]]:
    """Round 3: propose final solution and reasoning after reviewing pooled solutions."""
    q_txt = "\n".join([f"{i+1}. {q}" for i, q in enumerate(questions)])
    digest_txt = json.dumps(solution_digest, ensure_ascii=False, indent=2)
    user = (
        "You are a Delphi panelist in a recursive reasoning study.\n"
        f"Topic: {topic}\n"
        f"Problem statement: {problem_statement or '(none provided)'}\n"
        f"Round: {round_index} (FINAL SOLUTION)\n\n"
        "You have received anonymised group feedback summarising proposed solutions and reasoning.\n"
        "Task:\n"
        "1) Review the digest.\n"
        "2) Propose your final solution/answer.\n"
        "3) Provide your final reasoning.\n\n"
        f"Questions:\n{q_txt}\n\n"
        "Controlled group digest (Round 2):\n" + digest_txt + "\n\n"
        'Return ONLY JSON with schema: {"final_solution": "...", "final_reasoning": "..."}'
    )
    return [{"role": "user", "content": user}]


def prompt_master_recursive_final_synthesis(
    *,
    topic: str,
    problem_statement: str,
    questions: List[str],
    understanding_digest: Dict[str, Any],
    solution_digest: Dict[str, Any],
    final_solutions: List[Dict[str, Any]],
) -> List[Dict[str, str]]:
    """Master produces final report after Round 3."""
    q_txt = "\n".join([f"{i+1}. {q}" for i, q in enumerate(questions)])
    entries: List[str] = []
    for s in final_solutions:
        aid = str(s.get("agent_id", "")).strip() or "P"
        sol = str(s.get("final_solution", "")).strip()
        rea = str(s.get("final_reasoning", "")).strip()
        entries.append(f"[{aid}]\nFINAL_SOLUTION: {sol}\nFINAL_REASONING: {rea}")

    user = (
        "You are the Delphi master facilitator. Produce the final recursive reasoning report.\n\n"
        f"Topic: {topic}\n"
        f"Problem statement: {problem_statement or '(none provided)'}\n\n"
        f"Questions:\n{q_txt}\n\n"
        "Inputs:\n"
        "- Round 1 digest (pooled understandings):\n" + json.dumps(understanding_digest, ensure_ascii=False, indent=2) + "\n\n"
        "- Round 2 digest (pooled proposed solutions):\n" + json.dumps(solution_digest, ensure_ascii=False, indent=2) + "\n\n"
        "- Round 3 final solutions (anonymised):\n" + "\n\n".join(entries) + "\n\n"
        "Task:\n"
        "1) Provide a concise synthesis summary.\n"
        "2) Provide a recommended answer/solution (integrated, professional).\n"
        "3) Explicitly note agreements and disagreements.\n"
        "4) Note convergences and divergences in reasoning.\n"
        "5) List any remaining open questions.\n\n"
        'Return ONLY JSON with schema: {"summary": "...", "recommended_answer": "...", "agreements": ["..."], "disagreements": ["..."], "convergences": ["..."], "divergences": ["..."], "open_questions": ["..."]}'
    )
    return [{"role": "user", "content": user}]


def append_guidance_to_last_user_message(messages: List[Dict[str, str]], guidance: str) -> List[Dict[str, str]]:
    """Append additional guidance to the final user message.

    Used to inject response-length policies, audit instructions, etc., without duplicating prompt templates.
    """
    if not guidance:
        return messages
    out = [dict(m) for m in messages]
    for i in range(len(out) - 1, -1, -1):
        if out[i].get("role") == "user":
            out[i]["content"] = (out[i].get("content") or "") + "\n\n" + guidance.strip() + "\n"
            break
    return out

def prompt_master_polish_report(sections: Dict[str, str]) -> List[Dict[str, str]]:
    """
    Ask the master model to do proofread-only polishing of the consultancy report sections.

    Hard constraint: do not paraphrase, add, remove, or reorder substantive content.
    Only correct obvious spelling/grammar/punctuation issues and improve line-break hygiene.
    """
    schema = {
        "title": "string",
        "date": "YYYY-MM-DD",
        "creator": "string",
        "abstract": "string",
        "method": "string",
        "participants": "string",
        "findings": "string",
        "appendix": "string (may be empty)",
    }
    sys = (
        "You are a professional copy editor preparing a consultancy-style report for Microsoft Word. "
        "You must follow these constraints strictly:\n"
        "1) Do NOT paraphrase or rewrite. Keep wording as close to the input as possible.\n"
        "2) You MAY correct obvious spelling errors, punctuation, capitalization, and minor grammar mistakes.\n"
        "3) Do NOT add new content. Do NOT remove content. Do NOT change technical meaning.\n"
        "4) Preserve structure markers: lines beginning with '##', '###', or '####' must remain exactly as headings (do not remove or rename them).\n"
        "5) Preserve bullets: lines beginning with '-' should remain bullets.\n"
        "6) If you are unsure about a change, leave the text unchanged.\n"
        "Return valid JSON ONLY, matching the schema exactly."
    )
    user = (
        "Below are report sections. Proofread each section (only minimal corrections) and return them in JSON.\n\n"
        f"SCHEMA: {json.dumps(schema)}\n\n"
        "INPUT SECTIONS (do not invent new sections):\n"
        f"TITLE:\n{sections.get('title','')}\n\n"
        f"DATE:\n{sections.get('date','')}\n\n"
        f"CREATOR:\n{sections.get('creator','')}\n\n"
        f"ABSTRACT:\n{sections.get('abstract','')}\n\n"
        f"METHOD:\n{sections.get('method','')}\n\n"
        f"PARTICIPANTS:\n{sections.get('participants','')}\n\n"
        f"FINDINGS:\n{sections.get('findings','')}\n\n"
        f"APPENDIX:\n{sections.get('appendix','')}\n"
    )
    return [{"role": "system", "content": sys}, {"role": "user", "content": user}]
