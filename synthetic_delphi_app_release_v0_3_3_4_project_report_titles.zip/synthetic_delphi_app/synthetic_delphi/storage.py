from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Literal


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


@dataclass
class SQLiteStore:
    """Thread-safe SQLite persistence layer.

    The Delphi runner uses ThreadPoolExecutor for parallel agent calls. SQLite itself can
    handle concurrent reads, but concurrent writes on a single connection require careful
    coordination. We therefore serialize access to the underlying connection with an RLock.
    """

    path: str

    def __post_init__(self) -> None:
        self._lock = threading.RLock()
        # check_same_thread=False is required because we write from worker threads.
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL;")
        self._conn.execute("PRAGMA foreign_keys=ON;")
        self._init_db()

    @classmethod
    def from_env(cls) -> "SQLiteStore":
        path = os.getenv("SYNTHETIC_DELPHI_DB", "synthetic_delphi.sqlite3")
        return cls(path=path)

    def _init_db(self) -> None:
        with self._lock:
            c = self._conn.cursor()
            c.executescript(
                """
                CREATE TABLE IF NOT EXISTS studies (
                    run_id TEXT PRIMARY KEY,
                    created_at TEXT,
                    spec_json TEXT,
                    config_json TEXT,
                    agents_json TEXT,
                    master_json TEXT
                );
                CREATE TABLE IF NOT EXISTS stages (
                    stage_id TEXT PRIMARY KEY,
                    run_id TEXT,
                    name TEXT,
                    status TEXT,
                    started_at TEXT,
                    finished_at TEXT,
                    details_json TEXT,
                    FOREIGN KEY(run_id) REFERENCES studies(run_id)
                );
                CREATE TABLE IF NOT EXISTS tasks (
                    task_id TEXT PRIMARY KEY,
                    run_id TEXT,
                    stage_id TEXT,
                    agent_id TEXT,
                    status TEXT,
                    started_at TEXT,
                    finished_at TEXT,
                    attempts INTEGER,
                    error TEXT,
                    usage_json TEXT,
                    FOREIGN KEY(run_id) REFERENCES studies(run_id),
                    FOREIGN KEY(stage_id) REFERENCES stages(stage_id)
                );
                CREATE TABLE IF NOT EXISTS messages (
                    msg_id TEXT PRIMARY KEY,
                    run_id TEXT,
                    stage_id TEXT,
                    agent_id TEXT,
                    role TEXT,
                    content TEXT,
                    created_at TEXT,
                    FOREIGN KEY(run_id) REFERENCES studies(run_id)
                );
                CREATE TABLE IF NOT EXISTS events (
                    event_id TEXT PRIMARY KEY,
                    run_id TEXT,
                    ts TEXT,
                    kind TEXT,
                    payload_json TEXT,
                    FOREIGN KEY(run_id) REFERENCES studies(run_id)
                );
                CREATE TABLE IF NOT EXISTS artifacts (
                    artifact_id TEXT PRIMARY KEY,
                    run_id TEXT,
                    name TEXT,
                    created_at TEXT,
                    artifact_json TEXT,
                    FOREIGN KEY(run_id) REFERENCES studies(run_id)
                );
                """
            )
            self._conn.commit()

    def create_study(
        self,
        run_id: str,
        spec: Dict[str, Any],
        config: Dict[str, Any],
        agents: List[Dict[str, Any]],
        master: Dict[str, Any],
    ) -> None:
        with self._lock:
            self._conn.execute(
                "INSERT OR REPLACE INTO studies(run_id, created_at, spec_json, config_json, agents_json, master_json) VALUES (?, ?, ?, ?, ?, ?)",
                (run_id, _now_iso(), json.dumps(spec), json.dumps(config), json.dumps(agents), json.dumps(master)),
            )
            self._conn.commit()

    def upsert_stage(
        self,
        stage_id: str,
        run_id: str,
        name: str,
        status: str,
        details: Optional[Dict[str, Any]] = None,
        started_at: Optional[str] = None,
        finished_at: Optional[str] = None,
    ) -> None:
        details_json = json.dumps(details or {})
        with self._lock:
            self._conn.execute(
                """INSERT OR REPLACE INTO stages(stage_id, run_id, name, status, started_at, finished_at, details_json)
                     VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (stage_id, run_id, name, status, started_at, finished_at, details_json),
            )
            self._conn.commit()

    def list_stages(self, run_id: str) -> List[Dict[str, Any]]:
        with self._lock:
            cur = self._conn.execute(
                "SELECT stage_id, name, status, started_at, finished_at, details_json FROM stages WHERE run_id=? ORDER BY started_at",
                (run_id,),
            )
            rows = cur.fetchall()
        out: List[Dict[str, Any]] = []
        for row in rows:
            out.append(
                {
                    "stage_id": row[0],
                    "name": row[1],
                    "status": row[2],
                    "started_at": row[3],
                    "finished_at": row[4],
                    "details": json.loads(row[5] or "{}"),
                }
            )
        return out

    def upsert_task(
        self,
        task_id: str,
        run_id: str,
        stage_id: str,
        agent_id: str,
        status: str,
        started_at: Optional[str] = None,
        finished_at: Optional[str] = None,
        attempts: int = 0,
        error: str = "",
        usage: Optional[Dict[str, Any]] = None,
    ) -> None:
        with self._lock:
            self._conn.execute(
                """INSERT OR REPLACE INTO tasks(task_id, run_id, stage_id, agent_id, status, started_at, finished_at, attempts, error, usage_json)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (task_id, run_id, stage_id, agent_id, status, started_at, finished_at, attempts, error, json.dumps(usage or {})),
            )
            self._conn.commit()

    def log_message(self, msg_id: str, run_id: str, stage_id: str, agent_id: str, role: str, content: str) -> None:
        with self._lock:
            self._conn.execute(
                "INSERT OR REPLACE INTO messages(msg_id, run_id, stage_id, agent_id, role, content, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (msg_id, run_id, stage_id, agent_id, role, content, _now_iso()),
            )
            self._conn.commit()

    def log_event(self, event_id: str, run_id: str, kind: str, payload: Dict[str, Any]) -> None:
        with self._lock:
            self._conn.execute(
                "INSERT OR REPLACE INTO events(event_id, run_id, ts, kind, payload_json) VALUES (?, ?, ?, ?, ?)",
                (event_id, run_id, _now_iso(), kind, json.dumps(payload)),
            )
            self._conn.commit()

    def list_events(self, run_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        with self._lock:
            cur = self._conn.execute(
                "SELECT ts, kind, payload_json FROM events WHERE run_id=? ORDER BY ts DESC LIMIT ?",
                (run_id, limit),
            )
            rows = cur.fetchall()
        out: List[Dict[str, Any]] = []
        for ts, kind, payload_json in rows:
            out.append({"ts": ts, "kind": kind, "payload": json.loads(payload_json or "{}")})
        return out

    def save_artifact(self, artifact_id: str, run_id: str, name: str, artifact: Dict[str, Any]) -> None:
        with self._lock:
            self._conn.execute(
                "INSERT OR REPLACE INTO artifacts(artifact_id, run_id, name, created_at, artifact_json) VALUES (?, ?, ?, ?, ?)",
                (artifact_id, run_id, name, _now_iso(), json.dumps(artifact)),
            )
            self._conn.commit()

    def get_artifact(self, run_id: str, name: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            cur = self._conn.execute(
                "SELECT artifact_json FROM artifacts WHERE run_id=? AND name=? ORDER BY created_at DESC LIMIT 1",
                (run_id, name),
            )
            row = cur.fetchone()
        if not row:
            return None
        return json.loads(row[0])

    # Backwards-compatible alias.
    # Earlier versions of the Streamlit UI called this `load_artifact`.
    def load_artifact(self, run_id: str, name: str) -> Optional[Dict[str, Any]]:
        return self.get_artifact(run_id=run_id, name=name)


    def list_tasks(self, run_id: str, stage_id: Optional[str] = None, agent_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """List task records for audit/inspection."""
        where = ['run_id=?']
        params: List[Any] = [run_id]
        if stage_id:
            where.append('stage_id=?')
            params.append(stage_id)
        if agent_id:
            where.append('agent_id=?')
            params.append(agent_id)
        sql = (
            'SELECT task_id, stage_id, agent_id, status, started_at, finished_at, attempts, error, usage_json '
            f"FROM tasks WHERE {' AND '.join(where)} ORDER BY started_at"
        )
        with self._lock:
            cur = self._conn.execute(sql, tuple(params))
            rows = cur.fetchall()
        out: List[Dict[str, Any]] = []
        for r in rows:
            out.append(
                {
                    'task_id': r[0],
                    'stage_id': r[1],
                    'agent_id': r[2],
                    'status': r[3],
                    'started_at': r[4],
                    'finished_at': r[5],
                    'attempts': r[6],
                    'error': r[7],
                    'usage': json.loads(r[8] or '{}'),
                }
            )
        return out

    def list_messages(
        self,
        run_id: str,
        stage_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        limit: Optional[int] = None,
        order: Literal['ASC', 'DESC'] = 'ASC',
    ) -> List[Dict[str, Any]]:
        """List stored chat messages.

        This is intentionally raw: it contains the exact prompt/response content written by the runner.
        """
        where = ['run_id=?']
        params: List[Any] = [run_id]
        if stage_id:
            where.append('stage_id=?')
            params.append(stage_id)
        if agent_id:
            where.append('agent_id=?')
            params.append(agent_id)
        lim = ''
        if limit:
            lim = ' LIMIT ?'
            params.append(limit)
        sql = (
            'SELECT msg_id, stage_id, agent_id, role, content, created_at '
            f"FROM messages WHERE {' AND '.join(where)} ORDER BY created_at {order}{lim}"
        )
        with self._lock:
            cur = self._conn.execute(sql, tuple(params))
            rows = cur.fetchall()
        return [
            {
                'msg_id': r[0],
                'stage_id': r[1],
                'agent_id': r[2],
                'role': r[3],
                'content': r[4],
                'created_at': r[5],
            }
            for r in rows
        ]

    def get_study_record(self, run_id: str) -> Optional[Dict[str, Any]]:
        """Fetch the stored study inputs (spec/config/agents/master)."""
        with self._lock:
            cur = self._conn.execute(
                'SELECT created_at, spec_json, config_json, agents_json, master_json FROM studies WHERE run_id=?',
                (run_id,),
            )
            row = cur.fetchone()
        if not row:
            return None
        return {
            'run_id': run_id,
            'created_at': row[0],
            'spec': json.loads(row[1] or '{}'),
            'config': json.loads(row[2] or '{}'),
            'agents': json.loads(row[3] or '[]'),
            'master': json.loads(row[4] or '{}'),
        }

    def list_artifacts(self, run_id: str):
        """List artifacts saved for a run."""
        with self._lock:
            cur = self._conn.execute(
                "SELECT artifact_id, name, created_at FROM artifacts WHERE run_id=? ORDER BY created_at ASC",
                (run_id,),
            )
            rows = cur.fetchall()
        return [
            {"artifact_id": r[0], "name": r[1], "created_at": r[2]}
            for r in rows
        ]


    def close(self) -> None:
        try:
            with self._lock:
                self._conn.close()
        except Exception:
            pass
