from __future__ import annotations

import json
import os
import re
import hashlib
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Protocol, Tuple

import requests


@dataclass
class ChatResult:
    content: str
    raw: Dict[str, Any]
    usage: Dict[str, Any]


class Provider(Protocol):
    def chat(
        self,
        messages: List[Dict[str, str]],
        *,
        model: str,
        api_key: Optional[str],
        base_url: str,
        temperature: float,
        max_tokens: int,
        timeout_s: int,
        reasoning_effort: Optional[str] = None,
        verbosity: Optional[str] = None,
        user_tag: Optional[str] = None,
    ) -> ChatResult:
        ...


class OpenAICompatibleProvider:
    def __init__(self, session: Optional[requests.Session] = None) -> None:
        self._session = session or requests.Session()

    @staticmethod
    def _stable_tag(tag: str, n: int = 24) -> str:
        """Create a short, stable identifier safe to send to providers.

        We avoid sending raw tags because some providers deprecate/disable the old
        `user` field and/or have stricter limits on identifier formats.
        """
        h = hashlib.sha256(tag.encode("utf-8")).hexdigest()
        return h[: max(8, min(n, len(h)))]

    @staticmethod
    def _extract_http_error(resp: requests.Response) -> str:
        req_id = resp.headers.get("x-request-id") or resp.headers.get("x-request_id")
        detail = ""
        try:
            j = resp.json()
            err = j.get("error") if isinstance(j, dict) else None
            if isinstance(err, dict):
                msg = err.get("message") or ""
                code = err.get("code")
                etype = err.get("type")
                param = err.get("param")
                parts = [p for p in [msg, f"code={code}" if code else None, f"type={etype}" if etype else None, f"param={param}" if param else None] if p]
                detail = "; ".join(parts)
            else:
                detail = json.dumps(j)[:2000]
        except Exception:
            detail = (resp.text or "").strip()[:2000]
        if req_id:
            detail = f"{detail} (request_id={req_id})".strip()
        return detail or "HTTP request failed."

    @staticmethod
    def _endpoint(base_url: str) -> str:
        base_url = base_url.rstrip("/")
        # Accept either https://api.openai.com or https://api.openai.com/v1
        # and avoid duplicating /v1.
        if base_url.endswith("/v1/chat/completions"):
            return base_url
        if base_url.endswith("/v1"):
            return f"{base_url}/chat/completions"
        return f"{base_url}/v1/chat/completions"

    def chat(
        self,
        messages: List[Dict[str, str]],
        *,
        model: str,
        api_key: Optional[str],
        base_url: str,
        temperature: float,
        max_tokens: int,
        timeout_s: int,
        reasoning_effort: Optional[str] = None,
        verbosity: Optional[str] = None,
        user_tag: Optional[str] = None,
    ) -> ChatResult:
        key = api_key or os.getenv("OPENAI_API_KEY") or os.getenv("OPENAI_APIKEY")
        if not key:
            raise RuntimeError("Missing API key. Provide per-agent key or set OPENAI_API_KEY env var.")
        url = self._endpoint(base_url)
        headers = {
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
        }
        msgs = list(messages)
        # The Chat Completions API does not currently expose a dedicated "verbosity" parameter.
        # If the user sets verbosity, we apply it as a system-level instruction.
        if verbosity:
            v = str(verbosity).strip().lower()
            if v in {"low", "medium", "high"}:
                hint = {
                    "low": "Verbosity preference: LOW. Answer concisely and avoid unnecessary detail.",
                    "medium": "Verbosity preference: MEDIUM. Provide a balanced, moderately detailed answer.",
                    "high": "Verbosity preference: HIGH. Provide a thorough, detailed answer with clear structure.",
                }[v]
                msgs = msgs + [{"role": "system", "content": hint}]

        payload: Dict[str, Any] = {
            "model": model,
            "messages": msgs,
            # max_tokens is deprecated and not compatible with some newer reasoning models.
            # Use max_completion_tokens when available.
            "max_completion_tokens": max_tokens,
        }

        # Some newer models (notably GPT-5 family) only support the default temperature (often 1.0).
        # We therefore:
        #   (a) avoid sending temperature for GPT-5* unless it is exactly 1.0, and
        #   (b) for other models, only send temperature when it differs from the default.
        try:
            if temperature is not None:
                t = float(temperature)
                if str(model).lower().startswith("gpt-5"):
                    # Let the model default apply (OpenAI rejects non-default temps for these models).
                    if t == 1.0:
                        payload["temperature"] = 1.0
                else:
                    if t != 1.0:
                        payload["temperature"] = t
        except Exception:
            # If parsing fails, omit temperature.
            pass
        if reasoning_effort:
            payload["reasoning_effort"] = reasoning_effort
        if user_tag:
            stable = self._stable_tag(user_tag)
            # Some OpenAI-compatible providers have replaced/deprecated the legacy `user` field.
            payload["prompt_cache_key"] = stable
            payload["safety_identifier"] = stable
            # Do NOT send `metadata` to the OpenAI Chat Completions endpoint unless `store=true`.
            # (OpenAI rejects metadata otherwise.) We keep all tagging/audit locally.

        # Do not force response_format because not all OpenAI-compatible providers support it.
        resp = self._session.post(url, headers=headers, json=payload, timeout=timeout_s)

        # Best-effort fallback for OpenAI-compatible providers with narrower parameter support.
        if resp.status_code == 400:
            msg = ""
            err_param: Optional[str] = None
            try:
                j = resp.json()
                err = j.get("error") if isinstance(j, dict) else None
                msg = json.dumps(err or j)
                if isinstance(err, dict):
                    err_param = err.get("param")
            except Exception:
                msg = resp.text or ""
            msg_l = msg.lower()

            # Retry without optional knobs that might be unsupported.
            remove: List[str] = []
            optional = {"reasoning_effort", "prompt_cache_key", "safety_identifier", "metadata", "max_completion_tokens", "temperature"}

            # If the provider explicitly flags a param, remove it.
            if err_param in optional:
                remove.append(err_param)

            # Some OpenAI errors are specific (e.g., metadata allowed only when store=true) and
            # won't include "unknown parameter". Detect these and drop the offending field.
            if "metadata" in msg_l and "only allowed" in msg_l and "store" in msg_l:
                remove.append("metadata")

            # Some OpenAI models only support default temperature and will error on non-default.
            if "temperature" in msg_l and ("only the default" in msg_l or "only the default (1)" in msg_l):
                remove.append("temperature")

            # Heuristic: many providers include the parameter name in the message when unsupported.
            if any(k in msg_l for k in ["unknown parameter", "unrecognized", "unsupported", "invalid parameter", "unexpected"]):
                for k in sorted(optional):
                    if k in msg_l:
                        remove.append(k)

            # De-dup
            remove = list(dict.fromkeys(remove))

            if remove:
                payload2 = dict(payload)
                for k in remove:
                    payload2.pop(k, None)
                # If a provider doesn't support max_completion_tokens, fall back to legacy max_tokens.
                if "max_completion_tokens" in remove:
                    payload2["max_tokens"] = max_tokens
                resp = self._session.post(url, headers=headers, json=payload2, timeout=timeout_s)

        if resp.status_code >= 400:
            raise RuntimeError(f"{resp.status_code} {resp.reason}: {self._extract_http_error(resp)}")

        data = resp.json()
        content = data["choices"][0]["message"]["content"]
        usage = data.get("usage", {})
        return ChatResult(content=content, raw=data, usage=usage)


class MockProvider:
    """Deterministic provider for tests/offline use.

    It recognizes expected JSON schemas in prompts and returns valid JSON accordingly.
    """

    def chat(
        self,
        messages: List[Dict[str, str]],
        *,
        model: str,
        api_key: Optional[str],
        base_url: str,
        temperature: float,
        max_tokens: int,
        timeout_s: int,
        reasoning_effort: Optional[str] = None,
        verbosity: Optional[str] = None,
        user_tag: Optional[str] = None,
    ) -> ChatResult:
        user = "\n".join([m["content"] for m in messages if m["role"] == "user"])
        content = self._respond(user)
        return ChatResult(content=content, raw={"mock": True}, usage={"mock_tokens": len(content)})

    def _respond(self, prompt: str) -> str:
        # Expert list JSON
        if "Make a list of famous people" in prompt and "categories" in prompt:
            return json.dumps({"categories": [{"name": "Economist", "people": ["Alice Econ", "Bob Econ", "Cara Econ"]}]})
        if "Return ONLY JSON with schema: {\"system_prompt\"" in prompt:
            return json.dumps({"system_prompt": "You are a simulated expert. Respond thoughtfully and concisely."})
        if "Propose" in prompt and "\"items\"" in prompt and "candidate items" in prompt:
            items = []
            for i in range(1, 7):
                items.append({"text": f"Item {i}", "rationale": f"Rationale {i}"})
            return json.dumps({"items": items})
        if "Consolidate the following items" in prompt:
            # return unique items from bullet list
            bullets = [ln.strip()[2:].strip() for ln in prompt.splitlines() if ln.strip().startswith("- ")]
            uniq = []
            for b in bullets:
                if b and b not in uniq:
                    uniq.append(b)
            return json.dumps({"items": uniq[:10]})
        if "\"ratings\"" in prompt and "Rate each item" in prompt:
            # Parse number of items
            n = len(re.findall(r"^\d+\.\s", prompt, flags=re.M))
            ratings = []
            for i in range(1, n + 1):
                ratings.append({"item_index": i, "scores": {"Importance": 5}, "justification": "Because."})
            return json.dumps({"ratings": ratings, "overall_comment": "OK"})
        if "Prepare controlled feedback" in prompt and "\"feedback\"" in prompt:
            return json.dumps({"feedback": "Group median ratings are stable; consider dispersion on a few items."})
        if "Return your answers in JSON ONLY" in prompt and "\"answers\"" in prompt:
            qn = len(re.findall(r"^\d+\.\s", prompt, flags=re.M))
            answers = [{"question_index": i, "answer": f"Answer {i}"} for i in range(1, qn + 1)]
            return json.dumps({"answers": answers})
        if "prepare controlled feedback" in prompt and "\"summary\"" in prompt:
            return json.dumps({"summary": "Summary.", "followups": ["Follow-up 1"]})
        
        # Forecasting
        if "Forecasting Round" in prompt and '"forecasts"' in prompt:
            qn = len(re.findall(r"^\d+\.\s", prompt, flags=re.M))
            forecasts = []
            for i in range(1, qn + 1):
                forecasts.append({
                    "question_index": i,
                    "probability": 60.0,
                    "confidence": 3,
                    "rationale": "Mock rationale."
                })
            return json.dumps({"forecasts": forecasts})

        # Priority ranking
        if ("Rank the items" in prompt or "ranked_item_indices" in prompt) and '"ranked_item_indices"' in prompt:
            n = len(re.findall(r"^\d+\.\s", prompt, flags=re.M))
            ranked = list(range(1, n + 1))
            return json.dumps({"ranked_item_indices": ranked, "rationale": "Mock ranking rationale."})

        # Sensemaking
        if "Problem scoping / sensemaking" in prompt and '"glossary"' in prompt:
            return json.dumps({
                "glossary": [{"term": "Term", "definition": "Definition."}],
                "assumptions": ["Assumption 1"],
                "boundaries": {"in_scope": ["In-scope 1"], "out_of_scope": ["Out-of-scope 1"]},
                "uncertainties": ["Uncertainty 1"]
            })
        if "consolidate the panel sensemaking" in prompt and '"scope_map"' in prompt:
            return json.dumps({
                "scope_map": {
                    "glossary": [{"term": "Term", "definition": "Definition."}],
                    "assumptions": ["Assumption 1"],
                    "in_scope": ["In-scope 1"],
                    "out_of_scope": ["Out-of-scope 1"],
                    "uncertainties": ["Uncertainty 1"],
                    "notes": "Mock notes."
                }
            })

        # Guidelines / criteria statements
        if "Generate policy / guideline statements" in prompt and '"statements"' in prompt:
            stmts = []
            for i in range(1, 6):
                stmts.append({"text": f"Statement {i}", "rationale": "Because."})
            return json.dumps({"statements": stmts})
        if "Consolidate and rewrite the following statements" in prompt:
            bullets = [ln.strip()[2:].strip() for ln in prompt.splitlines() if ln.strip().startswith("- ")]
            uniq = []
            for b in bullets:
                if b and b not in uniq:
                    uniq.append(b)
            return json.dumps({"statements": uniq[:10]})
        if "Rate each statement" in prompt and '"ratings"' in prompt and "acceptability" in prompt.lower():
            n = len(re.findall(r"^\d+\.\s", prompt, flags=re.M))
            ratings = []
            for i in range(1, n + 1):
                ratings.append({
                    "statement_index": i,
                    "acceptability": 4,
                    "feasibility": 4,
                    "critique": "OK.",
                    "edit_suggestion": ""
                })
            return json.dumps({"ratings": ratings})

        # Risk register
        if "Identify key risks" in prompt and '"risks"' in prompt:
            risks = []
            for i in range(1, 4):
                risks.append({
                    "risk": f"Risk {i}",
                    "causes": ["Cause"],
                    "impacts": ["Impact"],
                    "mitigations": ["Mitigation"]
                })
            return json.dumps({"risks": risks})
        if "Consolidate the risks" in prompt and '"risks"' in prompt:
            return json.dumps({"risks": [{"risk_id": "R1", "risk": "Risk 1", "causes": ["Cause"], "impacts": ["Impact"], "mitigations": ["Mitigation"]}]})
        if "Rate each risk" in prompt and '"ratings"' in prompt:
            n = len(re.findall(r"^\d+\.\s", prompt, flags=re.M))
            ratings = []
            for i in range(1, n + 1):
                ratings.append({"risk_index": i, "likelihood": 3, "impact": 4, "justification": "Mock."})
            return json.dumps({"ratings": ratings})

        # Instrument development
        if "Propose measurement items" in prompt and '"items"' in prompt:
            # Create a small set of items without parsing constructs
            items = [
                {"construct": "Construct 1", "item_text": "I do X.", "rationale": "Measures X."},
                {"construct": "Construct 1", "item_text": "I can Y.", "rationale": "Measures Y."},
            ]
            return json.dumps({"items": items})
        if "Consolidate these items into a draft instrument" in prompt and '"instrument"' in prompt:
            return json.dumps({"instrument": {"constructs": [{"name": "Construct 1", "items": ["I do X.", "I can Y."]}]}})
        if "Rate each instrument item" in prompt and '"ratings"' in prompt:
            n = len(re.findall(r"^\d+\.\s", prompt, flags=re.M))
            ratings = []
            for i in range(1, n + 1):
                ratings.append({"item_index": i, "relevance": 4, "clarity": 4, "edit_suggestion": ""})
            return json.dumps({"ratings": ratings})

        # Scenarios
        if "List the most important drivers" in prompt and '"drivers"' in prompt:
            return json.dumps({
                "drivers": [{"name": "Driver 1", "description": "Desc", "direction": "Increase"}],
                "critical_uncertainties": [{"name": "Uncertainty 1", "poles": ["High", "Low"]}]
            })
        if "Generate" in prompt and "scenarios" in prompt and '"scenarios"' in prompt:
            scenarios = []
            for i in range(1, 4):
                scenarios.append({"name": f"Scenario {i}", "narrative": "Narrative", "key_signals": ["Signal"], "implications": ["Implication"]})
            return json.dumps({"scenarios": scenarios})
        if "Review each scenario" in prompt and '"reviews"' in prompt:
            n = len(re.findall(r"^\d+\.\s", prompt, flags=re.M))
            reviews = []
            for i in range(1, n + 1):
                reviews.append({"scenario_index": i, "plausibility": 4, "coherence": 4, "missing_elements": "", "improvements": ""})
            return json.dumps({"reviews": reviews})



        # Recursive reasoning template
        if "recursive reasoning study" in prompt and "UNDERSTANDING ONLY" in prompt and '"understanding"' in prompt:
            return json.dumps({"understanding": "Mock understanding of the problem and questions.", "reasoning": "Mock reasoning for that interpretation."})
        if "recursive reasoning study" in prompt and "PROPOSED SOLUTION" in prompt and '"solution"' in prompt:
            return json.dumps({"solution": "Mock proposed solution addressing the pooled interpretations.", "reasoning": "Mock reasoning supporting the proposed solution."})
        if "recursive reasoning study" in prompt and "FINAL SOLUTION" in prompt and '"final_solution"' in prompt:
            return json.dumps({"final_solution": "Mock final solution.", "final_reasoning": "Mock final reasoning."})
        if "recursive reasoning report" in prompt and '"recommended_answer"' in prompt:
            return json.dumps({
                "summary": "Mock synthesis summary.",
                "recommended_answer": "Mock recommended answer.",
                "agreements": ["Mock agreement"],
                "disagreements": ["Mock disagreement"],
                "convergences": ["Mock convergence"],
                "divergences": ["Mock divergence"],
                "open_questions": ["Mock open question"],
            })
        if "recursive reasoning" in prompt and '"missing_considerations"' in prompt and '"clarification_questions"' in prompt:
            return json.dumps({
                "summary": "Mock digest summary.",
                "agreements": ["Mock agreement"],
                "disagreements": ["Mock disagreement"],
                "missing_considerations": ["Mock missing consideration"],
                "clarification_questions": ["Mock clarification question"],
            })
        # Report polishing (proofread-only)
        if "INPUT SECTIONS" in prompt and "ABSTRACT:" in prompt and "FINDINGS:" in prompt and '"abstract"' in prompt.lower():
            def grab(label: str) -> str:
                m = re.search(rf"{label}:\n(.*?)(?=\n\n[A-Z_ ]+:\n|\Z)", prompt, flags=re.S)
                return (m.group(1).strip() if m else "")
            obj = {
                "title": grab("TITLE"),
                "date": grab("DATE"),
                "creator": grab("CREATOR"),
                "abstract": grab("ABSTRACT"),
                "method": grab("METHOD"),
                "participants": grab("PARTICIPANTS"),
                "findings": grab("FINDINGS"),
                "appendix": grab("APPENDIX"),
            }
            return json.dumps(obj)

        # default
        return json.dumps({"note": "mock"})