# Launch Synthetic Delphi (Streamlit) and open a NEW browser window.
# Note: Browser pop-up policies vary. This script uses explicit "new window" flags where possible.
# Usage: .\Launch_Synthetic_Delphi.ps1

$ErrorActionPreference = 'Stop'

$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $AppDir

# Prefer 'py' launcher if available, else 'python'
$pythonCmd = $null
if (Get-Command py -ErrorAction SilentlyContinue) {
    $pythonCmd = 'py'
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    $pythonCmd = 'python'
} else {
    throw 'Python not found on PATH. Install Python 3.x and ensure it is available as py or python.'
}

$port = 8501
$url = "http://localhost:$port/?window=1"

Write-Host "Starting Synthetic Delphi from: $AppDir"

# Start Streamlit (do not auto-open a browser tab)
Start-Process -FilePath $pythonCmd -WorkingDirectory $AppDir -ArgumentList @(
    '-m','streamlit','run','app.py',
    '--server.port',"$port",
    '--browser.gatherUsageStats','false'
) | Out-Null

# Wait for the server to respond (best-effort)
$maxWaitSeconds = 30
for ($i = 0; $i -lt $maxWaitSeconds; $i++) {
    try {
        Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 2 | Out-Null
        break
    } catch {
        Start-Sleep -Seconds 1
    }
}

# Open in a new window (Edge/Chrome/Firefox), else fall back to default handler
if (Get-Command msedge -ErrorAction SilentlyContinue) {
    Start-Process -FilePath 'msedge' -ArgumentList @('--new-window', $url) | Out-Null
} elseif (Get-Command chrome -ErrorAction SilentlyContinue) {
    Start-Process -FilePath 'chrome' -ArgumentList @('--new-window', $url) | Out-Null
} elseif (Get-Command firefox -ErrorAction SilentlyContinue) {
    Start-Process -FilePath 'firefox' -ArgumentList @('-new-window', $url) | Out-Null
} else {
    Start-Process $url | Out-Null
}
