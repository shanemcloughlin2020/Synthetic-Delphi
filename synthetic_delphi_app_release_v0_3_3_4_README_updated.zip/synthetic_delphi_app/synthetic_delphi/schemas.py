from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field, field_validator, AliasChoices


ProviderKind = Literal["openai_compat", "anthropic_compat", "google_compat", "local_http", "mock"]

# OpenAI reasoning/verbosity knobs are optional; many gateways ignore/deny them.
ReasoningEffort = Literal["none", "minimal", "low", "medium", "high", "xhigh"]
Verbosity = Literal["low", "medium", "high"]


class WordCountSpec(BaseModel):
    """Word-count guidance for model outputs.

    Notes:
    - Word counts are measured over natural language content (not tokens).
    - If `strict=True`, the runner will auto-reprompt to bring the output into range.
    """

    min_words: Optional[int] = Field(default=None, ge=0)
    target_words: Optional[int] = Field(default=None, ge=0)
    max_words: Optional[int] = Field(default=None, ge=0)
    strict: bool = False

    def is_configured(self) -> bool:
        return any(x is not None and x > 0 for x in (self.min_words, self.target_words, self.max_words))


class ResponsePolicy(BaseModel):
    """Response formatting policy.

    The runner uses this primarily to:
    1) Inject clear length guidance into prompts.
    2) Optionally enforce the overall word-count range via auto-reprompt (`overall.strict=True`).

    `field_policies` is guidance-only (injected into prompts) so you can communicate per-field
    expectations (e.g., justification lengths) without breaking schemas.
    """

    overall: WordCountSpec = Field(default_factory=WordCountSpec)
    field_policies: Dict[str, WordCountSpec] = Field(default_factory=dict)
    notes: str = ""


class AgentProfile(BaseModel):
    agent_id: str = Field(..., description="Stable id used for storage and task assignment.")
    name: str = Field(..., min_length=1)
    provider: ProviderKind = "openai_compat"
    base_url: str = Field(
        "https://api.openai.com",
        description="Base URL for OpenAI-compatible providers.",
        validation_alias=AliasChoices("base_url", "api_base_url", "apiBaseUrl"),
    )
    model: str = Field("gpt-4o-mini", description="Model identifier for provider.")
    api_key: Optional[str] = Field(default=None, description="API key for this agent. If omitted, env var may be used.")

    # Panel / persona fields (used when AI-Delphi modes build system prompts)
    discipline: str = Field("", description="Optional: discipline/professional role (Persona Panel).")
    persona_name: str = Field("", description="Optional: named persona (Iconic Minds).")
    persona_description: str = Field("", description="Optional: persona description (Persona Panel / Iconic Minds).")

    system_prompt: str = Field("", description="Additional persona prompt (system).")

    # Optional model knobs (best-effort; may be ignored by non-OpenAI providers)
    reasoning_effort: Optional[ReasoningEffort] = None
    verbosity: Optional[Verbosity] = None

    temperature: float = Field(0.4, ge=0.0, le=2.0)
    max_tokens: int = Field(1200, ge=128, le=32000)
    timeout_s: int = Field(90, ge=5, le=600)
    enabled: bool = True

    @field_validator("base_url")
    @classmethod
    def _strip_trailing_slash(cls, v: str) -> str:
        return v.rstrip("/")


class MasterAgentConfig(BaseModel):
    """Master facilitator configuration."""

    name: str = "Master Researcher"
    provider: ProviderKind = "openai_compat"
    base_url: str = Field(
        "https://api.openai.com",
        validation_alias=AliasChoices("base_url", "api_base_url", "apiBaseUrl"),
    )
    model: str = "gpt-4o-mini"
    api_key: Optional[str] = None

    # Optional model knobs
    reasoning_effort: Optional[ReasoningEffort] = None
    verbosity: Optional[Verbosity] = None

    system_prompt: str = (
        "You are a rigorous research facilitator for a Delphi study. "
        "You must be neutral, transparent, and never fabricate numbers."
    )
    temperature: float = 0.2
    max_tokens: int = 1600
    timeout_s: int = 120

    @field_validator("base_url")
    @classmethod
    def _strip_trailing_slash(cls, v: str) -> str:
        return v.rstrip("/")


class RatingDimension(BaseModel):
    name: str = Field(..., min_length=1)
    description: str = ""
    scale_min: int = 1
    scale_max: int = 7
    min_label: str = "Low"
    max_label: str = "High"

    @field_validator("scale_max")
    @classmethod
    def _max_gt_min(cls, v: int, info):
        # scale_min not accessible reliably in this context; validate later.
        return v


class ForecastQuestion(BaseModel):
    """A forecasting question. MVP focuses on binary probability questions."""

    question_id: str
    text: str
    kind: Literal["binary"] = "binary"


DelphiTemplate = Literal[
    "item_rating",
    "questionnaire_ai_delphi",
    "forecasting",
    "priority_ranking",
    "sensemaking",
    "idea_generation",
    "criteria_standards",
    "scenario_building",
    "policy_guidelines",
    "risk_register",
    "instrument_development",
    "recursive_reasoning",
]

AIDelphiModel = Literal["iconic_minds", "persona_panel", "digital_oracle"]


class DelphiConfig(BaseModel):
    template: DelphiTemplate = "item_rating"
    ai_delphi_model: AIDelphiModel = "digital_oracle"

    @field_validator("ai_delphi_model", mode="before")
    @classmethod
    def _coerce_ai_delphi_model(cls, v):
        # Backward compatibility: older UI used 'generic'
        if v in (None, "", "generic", "default"):
            return "digital_oracle"
        return v

    max_rounds: int = Field(3, ge=1, le=6)
    min_rounds: int = Field(2, ge=1, le=6)

    quorum_fraction: float = Field(0.7, gt=0.0, le=1.0)
    stage_deadline_s: int = Field(240, ge=30, le=3600)
    retries: int = Field(1, ge=0, le=5)

    # Item-rating stopping criteria
    consensus_iqr_threshold: float = Field(1.0, ge=0.0, le=5.0)
    stability_median_threshold: float = Field(0.5, ge=0.0, le=5.0)

    # Questionnaire feedback
    questionnaire_followup: bool = True

    # Ethical guardrails (Iconic Minds)
    iconic_minds_scope_guardrails: bool = True

    # Forecasting settings
    forecast_weight_by_confidence: bool = True
    forecast_beta_pooling: bool = True
    forecast_beta_draws: int = Field(20000, ge=1000, le=200000)

    # Priority setting
    priority_top_k: int = Field(10, ge=1, le=50)

    # -----------------------
    # Response length policies
    # -----------------------
    response_length_mode: Literal["tokens_only", "guided", "strict"] = "guided"

    participant_policy: ResponsePolicy = Field(
        default_factory=lambda: ResponsePolicy(
            overall=WordCountSpec(min_words=120, target_words=200, max_words=260, strict=False),
            field_policies={
                "rationale": WordCountSpec(min_words=15, target_words=30, max_words=45, strict=False),
                "justification": WordCountSpec(min_words=20, target_words=40, max_words=60, strict=False),
                "overall_comment": WordCountSpec(min_words=50, target_words=90, max_words=130, strict=False),
            },
            notes="Default guidance for participant responses. Override per stage as needed.",
        )
    )

    master_policy: ResponsePolicy = Field(
        default_factory=lambda: ResponsePolicy(
            overall=WordCountSpec(min_words=1200, target_words=2500, max_words=3000, strict=False),
            field_policies={
                "feedback": WordCountSpec(min_words=600, target_words=900, max_words=1200, strict=False),
                "summary": WordCountSpec(min_words=400, target_words=600, max_words=900, strict=False),
            },
            notes="Default guidance for master facilitator outputs (feedback/synthesis).",
        )
    )

    stage_policies: Dict[str, ResponsePolicy] = Field(default_factory=dict, description="Optional per-stage policy overrides.")

    # New (2025-12-25): allow separate per-stage overrides for participants vs master facilitator.
    # Backward compatible with `stage_policies` (applies to both).
    stage_policies_participant: Dict[str, ResponsePolicy] = Field(default_factory=dict, description="Optional per-stage overrides for participant agents.")
    stage_policies_master: Dict[str, ResponsePolicy] = Field(default_factory=dict, description="Optional per-stage overrides for the master facilitator.")

    # Reporting
    generate_word_report: bool = Field(True, description="Generate a proofread, professionally formatted Word (.docx) report after synthesis.")
    report_title: str = Field(
        "Synthetic Delphi — Consultancy Report",
        description="Title used in generated RTF/Word reports.",
    )


class StudyRunSpec(BaseModel):
    project_name: str = Field("", description="Optional: a project label used in saved cohorts and report metadata.")
    title: str = Field("Untitled Delphi Study", min_length=1)
    topic: str = Field(..., min_length=3)
    problem_statement: str = Field("", description="Optional: more detail, context, constraints.")
    master_instructions: str = Field("", description="Additional instructions for the master facilitator.")

    # Common item-generation inputs (used by many pipelines)
    seed_items: List[str] = Field(default_factory=list, description="Optional item list to start from (modified Delphi).")
    items_per_agent: int = Field(6, ge=1, le=30)

    # Item-rating
    rating_dimensions: List[RatingDimension] = Field(default_factory=lambda: [RatingDimension(name="Importance")])

    # Questionnaire / sensemaking
    questionnaire: List[str] = Field(default_factory=list, description="List of open-ended questions (each a string).")

    # Forecasting
    forecast_questions: List[str] = Field(default_factory=list, description="Binary forecasting questions (one per line in UI).")

    # Policy/guidelines & criteria
    seed_statements: List[str] = Field(default_factory=list, description="Optional starting statements for guidelines/standards.")
    statements_per_agent: int = Field(6, ge=1, le=30)

    # Instrument development
    constructs: List[str] = Field(default_factory=list, description="Construct names for instrument development.")
    items_per_construct_per_agent: int = Field(4, ge=1, le=20)

    # Scenario building
    scenario_time_horizon: str = Field("5-10 years", description="Time horizon for scenarios.")
    n_scenarios: int = Field(4, ge=2, le=8)

    # Risk register
    risks_per_agent: int = Field(6, ge=1, le=30)

    @field_validator("rating_dimensions")
    @classmethod
    def _validate_dims(cls, v: List[RatingDimension]) -> List[RatingDimension]:
        for d in v:
            if d.scale_max <= d.scale_min:
                raise ValueError(f"Invalid scale for {d.name}: scale_max must be > scale_min")
        return v


class RunOptions(BaseModel):
    run_id: Optional[str] = None
    # Late policy: "exclude" or "include_if_before_synthesis"
    late_policy: Literal["exclude", "include_if_before_synthesis"] = "exclude"


    # Optional UI hook for live monitoring (excluded from serialization)
    progress_hook: Optional[Any] = Field(default=None, exclude=True)


class StageStatus(BaseModel):
    stage_id: str
    name: str
    status: Literal["PENDING", "RUNNING", "SUCCEEDED", "FAILED"] = "PENDING"
    started_at: Optional[str] = None
    finished_at: Optional[str] = None
    details: Dict[str, Any] = Field(default_factory=dict)


class StudyResult(BaseModel):
    run_id: str
    template: DelphiTemplate
    rounds_completed: int
    quorum_reached: bool
    outputs: Dict[str, Any]
