from __future__ import annotations

import base64
import io
import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple


def _as_str(x: Any) -> str:
    if x is None:
        return ""
    try:
        return str(x)
    except Exception:
        return ""


def _md_table_to_text(md: str) -> str:
    """Best-effort: keep a markdown table readable in Word by normalizing whitespace."""
    md = (md or "").strip()
    if not md:
        return ""
    lines = [ln.rstrip() for ln in md.splitlines() if ln.strip()]
    # Many tables are already concise; just return as-is.
    return "\n".join(lines)


def _format_questionnaire_findings(outputs: Dict[str, Any]) -> str:
    fr = outputs.get("final_report") or {}
    questionnaire = outputs.get("questionnaire") or []
    if not isinstance(fr, dict):
        return ""
    parts: List[str] = []
    overall = _as_str(fr.get("overall_synthesis")).strip()
    if overall:
        parts.append("## Overall synthesis")
        parts.append(overall)
        parts.append("")

    per_q = fr.get("per_question")
    if isinstance(per_q, list) and per_q:
        parts.append("## Per-question synthesis")
        for q in per_q:
            if not isinstance(q, dict):
                continue
            qi = q.get("question_index")
            try:
                qi_int = int(qi)
            except Exception:
                qi_int = None
            qtxt = ""
            if qi_int and isinstance(questionnaire, list) and 1 <= qi_int <= len(questionnaire):
                qtxt = _as_str(questionnaire[qi_int - 1]).strip()
            parts.append("")
            parts.append(f"### Q{qi_int}: {qtxt}" if qi_int else "### Question")

            consensus = _as_str(q.get("consensus")).strip()
            disagreements = _as_str(q.get("disagreements")).strip()
            implications = _as_str(q.get("implications")).strip()

            if consensus:
                parts.append("Consensus:")
                parts.append(consensus)
            if disagreements:
                parts.append("Key disagreements:")
                parts.append(disagreements)
            if implications:
                parts.append("Implications:")
                parts.append(implications)

    return "\n".join([p for p in parts if p is not None]).strip()


def _format_priority_findings(outputs: Dict[str, Any]) -> str:
    items = outputs.get("items") or []
    topk = outputs.get("final_top_k") or []
    W = outputs.get("final_kendalls_w")
    table_md = _as_str(outputs.get("final_borda_table_md")).strip()

    parts: List[str] = []
    if topk and isinstance(items, list):
        parts.append("## Final priority list (top-k)")
        for i, idx in enumerate(topk, start=1):
            try:
                item_txt = _as_str(items[int(idx) - 1]).strip()
            except Exception:
                item_txt = _as_str(idx).strip()
            if item_txt:
                parts.append(f"- {i}. {item_txt}")
        parts.append("")
    if W is not None:
        parts.append("## Agreement")
        parts.append(f"Kendall's W: {W}")
        parts.append("")
    if table_md:
        parts.append("## Aggregate scores (excerpt)")
        parts.append(_md_table_to_text(table_md))
    return "\n".join(parts).strip()


def _format_forecasting_findings(outputs: Dict[str, Any]) -> str:
    table_md = _as_str(outputs.get("final_table_md")).strip()
    parts: List[str] = []
    if table_md:
        parts.append("## Final aggregated forecasts")
        parts.append(_md_table_to_text(table_md))
    return "\n".join(parts).strip()


def _format_item_rating_findings(outputs: Dict[str, Any]) -> str:
    stats = outputs.get("final_stats") or {}
    parts: List[str] = []
    if isinstance(stats, dict) and stats:
        parts.append("## Final item ratings")
        # Try to identify dimensions from first item
        dim_names: List[str] = []
        try:
            first_item = next(iter(stats.values()))
            if isinstance(first_item, dict):
                dim_names = list(first_item.keys())
        except Exception:
            dim_names = []

        # Provide a concise listing of up to 15 items
        for i, (item, dims) in enumerate(list(stats.items())[:15], start=1):
            parts.append(f"### {i}. {_as_str(item).strip()}")
            if isinstance(dims, dict):
                for dn in (dim_names or list(dims.keys())):
                    d = dims.get(dn)
                    if isinstance(d, dict):
                        med = d.get("median")
                        iqr = d.get("iqr")
                        mean = d.get("mean")
                        n = d.get("n")
                        parts.append(f"- {dn}: median={med}, IQR={iqr}, mean={mean}, n={n}")
            parts.append("")

    fb = _as_str(outputs.get("feedback_last")).strip()
    if fb:
        parts.append("## Facilitator note")
        parts.append(fb)
    return "\n".join(parts).strip()


def _format_guidelines_findings(outputs: Dict[str, Any]) -> str:
    mode = _as_str(outputs.get("mode") or "guidelines").strip() or "guidelines"
    statements = outputs.get("statements") or []
    stats = outputs.get("stats") or {}
    divergence = outputs.get("divergence") or []
    parts: List[str] = []
    if statements:
        parts.append(f"## Consolidated {mode} statements")
        for s in statements[:25]:
            st = _as_str(s).strip()
            if st:
                parts.append(f"- {st}")
        parts.append("")

    if isinstance(stats, dict) and stats:
        parts.append(f"## Ratings summary ({mode})")
        # Summarize top 10 by acceptability median if present.
        scored: List[Tuple[float, float, str]] = []
        for st, dims in stats.items():
            if not isinstance(dims, dict):
                continue
            acc = dims.get("Acceptability") or dims.get("acceptability")
            if isinstance(acc, dict) and acc.get("median") is not None:
                try:
                    scored.append((float(acc.get("median")), float(acc.get("iqr") or 999), _as_str(st).strip()))
                except Exception:
                    continue
        scored.sort(key=lambda x: (-x[0], x[1], x[2]))
        for med, iqr, st in scored[:10]:
            parts.append(f"- {st} (acceptability median={med}, IQR={iqr})")
        parts.append("")

    if divergence:
        parts.append("## Divergent statements")
        for st in divergence[:15]:
            parts.append(f"- {_as_str(st).strip()}")
    return "\n".join(parts).strip()


def _format_risk_register_findings(outputs: Dict[str, Any]) -> str:
    risks = outputs.get("risks") or []
    rpn = outputs.get("risk_priority") or {}
    parts: List[str] = []
    if isinstance(rpn, dict) and rpn:
        parts.append("## Risk priority (by median likelihood × median impact)")
        # Sort by score desc
        try:
            ranked = sorted(((float(v), k) for k, v in rpn.items()), reverse=True)
        except Exception:
            ranked = []
        for score, key in ranked[:15]:
            parts.append(f"- {key} (priority={score:.2f})")
        parts.append("")

    if isinstance(risks, list) and risks:
        parts.append("## Consolidated risk register (excerpt)")
        for r in risks[:12]:
            if not isinstance(r, dict):
                continue
            rid = _as_str(r.get("risk_id")).strip()
            rtxt = _as_str(r.get("risk")).strip()
            if rid or rtxt:
                parts.append(f"### {rid}: {rtxt}".strip())
            causes = r.get("causes") or []
            impacts = r.get("impacts") or []
            mitigations = r.get("mitigations") or []
            for lbl, arr in (("Causes", causes), ("Impacts", impacts), ("Mitigations", mitigations)):
                if isinstance(arr, list) and arr:
                    parts.append(f"{lbl}:")
                    for x in arr[:6]:
                        parts.append(f"- {_as_str(x).strip()}")
            parts.append("")

    return "\n".join(parts).strip()


def _format_scenario_findings(outputs: Dict[str, Any]) -> str:
    scenarios = outputs.get("scenarios") or []
    horizon = _as_str(outputs.get("time_horizon")).strip()
    parts: List[str] = []
    if horizon:
        parts.append(f"## Time horizon: {horizon}")
        parts.append("")
    if isinstance(scenarios, list) and scenarios:
        parts.append("## Scenarios")
        for i, sc in enumerate(scenarios[:10], start=1):
            if isinstance(sc, dict):
                name = _as_str(sc.get("name") or sc.get("title") or f"Scenario {i}").strip()
                narrative = _as_str(sc.get("narrative") or sc.get("description") or "").strip()
                parts.append(f"### {name}")
                if narrative:
                    parts.append(narrative)
            else:
                parts.append(f"- {_as_str(sc).strip()}")
            parts.append("")
    return "\n".join(parts).strip()


def _format_sensemaking_findings(outputs: Dict[str, Any]) -> str:
    scope_map = outputs.get("scope_map") or {}
    if not isinstance(scope_map, dict):
        return ""
    parts: List[str] = []
    parts.append("## Shared scope map")
    for key, title in (
        ("glossary", "Glossary"),
        ("assumptions", "Assumptions"),
        ("in_scope", "In scope"),
        ("out_of_scope", "Out of scope"),
        ("uncertainties", "Uncertainties"),
    ):
        arr = scope_map.get(key)
        if isinstance(arr, list) and arr:
            parts.append(f"### {title}")
            for x in arr[:30]:
                parts.append(f"- {_as_str(x).strip()}")
            parts.append("")
    notes = _as_str(scope_map.get("notes")).strip()
    if notes:
        parts.append("### Notes")
        parts.append(notes)
    return "\n".join(parts).strip()


def _format_idea_generation_findings(outputs: Dict[str, Any]) -> str:
    clustered = outputs.get("clustered") or {}
    if not isinstance(clustered, dict):
        return ""
    clusters = clustered.get("clusters") or []
    parts: List[str] = []
    if isinstance(clusters, list) and clusters:
        parts.append("## Idea clusters")
        for c in clusters[:12]:
            if not isinstance(c, dict):
                continue
            theme = _as_str(c.get("theme")).strip()
            items = c.get("items") or []
            if theme:
                parts.append(f"### {theme}")
            if isinstance(items, list) and items:
                for it in items[:25]:
                    parts.append(f"- {_as_str(it).strip()}")
            parts.append("")
    return "\n".join(parts).strip()


def _format_instrument_findings(outputs: Dict[str, Any]) -> str:
    instrument = outputs.get("instrument") or {}
    if not isinstance(instrument, dict):
        return ""
    parts: List[str] = []
    parts.append("## Draft instrument")
    constructs = instrument.get("constructs") or []
    if isinstance(constructs, list) and constructs:
        for c in constructs:
            if not isinstance(c, dict):
                continue
            cname = _as_str(c.get("name")).strip()
            parts.append(f"### {cname}" if cname else "### Construct")
            items = c.get("items") or []
            if isinstance(items, list):
                for it in items[:30]:
                    parts.append(f"- {_as_str(it).strip()}")
            parts.append("")
    return "\n".join(parts).strip()




def _format_recursive_reasoning_findings(outputs: Dict[str, Any]) -> str:
    questions = outputs.get("questionnaire") or []
    digest1 = outputs.get("understanding_digest") or {}
    digest2 = outputs.get("solution_digest") or {}
    final_report = outputs.get("final_report") or {}

    q_txt = "\n".join([f"{i+1}. {_as_str(q).strip()}" for i, q in enumerate(questions) if _as_str(q).strip()])

    parts: list[str] = []
    if q_txt:
        parts.append("Key questions")
        parts.append(q_txt)

    # Round 1 digest
    if isinstance(digest1, dict) and any(digest1.get(k) for k in ("summary", "agreements", "disagreements", "missing_considerations")):
        parts.append("\nRound 1 — Pooled understandings")
        if _as_str(digest1.get("summary")).strip():
            parts.append("Summary: " + _as_str(digest1.get("summary")).strip())
        if isinstance(digest1.get("agreements"), list) and digest1.get("agreements"):
            parts.append("Agreements:\n- " + "\n- ".join([_as_str(x).strip() for x in digest1.get("agreements") if _as_str(x).strip()]))
        if isinstance(digest1.get("disagreements"), list) and digest1.get("disagreements"):
            parts.append("Disagreements:\n- " + "\n- ".join([_as_str(x).strip() for x in digest1.get("disagreements") if _as_str(x).strip()]))
        if isinstance(digest1.get("missing_considerations"), list) and digest1.get("missing_considerations"):
            parts.append("Missing considerations:\n- " + "\n- ".join([_as_str(x).strip() for x in digest1.get("missing_considerations") if _as_str(x).strip()]))
        if isinstance(digest1.get("clarification_questions"), list) and digest1.get("clarification_questions"):
            parts.append("Clarification questions:\n- " + "\n- ".join([_as_str(x).strip() for x in digest1.get("clarification_questions") if _as_str(x).strip()]))

    # Round 2 digest
    if isinstance(digest2, dict) and any(digest2.get(k) for k in ("summary", "agreements", "disagreements", "missing_considerations")):
        parts.append("\nRound 2 — Pooled proposed solutions")
        if _as_str(digest2.get("summary")).strip():
            parts.append("Summary: " + _as_str(digest2.get("summary")).strip())
        if isinstance(digest2.get("agreements"), list) and digest2.get("agreements"):
            parts.append("Agreements:\n- " + "\n- ".join([_as_str(x).strip() for x in digest2.get("agreements") if _as_str(x).strip()]))
        if isinstance(digest2.get("disagreements"), list) and digest2.get("disagreements"):
            parts.append("Disagreements:\n- " + "\n- ".join([_as_str(x).strip() for x in digest2.get("disagreements") if _as_str(x).strip()]))
        if isinstance(digest2.get("missing_considerations"), list) and digest2.get("missing_considerations"):
            parts.append("Missing considerations:\n- " + "\n- ".join([_as_str(x).strip() for x in digest2.get("missing_considerations") if _as_str(x).strip()]))
        if isinstance(digest2.get("clarification_questions"), list) and digest2.get("clarification_questions"):
            parts.append("Clarification questions:\n- " + "\n- ".join([_as_str(x).strip() for x in digest2.get("clarification_questions") if _as_str(x).strip()]))

    # Final synthesis
    if isinstance(final_report, dict) and any(final_report.get(k) for k in ("summary", "recommended_answer", "agreements", "disagreements")):
        parts.append("\nFinal synthesis")
        if _as_str(final_report.get("summary")).strip():
            parts.append("Summary: " + _as_str(final_report.get("summary")).strip())
        if _as_str(final_report.get("recommended_answer")).strip():
            parts.append("Recommended answer:\n" + _as_str(final_report.get("recommended_answer")).strip())
        if isinstance(final_report.get("agreements"), list) and final_report.get("agreements"):
            parts.append("Agreements:\n- " + "\n- ".join([_as_str(x).strip() for x in final_report.get("agreements") if _as_str(x).strip()]))
        if isinstance(final_report.get("disagreements"), list) and final_report.get("disagreements"):
            parts.append("Disagreements:\n- " + "\n- ".join([_as_str(x).strip() for x in final_report.get("disagreements") if _as_str(x).strip()]))
        if isinstance(final_report.get("convergences"), list) and final_report.get("convergences"):
            parts.append("Convergences:\n- " + "\n- ".join([_as_str(x).strip() for x in final_report.get("convergences") if _as_str(x).strip()]))
        if isinstance(final_report.get("divergences"), list) and final_report.get("divergences"):
            parts.append("Divergences:\n- " + "\n- ".join([_as_str(x).strip() for x in final_report.get("divergences") if _as_str(x).strip()]))
        if isinstance(final_report.get("open_questions"), list) and final_report.get("open_questions"):
            parts.append("Open questions:\n- " + "\n- ".join([_as_str(x).strip() for x in final_report.get("open_questions") if _as_str(x).strip()]))

    return "\n\n".join([p for p in parts if _as_str(p).strip()])

def format_findings(*, template: str, outputs: Dict[str, Any]) -> str:
    """Produce a Word-friendly findings narrative without dumping raw JSON."""
    template = (template or "").strip()
    if not isinstance(outputs, dict):
        return _as_str(outputs).strip()

    # Prefer explicit narrative fields if they are already strings.
    for k in ("final_report", "feedback_last", "synthesis", "summary"):
        v = outputs.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()

    if template == "questionnaire_ai_delphi":
        txt = _format_questionnaire_findings(outputs)
        if txt:
            return txt
    if template == "priority_ranking":
        txt = _format_priority_findings(outputs)
        if txt:
            return txt
    if template == "forecasting":
        txt = _format_forecasting_findings(outputs)
        if txt:
            return txt
    if template == "item_rating":
        txt = _format_item_rating_findings(outputs)
        if txt:
            return txt
    if template in ("policy_guidelines", "criteria_standards"):
        txt = _format_guidelines_findings(outputs)
        if txt:
            return txt
    if template == "risk_register":
        txt = _format_risk_register_findings(outputs)
        if txt:
            return txt
    if template == "scenario_building":
        txt = _format_scenario_findings(outputs)
        if txt:
            return txt
    if template == "sensemaking":
        txt = _format_sensemaking_findings(outputs)
        if txt:
            return txt
    if template == "recursive_reasoning":
        txt = _format_recursive_reasoning_findings(outputs)
        if txt:
            return txt
    if template == "idea_generation":
        txt = _format_idea_generation_findings(outputs)
        if txt:
            return txt
    if template == "instrument_development":
        txt = _format_instrument_findings(outputs)
        if txt:
            return txt

    # Fallback: compact JSON excerpt (human readable, preserve unicode characters)
    try:
        return "Outputs (excerpt):\n" + json.dumps(outputs, indent=2, ensure_ascii=False)[:8000]
    except Exception:
        return _as_str(outputs)[:8000]


def _require_python_docx():
    """Import python-docx lazily to avoid hard import failures at app startup."""
    try:
        from docx import Document  # type: ignore
        from docx.enum.text import WD_ALIGN_PARAGRAPH  # type: ignore
        from docx.shared import Pt  # type: ignore
        return Document, WD_ALIGN_PARAGRAPH, Pt
    except Exception as e:
        # Common pitfall: installing 'docx' instead of 'python-docx'
        raise RuntimeError(
            "python-docx is required to generate Word (.docx) reports. "
            "Install it with: python -m pip install python-docx. "
            "If you previously installed the 'docx' package, remove it with: python -m pip uninstall docx"
        ) from e



def _now_date_str() -> str:
    # ISO date (UTC)
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def build_draft_report_sections(
    *,
    run_id: str,
    spec: Any,
    config: Any,
    agents: List[Any],
    master: Any,
    result: Any,
    execution_summary: Optional[Dict[str, Any]] = None,
) -> Dict[str, str]:
    """
    Build a plain-text draft consultancy report from run inputs and outputs.

    The intention is to:
    - Keep findings wording anchored to master-generated synthesis fields where possible (e.g., final_report, feedback_last).
    - Keep the draft deterministic (no LLM calls here).
    """
    # Allow a user-specified report title (saved in config) while keeping run_id traceability.
    report_title = getattr(config, "report_title", None) or (config.get("report_title") if isinstance(config, dict) else None)
    report_title = (str(report_title).strip() if report_title is not None else "").strip()
    title = f"{report_title} ({run_id})" if report_title else f"Synthetic Delphi — Study Report ({run_id})"
    date_str = _now_date_str()

    project_name = getattr(spec, "project_name", None) or (spec.get("project_name") if isinstance(spec, dict) else "")
    topic = getattr(spec, "topic", None) or (spec.get("topic") if isinstance(spec, dict) else "")
    study_title = getattr(spec, "title", None) or (spec.get("title") if isinstance(spec, dict) else "")
    problem = getattr(spec, "problem_statement", None) or (spec.get("problem_statement") if isinstance(spec, dict) else "")

    template = getattr(config, "template", None) or (config.get("template") if isinstance(config, dict) else "")
    panel_mode = getattr(config, "ai_delphi_model", None) or (config.get("ai_delphi_model") if isinstance(config, dict) else "")
    max_rounds = getattr(config, "max_rounds", None) or (config.get("max_rounds") if isinstance(config, dict) else "")
    min_rounds = getattr(config, "min_rounds", None) or (config.get("min_rounds") if isinstance(config, dict) else "")
    quorum = getattr(config, "quorum_fraction", None) or (config.get("quorum_fraction") if isinstance(config, dict) else "")

    # Abstract: short and factual (avoid inventing results)
    abstract_lines: List[str] = []
    if project_name:
        abstract_lines.append(f"Project: {project_name}.")
    if study_title:
        abstract_lines.append(f"This report documents the Synthetic Delphi study: {study_title}.")
    if topic:
        abstract_lines.append(f"Topic: {topic}.")
    if problem:
        abstract_lines.append(f"Problem statement: {problem}")
    abstract_lines.append(
        "The findings section reflects the panel’s responses as recorded by the study pipeline."
    )
    abstract = "\n".join(abstract_lines).strip()

    method_lines = [
        f"Template: {template}",
        f"AI-Delphi panel mode: {panel_mode}",
        f"Rounds: min={min_rounds}, max={max_rounds}",
        f"Quorum fraction (per stage): {quorum}",
    ]
    method = "\n".join([x for x in method_lines if str(x).strip() and "None" not in str(x)])

    # Participants
    p_lines: List[str] = []
    try:
        mname = getattr(master, "name", None) or (master.get("name") if isinstance(master, dict) else "Master Researcher")
        mmodel = getattr(master, "model", None) or (master.get("model") if isinstance(master, dict) else "")
        p_lines.append(f"- Master facilitator: {mname} ({mmodel})")
    except Exception:
        p_lines.append("- Master facilitator: Master Researcher")
    for a in agents:
        try:
            if getattr(a, "enabled", True) is False:
                continue
            name = getattr(a, "name", None) or (a.get("name") if isinstance(a, dict) else "")
            model = getattr(a, "model", None) or (a.get("model") if isinstance(a, dict) else "")
            agent_id = getattr(a, "agent_id", None) or (a.get("agent_id") if isinstance(a, dict) else "")
            if name:
                p_lines.append(f"- Participant: {name} ({agent_id}; {model})".strip())
        except Exception:
            continue
    participants = "\n".join(p_lines).strip()

    # Findings: generate a Word-friendly narrative without dumping raw JSON
    outputs = getattr(result, "outputs", None) or (result.get("outputs") if isinstance(result, dict) else {}) or {}
    findings_text = format_findings(template=str(template or ""), outputs=outputs)

    appendix = ""
    if execution_summary:
        try:
            appendix = "Execution summary:\n" + json.dumps(execution_summary, indent=2, ensure_ascii=False)
        except Exception:
            appendix = f"Execution summary:\n{execution_summary}"

    return {
        "title": title,
        "date": date_str,
        "creator": "Shane McLoughlin",
        "abstract": abstract,
        "method": method,
        "participants": participants,
        "findings": findings_text,
        "appendix": appendix.strip(),
    }


def sections_similarity(a: str, b: str) -> float:
    """
    Rough similarity score [0..1] to detect heavy rewrites.
    """
    import difflib
    a_n = " ".join(a.split())
    b_n = " ".join(b.split())
    if not a_n and not b_n:
        return 1.0
    return difflib.SequenceMatcher(None, a_n, b_n).ratio()


def build_docx_from_sections(sections: Dict[str, str]) -> bytes:
    """
    Build a Word (.docx) file in-memory.
    """
    Document, WD_ALIGN_PARAGRAPH, Pt = _require_python_docx()
    doc = Document()

    # Title
    title = (sections.get("title") or "Synthetic Delphi — Study Report").strip()
    p = doc.add_paragraph(title)
    try:
        p.style = "Title"
    except Exception:
        pass
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # Creator + date
    creator = (sections.get("creator") or "").strip()
    date_str = (sections.get("date") or _now_date_str()).strip()
    meta = []
    if creator:
        meta.append(f"Created by {creator}")
    if date_str:
        meta.append(f"Date: {date_str}")
    if meta:
        mp = doc.add_paragraph(" | ".join(meta))
        mp.alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_paragraph("")

    def add_section(heading: str, body: str) -> None:
        if not body or not body.strip():
            return
        doc.add_heading(heading, level=1)
        lines = body.strip().splitlines()
        # Preserve blank lines as paragraph breaks
        for line in lines:
            ln = line.rstrip()
            if not ln.strip():
                doc.add_paragraph("")
                continue
            # Lightweight markdown-ish headings for better Word structure.
            if ln.startswith("#### "):
                doc.add_heading(ln[5:].strip(), level=4)
                continue
            if ln.startswith("### "):
                doc.add_heading(ln[4:].strip(), level=3)
                continue
            if ln.startswith("## "):
                doc.add_heading(ln[3:].strip(), level=2)
                continue
            if ln.lstrip().startswith(("-", "•")):
                # bullet
                bullet = ln.lstrip().lstrip("•").lstrip("-").strip()
                doc.add_paragraph(bullet, style="List Bullet")
            elif ln.endswith(":") and len(ln) <= 90:
                # Bold label line (e.g., 'Consensus:')
                p = doc.add_paragraph()
                r = p.add_run(ln)
                r.bold = True
            else:
                doc.add_paragraph(ln)

        doc.add_paragraph("")

    add_section("Abstract", sections.get("abstract", ""))
    add_section("Method", sections.get("method", ""))
    add_section("Participants", sections.get("participants", ""))
    add_section("Findings", sections.get("findings", ""))
    if sections.get("appendix"):
        add_section("Appendix", sections.get("appendix", ""))

    # Make body text a bit more readable
    try:
        style = doc.styles["Normal"]
        style.font.name = "Calibri"
        style.font.size = Pt(11)
    except Exception:
        pass

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def pack_docx_artifact(docx_bytes: bytes, *, run_id: str) -> Dict[str, Any]:
    return {
        "mime": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "filename": f"SyntheticDelphi_Report_{run_id}.docx",
        "b64": base64.b64encode(docx_bytes).decode("ascii"),
    }