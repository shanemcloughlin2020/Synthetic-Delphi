from __future__ import annotations

import json
import math
import re
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional, Tuple

from .analytics import (
    compute_item_stats,
    consensus_met,
    stability_met,
    stats_markdown_table,
    divergence_items,
    aggregate_forecasts,
    forecast_markdown_table,
    compute_borda_scores,
    kendalls_w,
    borda_markdown_table,
    top_k_from_scores,
    jaccard,
)
from .providers import ChatResult, MockProvider, OpenAICompatibleProvider, Provider
from .schemas import AgentProfile, DelphiConfig, MasterAgentConfig, RatingDimension, RunOptions, StudyResult, StudyRunSpec
from .storage import SQLiteStore, _now_iso
from . import prompts

def _safe_json_loads(text: str) -> Tuple[Optional[Any], Optional[str]]:
    try:
        return json.loads(text), None
    except Exception:
        # attempt to extract first JSON object
        m = re.search(r"\{.*\}", text, flags=re.S)
        if m:
            try:
                return json.loads(m.group(0)), None
            except Exception as e:
                return None, str(e)
        return None, "Invalid JSON"




def _count_words(text: str) -> int:
    return len(re.findall(r"\b\w+\b", text or ""))


def _count_words_in_json(obj: Any) -> int:
    """Count words across *string* values in a JSON-like structure."""
    if obj is None:
        return 0
    if isinstance(obj, str):
        return _count_words(obj)
    if isinstance(obj, (int, float, bool)):
        return 0
    if isinstance(obj, list):
        return sum(_count_words_in_json(x) for x in obj)
    if isinstance(obj, dict):
        return sum(_count_words_in_json(v) for v in obj.values())
    return 0


def _within_bounds(n: int, min_words: int | None, max_words: int | None) -> bool:
    if min_words is not None and min_words > 0 and n < min_words:
        return False
    if max_words is not None and max_words > 0 and n > max_words:
        return False
    return True


def _slug() -> str:
    return uuid.uuid4().hex[:10]


class DelphiStudyRunner:
    def __init__(self, store: SQLiteStore, provider: Provider) -> None:
        self.store = store
        self.provider = provider

        self._progress_hook = None

    def run(
        self,
        *,
        spec: StudyRunSpec,
        config: DelphiConfig,
        agents: List[AgentProfile],
        master: MasterAgentConfig,
        options: Optional[RunOptions] = None,
    ) -> StudyResult:
        options = options or RunOptions()
        run_id = options.run_id or f"run_{uuid.uuid4().hex}"
        self._progress_hook = getattr(options, "progress_hook", None)
        enabled_agents = [a for a in agents if a.enabled]
        if len(enabled_agents) == 0:
            raise ValueError("No enabled agents configured.")

        self.store.create_study(
            run_id=run_id,
            spec=spec.model_dump(),
            config=config.model_dump(),
            agents=[a.model_dump() for a in agents],
            master=master.model_dump(),
        )
        self.store.log_event(f"evt_{_slug()}", run_id, "RUN_STARTED", {"template": config.template})
        self._notify_progress({"type": "RUN_STARTED", "run_id": run_id, "template": config.template})

        if config.template == "item_rating":
            outputs, rounds_completed, quorum_ok = self._run_item_rating(run_id, spec, config, enabled_agents, master)
        elif config.template == "questionnaire_ai_delphi":
            outputs, rounds_completed, quorum_ok = self._run_questionnaire(run_id, spec, config, enabled_agents, master)
        elif config.template == "forecasting":
            outputs, rounds_completed, quorum_ok = self._run_forecasting(run_id, spec, config, enabled_agents, master)
        elif config.template == "priority_ranking":
            outputs, rounds_completed, quorum_ok = self._run_priority_ranking(run_id, spec, config, enabled_agents, master)
        elif config.template == "sensemaking":
            outputs, rounds_completed, quorum_ok = self._run_sensemaking(run_id, spec, config, enabled_agents, master)
        elif config.template == "idea_generation":
            outputs, rounds_completed, quorum_ok = self._run_idea_generation(run_id, spec, config, enabled_agents, master)
        elif config.template == "criteria_standards":
            outputs, rounds_completed, quorum_ok = self._run_criteria_standards(run_id, spec, config, enabled_agents, master)
        elif config.template == "scenario_building":
            outputs, rounds_completed, quorum_ok = self._run_scenario_building(run_id, spec, config, enabled_agents, master)
        elif config.template == "policy_guidelines":
            outputs, rounds_completed, quorum_ok = self._run_policy_guidelines(run_id, spec, config, enabled_agents, master)
        elif config.template == "risk_register":
            outputs, rounds_completed, quorum_ok = self._run_risk_register(run_id, spec, config, enabled_agents, master)
        elif config.template == "instrument_development":
            outputs, rounds_completed, quorum_ok = self._run_instrument_development(run_id, spec, config, enabled_agents, master)
        elif config.template == "recursive_reasoning":
            outputs, rounds_completed, quorum_ok = self._run_recursive_reasoning(run_id, spec, config, enabled_agents, master)
        else:
            raise ValueError(f"Unknown Delphi template: {config.template}")

        result = StudyResult(
            run_id=run_id,
            template=config.template,
            rounds_completed=rounds_completed,
            quorum_reached=quorum_ok,
            outputs=outputs,
        )
        self.store.save_artifact(f"art_{_slug()}", run_id, "final_result", result.model_dump())
        # Optional: generate proofread Word report (.docx) after synthesis.
        if getattr(config, "generate_word_report", False):
            try:
                self._generate_word_report(run_id, spec, config, enabled_agents, master, result)
            except Exception as e:
                self.store.log_event(f"evt_{_slug()}", run_id, "WORD_REPORT_FAILED", {"error": str(e)})

        # Save execution summary artifact for quick health reporting in the UI.
        try:
            summary = self._compute_execution_summary(run_id)
            self.store.save_artifact(f"art_{_slug()}", run_id, "execution_summary", summary)
        except Exception as e:
            self.store.log_event(f"evt_{_slug()}", run_id, "EXECUTION_SUMMARY_FAILED", {"error": str(e)})

        self.store.log_event(f"evt_{_slug()}", run_id, "RUN_FINISHED", {"rounds_completed": rounds_completed, "quorum": quorum_ok})
        self._notify_progress({"type": "RUN_FINISHED", "run_id": run_id, "rounds_completed": rounds_completed, "quorum": quorum_ok})
        self._progress_hook = None
        return result

    # -------------------------
    # Core orchestration helpers
    # -------------------------

    # -------------------------
    # Core orchestration helpers
    # -------------------------
    def _effective_system_prompt(self, config: Optional[DelphiConfig], profile: Dict[str, Any], *, is_master: bool) -> str:
        base_prompt = (profile.get("system_prompt") or "").strip()
        if not config:
            return base_prompt

        mode = config.ai_delphi_model
        persona_name = (profile.get("persona_name") or profile.get("name") or profile.get("agent_id") or "").strip()
        discipline = (profile.get("discipline") or "").strip()
        persona_description = (profile.get("persona_description") or "").strip()

        sys_prompt = base_prompt

        if mode == "persona_panel":
            # Build a stable panel persona prompt from discipline/description; treat base_prompt as additional guidance.
            if persona_description or discipline:
                desc = persona_description or f"Discipline/role: {discipline}."
                sys_prompt = prompts.persona_system_prompt("persona_panel", persona_name or profile.get("name", ""), desc)
                if base_prompt and base_prompt != desc:
                    sys_prompt = sys_prompt + "\n\nAdditional instructions:\n" + base_prompt

        elif mode == "iconic_minds":
            # Prefer explicit persona_description; otherwise fall back to base_prompt as the persona brief.
            desc = persona_description or base_prompt
            if desc:
                sys_prompt = prompts.persona_system_prompt("iconic_minds", persona_name or profile.get("name", ""), desc)
            if config.iconic_minds_scope_guardrails:
                sys_prompt = prompts.apply_iconic_minds_guardrails(sys_prompt)

        # Digital oracle: do nothing special.
        return sys_prompt

    def _select_policy(self, config: Optional[DelphiConfig], stage_key: str, *, is_master: bool):
        if not config:
            return None
        if config.response_length_mode == "tokens_only":
            return None

        default_policy = config.master_policy if is_master else config.participant_policy

        # Prefer role-specific stage overrides if provided (newer config), else fall back to shared stage_policies.
        if is_master and getattr(config, 'stage_policies_master', None):
            return (config.stage_policies_master or {}).get(stage_key, (config.stage_policies or {}).get(stage_key, default_policy))
        if (not is_master) and getattr(config, 'stage_policies_participant', None):
            return (config.stage_policies_participant or {}).get(stage_key, (config.stage_policies or {}).get(stage_key, default_policy))

        return (config.stage_policies or {}).get(stage_key, default_policy)

    def _format_policy_guidance(self, policy, *, stage_key: str) -> str:
        if not policy:
            return ""
        overall = getattr(policy, "overall", None)
        if not overall or not getattr(overall, "is_configured", lambda: False)():
            return ""

        lines = ["Response length policy (words, not tokens):"]
        mn = overall.min_words
        mx = overall.max_words
        tgt = overall.target_words
        if tgt and tgt > 0:
            lines.append(f"- Aim for approximately {tgt} words total across all text fields.")
        if (mn and mn > 0) or (mx and mx > 0):
            lines.append(f"- Keep the total between {mn or 0} and {mx or '∞'} words.")
        # Per-field guidance (prompt-only)
        fp = getattr(policy, "field_policies", {}) or {}
        for field, spec in fp.items():
            if not spec or not getattr(spec, "is_configured", lambda: False)():
                continue
            fmn, fmx, ftgt = spec.min_words, spec.max_words, spec.target_words
            frag = []
            if ftgt and ftgt > 0:
                frag.append(f"~{ftgt}")
            if (fmn and fmn > 0) or (fmx and fmx > 0):
                frag.append(f"{fmn or 0}-{fmx or '∞'}")
            if frag:
                lines.append(f"- For `{field}` text, aim for {' ('.join([frag[0]] + ([] if len(frag)==1 else [frag[1]]))}{')' if len(frag)>1 else ''} words.")
        if getattr(policy, "notes", ""):
            lines.append("Notes: " + str(policy.notes).strip())

        lines.append("Do not add commentary or markdown. Follow the required JSON schema exactly.")
        return "\n".join(lines)

    # -------------------------
    # Stage lifecycle helpers
    # -------------------------
    def _notify_progress(self, payload: dict) -> None:
        hook = getattr(self, '_progress_hook', None)
        if hook:
            try:
                hook(payload)
            except Exception:
                # UI hooks must never break the pipeline
                pass

    def _stage_started(self, run_id: str, stage_id: str, stage_name: str, stage_key: str, details: dict | None = None) -> None:
        det = {"stage_key": stage_key}
        if details:
            det.update(details)
        self.store.upsert_stage(stage_id, run_id, stage_name, "RUNNING", started_at=_now_iso(), details=det)
        self.store.log_event(f"evt_{_slug()}", run_id, "STAGE_STARTED", {"stage_id": stage_id, "name": stage_name, "stage_key": stage_key})
        self._notify_progress({"type": "STAGE_STARTED", "stage_id": stage_id, "name": stage_name, "stage_key": stage_key})

    def _stage_finished(
        self,
        run_id: str,
        stage_id: str,
        stage_name: str,
        stage_key: str,
        *,
        ok: bool,
        status: str,
        details: dict | None = None,
    ) -> None:
        det = {"stage_key": stage_key}
        if details:
            det.update(details)
        self.store.upsert_stage(stage_id, run_id, stage_name, status, finished_at=_now_iso(), details=det)
        payload = {"stage_id": stage_id, "name": stage_name, "stage_key": stage_key, "ok": ok}
        if details:
            payload.update({"details": details})
        self.store.log_event(f"evt_{_slug()}", run_id, "STAGE_FINISHED", payload)
        self._notify_progress({"type": "STAGE_FINISHED", "stage_id": stage_id, "name": stage_name, "stage_key": stage_key, "ok": ok})

    def _compute_execution_summary(self, run_id: str) -> Dict[str, Any]:
        """Compute a lightweight execution summary for the UI.

        The goal is to make it obvious which agents/stages succeeded, failed, or timed out.
        This uses the persisted stages/tasks tables, so it works for historical runs.
        """
        rec = self.store.get_study_record(run_id) or {}
        agent_names: Dict[str, str] = {}
        for a in rec.get("agents", []) or []:
            try:
                agent_names[str(a.get("agent_id"))] = str(a.get("name") or "")
            except Exception:
                pass
        try:
            agent_names["MASTER"] = str((rec.get("master") or {}).get("name") or "Master")
        except Exception:
            agent_names["MASTER"] = "Master"

        stages = self.store.list_stages(run_id) or []
        tasks = self.store.list_tasks(run_id) or []

        # Index latest task per (stage_id, agent_id)
        latest: Dict[tuple, Dict[str, Any]] = {}
        for t in tasks:
            key = (t.get("stage_id"), t.get("agent_id"))
            if key not in latest:
                latest[key] = t
                continue
            # Prefer higher attempt count; fall back to finished_at timestamp
            a1 = int(latest[key].get("attempts") or 0)
            a2 = int(t.get("attempts") or 0)
            if a2 > a1:
                latest[key] = t
                continue
            if a2 == a1:
                f1 = str(latest[key].get("finished_at") or "")
                f2 = str(t.get("finished_at") or "")
                if f2 and (not f1 or f2 > f1):
                    latest[key] = t

        # Per-stage rollups
        stage_rows: List[Dict[str, Any]] = []
        for s in stages:
            det = s.get("details") or {}
            stage_id = s.get("stage_id")
            errors = det.get("errors") if isinstance(det, dict) else None
            stage_rows.append({
                "stage_id": stage_id,
                "stage_key": det.get("stage_key"),
                "name": s.get("name"),
                "status": s.get("status"),
                "responses": det.get("responses"),
                "quorum_required": det.get("quorum_required"),
                "errors": errors if isinstance(errors, dict) else {},
                "started_at": s.get("started_at"),
                "finished_at": s.get("finished_at"),
            })

        # Determine set of agents observed
        agent_ids = sorted({str(t.get("agent_id")) for t in tasks if t.get("agent_id")})
        if "MASTER" not in agent_ids:
            agent_ids.append("MASTER")

        agent_rows: List[Dict[str, Any]] = []
        for aid in agent_ids:
            agent_tasks = [t for t in tasks if str(t.get("agent_id")) == aid]
            total = len({(t.get("stage_id"), t.get("agent_id")) for t in agent_tasks if t.get("stage_id")})
            succ = 0
            fail = 0
            running = 0
            last_error = ""
            for s in stages:
                stage_id = s.get("stage_id")
                lt = latest.get((stage_id, aid))
                if not lt:
                    continue
                st = str(lt.get("status") or "")
                if st == "SUCCEEDED":
                    succ += 1
                elif st == "RUNNING":
                    running += 1
                else:
                    fail += 1
                    if lt.get("error"):
                        last_error = str(lt.get("error"))
            agent_rows.append({
                "agent_id": aid,
                "name": agent_names.get(aid, ""),
                "stages_total": int(total),
                "stages_succeeded": int(succ),
                "stages_failed": int(fail),
                "stages_running": int(running),
                "last_error": last_error,
            })

        metrics = {
            "stages": len(stages),
            "tasks": len(tasks),
            "participants": len([a for a in agent_rows if a["agent_id"] not in ("MASTER",)]),
            "master_calls": len([t for t in tasks if str(t.get("agent_id")) == "MASTER"]),
            "participant_calls": len([t for t in tasks if str(t.get("agent_id")) != "MASTER"]),
        }

        return {
            "run_id": run_id,
            "generated_at": _now_iso(),
            "metrics": metrics,
            "agents": agent_rows,
            "stages": stage_rows,
        }


    def _generate_word_report(
        self,
        run_id: str,
        spec: StudyRunSpec,
        config: DelphiConfig,
        agents: List[AgentProfile],
        master: MasterAgentConfig,
        result: StudyResult,
    ) -> None:
        """
        Final post-synthesis step: build a consultancy-style report draft, ask the master model
        to do proofread-only polishing, then generate a Word (.docx) file and save it as an artifact.

        This step is best-effort: failures are logged but do not fail the run.
        """
        stage_id = f"stage_{_slug()}"
        self._stage_started(run_id, stage_id, "Finalize Word Report", "report_polish")

        # Import reporting lazily so the app can start even if python-docx is not installed.
        try:
            from . import reporting as _reporting  # type: ignore
        except Exception as e:
            msg = (
                "Word report generation requires the optional dependency 'python-docx'. "
                "Install it with: python -m pip install python-docx"
            )
            self.store.log_event(f"evt_{_slug()}", run_id, "WORD_REPORT_IMPORT_FAILED", {"error": str(e)})
            self.store.save_artifact(
                f"art_{_slug()}",
                run_id,
                "polished_report_error",
                {"error": msg, "details": str(e)},
            )
            self._stage_finished(run_id, stage_id, "Finalize Word Report", status="FAILED", details={"error": msg})
            return

        # Build a deterministic draft from pipeline outputs.
        exec_summary = None
        try:
            exec_summary = self._compute_execution_summary(run_id)
        except Exception:
            exec_summary = None

        draft_sections = _reporting.build_draft_report_sections(
            run_id=run_id,
            spec=spec,
            config=config,
            agents=agents,
            master=master,
            result=result,
            execution_summary=exec_summary,
        )

        polished_sections = dict(draft_sections)
        polished_by_llm = False

        try:
            master_prof = master.model_dump()
            if config.ai_delphi_model == "iconic_minds" and getattr(config, "iconic_minds_scope_guardrails", True):
                master_prof["system_prompt"] = prompts.apply_iconic_minds_guardrails(master_prof.get("system_prompt", ""))

            msg = prompts.prompt_master_polish_report(draft_sections)
            obj, raw, usage, err = self._chat_json(
                run_id,
                stage_id,
                "report_polish",
                "MASTER",
                master_prof,
                msg,
                retries=min(1, getattr(config, "retries", 0)),
                config=config,
            )

            if not err and isinstance(obj, dict):
                required = ["title", "date", "creator", "abstract", "method", "participants", "findings", "appendix"]
                if all(k in obj for k in required):
                    # Guardrail: reject heavy rewrites (user asked for proofread-only).
                    sim_find = _reporting.sections_similarity(draft_sections.get("findings", ""), str(obj.get("findings", "")))
                    sim_min = min(
                        _reporting.sections_similarity(draft_sections.get(k, ""), str(obj.get(k, "")))
                        for k in required
                        if k in draft_sections
                    )
                    if sim_find >= 0.92 and sim_min >= 0.90:
                        polished_sections = {k: str(obj.get(k, "")) for k in required}
                        polished_by_llm = True
                    else:
                        self.store.log_event(
                            f"evt_{_slug()}",
                            run_id,
                            "WORD_REPORT_REWRITE_DETECTED",
                            {"sim_findings": sim_find, "sim_min": sim_min},
                        )
                else:
                    self.store.log_event(
                        f"evt_{_slug()}",
                        run_id,
                        "WORD_REPORT_BAD_SCHEMA",
                        {"missing_keys": [k for k in required if k not in obj]},
                    )
        except Exception as e:
            self.store.log_event(f"evt_{_slug()}", run_id, "WORD_REPORT_POLISH_FAILED", {"error": str(e)})

        # Always generate a docx (polished or draft).
        try:
            docx_bytes = _reporting.build_docx_from_sections(polished_sections)
            artifact = _reporting.pack_docx_artifact(docx_bytes, run_id=run_id)
            artifact["polished_by_llm"] = polished_by_llm
            self.store.save_artifact(f"art_{_slug()}", run_id, "polished_report_docx", artifact)
            self.store.save_artifact(f"art_{_slug()}", run_id, "polished_report_sections", polished_sections)
            self._stage_finished(
                run_id,
                stage_id,
                "Finalize Word Report",
                status="SUCCEEDED",
                details={"polished_by_llm": polished_by_llm},
            )
        except Exception as e:
            self._stage_finished(
                run_id,
                stage_id,
                "Finalize Word Report",
                status="FAILED",
                details={"error": str(e)},
            )
            self.store.log_event(f"evt_{_slug()}", run_id, "WORD_REPORT_DOCX_FAILED", {"error": str(e)})

    def _chat_json(
        self,
        run_id: str,
        stage_id: str,
        stage_key: str,
        agent_id: str,
        profile: Dict[str, Any],
        messages: List[Dict[str, str]],
        retries: int,
        config: Optional[DelphiConfig] = None,
    ) -> Tuple[Optional[Dict[str, Any]], str, Dict[str, Any], Optional[str]]:
        """Returns (json_obj, raw_text, usage, error)."""
        attempts = 0
        last_err: Optional[str] = None
        raw_text = ""
        usage: Dict[str, Any] = {}

        is_master = agent_id == "MASTER"
        sys_prompt = self._effective_system_prompt(config, profile, is_master=is_master).strip()
        if sys_prompt:
            messages = [{"role": "system", "content": sys_prompt}] + messages

        policy = self._select_policy(config, stage_key, is_master=is_master)
        guidance = self._format_policy_guidance(policy, stage_key=stage_key)
        if guidance:
            messages = prompts.append_guidance_to_last_user_message(messages, guidance)

        while attempts <= retries:
            attempts += 1
            task_id = f"task_{stage_id}_{agent_id}_{attempts}"
            self.store.upsert_task(task_id, run_id, stage_id, agent_id, "RUNNING", started_at=_now_iso(), attempts=attempts)
            try:
                for m in messages:
                    self.store.log_message(f"msg_{_slug()}", run_id, stage_id, agent_id, m["role"], m["content"])

                self.store.log_event(
                    f"evt_{_slug()}",
                    run_id,
                    "LLM_CALL",
                    {
                        "stage_id": stage_id,
                        "stage_key": stage_key,
                        "agent_id": agent_id,
                        "model": profile.get("model"),
                        "temperature": float(profile.get("temperature", 0.3)),
                        "max_tokens": int(profile.get("max_tokens", 1200)),
                        "reasoning_effort": profile.get("reasoning_effort"),
                        "verbosity": profile.get("verbosity"),
                    },
                )

                res: ChatResult = self.provider.chat(
                    messages,
                    model=profile["model"],
                    api_key=profile.get("api_key"),
                    base_url=profile.get("base_url", "https://api.openai.com"),
                    temperature=float(profile.get("temperature", 0.3)),
                    max_tokens=int(profile.get("max_tokens", 1200)),
                    timeout_s=int(profile.get("timeout_s", 90)),
                    reasoning_effort=profile.get("reasoning_effort"),
                    verbosity=profile.get("verbosity"),
                    user_tag=f"{run_id}:{agent_id}:{stage_key}",
                )
                raw_text = res.content
                usage = res.usage or {}
                self.store.log_message(f"msg_{_slug()}", run_id, stage_id, agent_id, "assistant", raw_text)

                obj, err = _safe_json_loads(raw_text)
                if err is None and isinstance(obj, dict):
                    # Optional length enforcement
                    enforce = False
                    if config and config.response_length_mode == "strict":
                        enforce = True
                    if policy and getattr(policy.overall, "strict", False):
                        enforce = True

                    if enforce and policy and policy.overall.is_configured():
                        wc = _count_words_in_json(obj)
                        mn, mx = policy.overall.min_words, policy.overall.max_words
                        if not _within_bounds(wc, mn, mx):
                            last_err = f"Word count out of bounds: {wc} words (required {mn}-{mx})."
                            messages = messages + [
                                {
                                    "role": "user",
                                    "content": (
                                        f"Your last JSON is valid, but its total word count across all text fields is {wc} words. "
                                        f"Revise it to be between {mn} and {mx} words while preserving meaning and schema. "
                                        "Return ONLY JSON."
                                    ),
                                }
                            ]
                            self.store.upsert_task(task_id, run_id, stage_id, agent_id, "FAILED", finished_at=_now_iso(), attempts=attempts, error=last_err, usage=usage)
                            continue

                    self.store.upsert_task(task_id, run_id, stage_id, agent_id, "SUCCEEDED", finished_at=_now_iso(), attempts=attempts, usage=usage)
                    return obj, raw_text, usage, None

                # JSON correction reprompt
                last_err = err or "Invalid JSON"
                messages = messages + [
                    {
                        "role": "user",
                        "content": (
                            "Your last response was not valid JSON. "
                            "Return ONLY a valid JSON object matching the required schema. No commentary."
                        ),
                    }
                ]
                self.store.upsert_task(task_id, run_id, stage_id, agent_id, "FAILED", finished_at=_now_iso(), attempts=attempts, error=last_err, usage=usage)
            except Exception as e:
                last_err = str(e)
                self.store.upsert_task(task_id, run_id, stage_id, agent_id, "FAILED", finished_at=_now_iso(), attempts=attempts, error=last_err, usage=usage)
        return None, raw_text, usage, last_err

    def _chat_text(
        self,
        run_id: str,
        stage_id: str,
        stage_key: str,
        agent_id: str,
        profile: Dict[str, Any],
        messages: List[Dict[str, str]],
        retries: int,
        config: Optional[DelphiConfig] = None,
    ) -> Tuple[Optional[str], Dict[str, Any], Optional[str]]:
        attempts = 0
        last_err: Optional[str] = None
        usage: Dict[str, Any] = {}

        is_master = agent_id == "MASTER"
        sys_prompt = self._effective_system_prompt(config, profile, is_master=is_master).strip()
        if sys_prompt:
            messages = [{"role": "system", "content": sys_prompt}] + messages

        policy = self._select_policy(config, stage_key, is_master=is_master)
        guidance = self._format_policy_guidance(policy, stage_key=stage_key)
        if guidance:
            messages = prompts.append_guidance_to_last_user_message(messages, guidance)

        while attempts <= retries:
            attempts += 1
            task_id = f"task_{stage_id}_{agent_id}_{attempts}"
            self.store.upsert_task(task_id, run_id, stage_id, agent_id, "RUNNING", started_at=_now_iso(), attempts=attempts)
            try:
                for m in messages:
                    self.store.log_message(f"msg_{_slug()}", run_id, stage_id, agent_id, m["role"], m["content"])

                self.store.log_event(
                    f"evt_{_slug()}",
                    run_id,
                    "LLM_CALL",
                    {
                        "stage_id": stage_id,
                        "stage_key": stage_key,
                        "agent_id": agent_id,
                        "model": profile.get("model"),
                        "temperature": float(profile.get("temperature", 0.3)),
                        "max_tokens": int(profile.get("max_tokens", 1200)),
                        "reasoning_effort": profile.get("reasoning_effort"),
                        "verbosity": profile.get("verbosity"),
                    },
                )

                res: ChatResult = self.provider.chat(
                    messages,
                    model=profile["model"],
                    api_key=profile.get("api_key"),
                    base_url=profile.get("base_url", "https://api.openai.com"),
                    temperature=float(profile.get("temperature", 0.3)),
                    max_tokens=int(profile.get("max_tokens", 1200)),
                    timeout_s=int(profile.get("timeout_s", 90)),
                    reasoning_effort=profile.get("reasoning_effort"),
                    verbosity=profile.get("verbosity"),
                    user_tag=f"{run_id}:{agent_id}:{stage_key}",
                )
                usage = res.usage or {}
                self.store.log_message(f"msg_{_slug()}", run_id, stage_id, agent_id, "assistant", res.content)

                enforce = False
                if config and config.response_length_mode == "strict":
                    enforce = True
                if policy and getattr(policy.overall, "strict", False):
                    enforce = True
                if enforce and policy and policy.overall.is_configured():
                    wc = _count_words(res.content)
                    mn, mx = policy.overall.min_words, policy.overall.max_words
                    if not _within_bounds(wc, mn, mx):
                        last_err = f"Word count out of bounds: {wc} words (required {mn}-{mx})."
                        messages = messages + [
                            {
                                "role": "user",
                                "content": (
                                    f"Your last response is {wc} words. Revise it to be between {mn} and {mx} words while preserving meaning. "
                                    "Return only the revised answer."
                                ),
                            }
                        ]
                        self.store.upsert_task(task_id, run_id, stage_id, agent_id, "FAILED", finished_at=_now_iso(), attempts=attempts, error=last_err, usage=usage)
                        continue

                self.store.upsert_task(task_id, run_id, stage_id, agent_id, "SUCCEEDED", finished_at=_now_iso(), attempts=attempts, usage=usage)
                return res.content, usage, None
            except Exception as e:
                last_err = str(e)
                self.store.upsert_task(task_id, run_id, stage_id, agent_id, "FAILED", finished_at=_now_iso(), attempts=attempts, error=last_err, usage=usage)
        return None, usage, last_err

    def _parallel_json_stage(
        self,
        run_id: str,
        stage_name: str,
        stage_key: str,
        agents: List[AgentProfile],
        build_messages_fn,
        config: DelphiConfig,
    ) -> Tuple[str, Dict[str, Dict[str, Any]], bool]:
        """Run a JSON-returning stage in parallel across agents.

        - `stage_key` is a stable identifier used for per-stage response policies and audit filtering.
        """
        stage_id = f"stage_{_slug()}"
        self._stage_started(run_id, stage_id, stage_name, stage_key)

        results: Dict[str, Dict[str, Any]] = {}
        errors: Dict[str, str] = {}
        with ThreadPoolExecutor(max_workers=min(10, len(agents))) as ex:
            future_map = {}
            for a in agents:
                prof = a.model_dump()
                msgs = build_messages_fn(a)
                future = ex.submit(self._chat_json, run_id, stage_id, stage_key, a.agent_id, prof, msgs, config.retries, config)
                future_map[future] = a

            try:
                for fut in as_completed(future_map, timeout=config.stage_deadline_s):
                    a = future_map[fut]
                    obj, raw, usage, err = fut.result()
                    if err is None and obj is not None:
                        results[a.agent_id] = obj
                    else:
                        errors[a.agent_id] = err or "error"
            except Exception:
                # stage deadline reached; remaining considered timed out
                pass

            for fut, a in future_map.items():
                if a.agent_id in results or a.agent_id in errors:
                    continue
                errors[a.agent_id] = "TIMED_OUT"

        quorum_n = math.ceil(len(agents) * config.quorum_fraction)
        quorum_ok = len(results) >= quorum_n

        self._stage_finished(run_id, stage_id, stage_name, stage_key, ok=quorum_ok, status="SUCCEEDED" if quorum_ok else "FAILED", details={"responses": len(results), "errors": errors, "quorum_required": quorum_n})
        return stage_id, results, quorum_ok

    # -------------------------
    # Item-rating Delphi pipeline
    # -------------------------
    def _run_item_rating(
        self,
        run_id: str,
        spec: StudyRunSpec,
        config: DelphiConfig,
        agents: List[AgentProfile],
        master: MasterAgentConfig,
    ) -> Tuple[Dict[str, Any], int, bool]:
        # Stage 1: elicitation or seed
        raw_items: List[str] = []
        rationales: Dict[str, List[str]] = {}

        if spec.seed_items:
            raw_items = [s.strip() for s in spec.seed_items if s.strip()]
            self.store.log_event(f"evt_{_slug()}", run_id, "SEED_ITEMS_USED", {"n": len(raw_items)})
            quorum_ok = True
        else:
            def build_msgs(a: AgentProfile):
                return prompts.prompt_round1_elicit_items(spec.topic, spec.problem_statement, spec.items_per_agent)

            _, resp, quorum_ok = self._parallel_json_stage(run_id, "Round 1 - Item Elicitation", "item_elicitation", agents, build_msgs, config)
            if not quorum_ok:
                return {"error": "Quorum not reached in elicitation."}, 0, False
            for aid, obj in resp.items():
                items = obj.get("items", [])
                for it in items:
                    txt = str(it.get("text", "")).strip()
                    rat = str(it.get("rationale", "")).strip()
                    if txt:
                        raw_items.append(txt)
                        rationales.setdefault(txt, []).append(rat)

        # Stage 2: consolidate items with master
        stage_id = f"stage_{_slug()}"
        self._stage_started(run_id, stage_id, "Consolidate Items", "item_consolidation")
        master_prof = master.model_dump()
        if config.ai_delphi_model == "iconic_minds" and config.iconic_minds_scope_guardrails:
            master_prof["system_prompt"] = prompts.apply_iconic_minds_guardrails(master_prof.get("system_prompt",""))
        msg = prompts.prompt_master_consolidate_items(spec.topic, raw_items)
        obj, raw, usage, err = self._chat_json(run_id, stage_id, "item_consolidation", "MASTER", master_prof, msg, retries=config.retries, config=config)
        if err is None and obj is not None and isinstance(obj.get("items"), list):
            items = [str(x).strip() for x in obj["items"] if str(x).strip()]
        else:
            # fallback dedup
            seen = set()
            items = []
            for it in raw_items:
                key = re.sub(r"\s+", " ", it.lower()).strip()
                if key not in seen:
                    seen.add(key)
                    items.append(it.strip())
            items = items[:30]
        self._stage_finished(run_id, stage_id, "Consolidate Items", "item_consolidation", ok=True, status="SUCCEEDED", details={"n_items": len(items)})

        # Rating rounds
        dims = [d.model_dump() for d in spec.rating_dimensions]
        all_rounds: List[Dict[str, Any]] = []
        prev_stats = None
        feedback_text: Optional[str] = None
        rounds_completed = 0

        for rnd in range(1, config.max_rounds + 1):
            def build_msgs_rating(a: AgentProfile):
                return prompts.prompt_round_rating(
                    spec.topic,
                    spec.problem_statement,
                    items,
                    dims,
                    round_index=rnd,
                    feedback=feedback_text,
                )

            stage_name = f"Round {rnd} - Rating"
            # NOTE: stage_key must be stable and template-consistent for per-stage response policies and audit filtering.
            _, resp, quorum_ok = self._parallel_json_stage(run_id, stage_name, "item_rating_round", agents, build_msgs_rating, config)
            if not quorum_ok:
                return {"error": f"Quorum not reached in rating round {rnd}."}, rounds_completed, False

            # Build ratings matrix: item->dim->scores
            ratings_matrix: Dict[str, Dict[str, List[int]]] = {it: {d['name']: [] for d in dims} for it in items}
            justifications: Dict[str, List[str]] = {it: [] for it in items}

            for aid, obj in resp.items():
                for r in obj.get("ratings", []):
                    idx = int(r.get("item_index", 0))
                    if idx < 1 or idx > len(items):
                        continue
                    item = items[idx - 1]
                    scores = r.get("scores", {}) or {}
                    for d in dims:
                        dn = d["name"]
                        sc = scores.get(dn)
                        if isinstance(sc, (int, float)):
                            ratings_matrix[item][dn].append(int(sc))
                    j = str(r.get("justification", "")).strip()
                    if j:
                        justifications[item].append(j)

            stats = compute_item_stats(ratings_matrix)
            rounds_completed = rnd
            all_rounds.append({
                "round": rnd,
                "ratings_matrix": ratings_matrix,
                "stats": {it: {dn: stats[it][dn].__dict__ for dn in stats[it]} for it in stats},
                "responses": len(resp),
            })

            # stopping rules
            cons_ok = consensus_met(stats, config.consensus_iqr_threshold)
            stab_ok = False
            if prev_stats is not None:
                stab_ok = stability_met(prev_stats, stats, config.stability_median_threshold)

            if rnd >= config.min_rounds and cons_ok and (stab_ok or prev_stats is None):
                self.store.log_event(f"evt_{_slug()}", run_id, "STOPPING_RULE_MET", {"round": rnd, "consensus": cons_ok, "stability": stab_ok})
                break

            # generate feedback for next round (unless last)
            if rnd < config.max_rounds:
                stage_id_fb = f"stage_{_slug()}"
                self._stage_started(run_id, stage_id_fb, f"Feedback after Round {rnd}", "questionnaire_feedback")
                stats_md = stats_markdown_table(stats)
                # naive qualitative theme extractor
                themes = []
                for it, js in justifications.items():
                    if not js:
                        continue
                    themes.append(f"{it}: " + " / ".join(js[:3]))
                themes_txt = "\n".join(themes)[:5000]

                fb_msg = prompts.prompt_master_feedback_item_rating(rnd, stats_md, themes_txt)
                fb_obj, _, _, fb_err = self._chat_json(run_id, stage_id_fb, "rating_feedback", "MASTER", master_prof, fb_msg, retries=config.retries, config=config)
                if fb_err is None and fb_obj and isinstance(fb_obj.get("feedback"), str):
                    feedback_text = fb_obj["feedback"]
                else:
                    feedback_text = "Group ratings have been aggregated; please reconsider your ratings in light of dispersion on some items."
                self._stage_finished(run_id, stage_id_fb, f"Feedback after Round {rnd}", "rating_feedback", ok=True, status="SUCCEEDED", details={"feedback_len": len(feedback_text)})

            prev_stats = stats

        outputs = {
            "items": items,
            "rounds": all_rounds,
            "final_stats": all_rounds[-1]["stats"] if all_rounds else {},
            "feedback_last": feedback_text,
        }
        self.store.save_artifact(f"art_{_slug()}", run_id, "item_rating_results", outputs)
        return outputs, rounds_completed, True

    # -------------------------
    # Questionnaire (AI-Delphi style) pipeline
    # -------------------------
    def _run_questionnaire(
        self,
        run_id: str,
        spec: StudyRunSpec,
        config: DelphiConfig,
        agents: List[AgentProfile],
        master: MasterAgentConfig,
    ) -> Tuple[Dict[str, Any], int, bool]:
        if not spec.questionnaire:
            raise ValueError("Questionnaire template requires spec.questionnaire (list of questions).")
        questionnaire = [q.strip() for q in spec.questionnaire if q.strip()]
        if not questionnaire:
            raise ValueError("Questionnaire is empty.")
        master_prof = master.model_dump()
        if config.ai_delphi_model == "iconic_minds" and config.iconic_minds_scope_guardrails:
            master_prof["system_prompt"] = prompts.apply_iconic_minds_guardrails(master_prof.get("system_prompt",""))

        per_question_feedback: Optional[Dict[int, str]] = None
        all_rounds: List[Dict[str, Any]] = []
        rounds_completed = 0

        for rnd in range(1, config.max_rounds + 1):
            def build_msgs(a: AgentProfile):
                return prompts.prompt_round_questionnaire(
                    spec.topic,
                    spec.problem_statement,
                    questionnaire,
                    round_index=rnd,
                    per_question_feedback=per_question_feedback,
                )

            stage_name = f"Round {rnd} - Questionnaire"
            # NOTE: stage_key must be template-consistent for per-stage response policies and auditing.
            _, resp, quorum_ok = self._parallel_json_stage(run_id, stage_name, "questionnaire_round", agents, build_msgs, config)
            if not quorum_ok:
                return {"error": f"Quorum not reached in questionnaire round {rnd}."}, rounds_completed, False

            # Organize answers per question
            answers_by_q: Dict[int, List[str]] = {i+1: [] for i in range(len(questionnaire))}
            for aid, obj in resp.items():
                for a in obj.get("answers", []):
                    qi = int(a.get("question_index", 0))
                    if qi in answers_by_q:
                        ans = str(a.get("answer","")).strip()
                        if ans:
                            answers_by_q[qi].append(ans)

            all_rounds.append({"round": rnd, "answers_by_question": answers_by_q, "responses": len(resp)})
            rounds_completed = rnd

            # Stop after min_rounds if we are not generating further feedback
            if rnd >= config.min_rounds and rnd == config.max_rounds:
                break
            if rnd >= config.min_rounds and not config.questionnaire_followup and rnd >= 2:
                break

            # Feedback generation per question (for next round)
            if rnd < config.max_rounds:
                stage_id_fb = f"stage_{_slug()}"
                self._stage_started(run_id, stage_id_fb, f"Feedback after Round {rnd}", "questionnaire_feedback")
                new_fb: Dict[int, str] = {}
                followups_map: Dict[int, List[str]] = {}
                for qi, qtext in enumerate(questionnaire, start=1):
                    ans = answers_by_q.get(qi, [])
                    msg = prompts.prompt_master_feedback_questionnaire(qi, qtext, ans, propose_followups=config.questionnaire_followup)
                    fb_obj, _, _, fb_err = self._chat_json(run_id, stage_id_fb, "questionnaire_feedback", "MASTER", master_prof, msg, retries=config.retries, config=config)

                    if fb_err is None and fb_obj:
                        agreement = fb_obj.get("agreement", [])
                        disagreements = fb_obj.get("disagreements", [])
                        missing = fb_obj.get("missing_considerations", [])
                        summary = str(fb_obj.get("summary", "")).strip()
                        fups = fb_obj.get("followups", [])

                        # Normalize list fields
                        agreement = agreement if isinstance(agreement, list) else []
                        disagreements = disagreements if isinstance(disagreements, list) else []
                        missing = missing if isinstance(missing, list) else []
                        fups = fups if isinstance(fups, list) else []

                        agreement = [str(x).strip() for x in agreement if str(x).strip()]
                        disagreements = [str(x).strip() for x in disagreements if str(x).strip()]
                        missing = [str(x).strip() for x in missing if str(x).strip()]
                        fups = [str(x).strip() for x in fups if str(x).strip()]

                        followups_map[qi] = fups

                        parts: List[str] = []
                        if agreement:
                            parts.append("Points of agreement:\n" + "\n".join([f"- {x}" for x in agreement[:8]]))
                        if disagreements:
                            parts.append("Key disagreements:\n" + "\n".join([f"- {x}" for x in disagreements[:8]]))
                        if missing:
                            parts.append("Missing considerations:\n" + "\n".join([f"- {x}" for x in missing[:8]]))
                        if summary:
                            parts.append("Summary:\n" + summary)
                        if fups:
                            parts.append("Clarification questions:\n" + "\n".join([f"- {x}" for x in fups[:3]]))

                        fb_txt = "\n\n".join(parts).strip()
                        new_fb[qi] = (
                            fb_txt
                            if fb_txt
                            else "Please reconsider your answer in light of the range of perspectives offered by the panel."
                        )
                    else:
                        new_fb[qi] = "Please reconsider your answer in light of the range of perspectives offered by the panel."

                per_question_feedback = new_fb
                self._stage_finished(run_id, stage_id_fb, f"Feedback after Round {rnd}", "questionnaire_feedback", ok=True, status="SUCCEEDED", details={"n_questions": len(questionnaire)})

        # Final synthesis
        stage_id_fin = f"stage_{_slug()}"
        self._stage_started(run_id, stage_id_fin, "Final Synthesis", "final_synthesis")
        # Build synthesis prompt
        per_q_blocks = []
        last_round = all_rounds[-1]["answers_by_question"]
        for qi, qtext in enumerate(questionnaire, start=1):
            ans = last_round.get(qi, [])
            per_q_blocks.append(f"Q{qi}: {qtext}\nAnswers:\n" + "\n".join([f"- {a}" for a in ans][:20]))
        synth_user = (
            "You are the Delphi facilitator. Produce a final report.\n\n"
            f"Topic: {spec.topic}\n"
            f"Problem: {spec.problem_statement or '(none)'}\n\n"
            "For each question, synthesize a concise consensus view, key disagreements, and actionable implications. "
            "Then provide an overall cross-question synthesis.\n\n"
            'Return ONLY JSON: {"overall_synthesis": "...", "per_question": [{"question_index": 1, "consensus": "...", "disagreements": "...", "implications": "..."}, ...]}'
            "\n\n"
            + "\n\n".join(per_q_blocks)
        )
        synth_msgs = [{"role": "user", "content": synth_user}]
        synth_obj, raw, usage, err = self._chat_json(run_id, stage_id_fin, "final_synthesis", "MASTER", master_prof, synth_msgs, retries=config.retries, config=config)
        if err is None and synth_obj:
            final_report = synth_obj
        else:
            final_report = {"overall_synthesis": "Synthesis failed.", "per_question": []}
        self._stage_finished(run_id, stage_id_fin, "Final Synthesis", "final_synthesis", ok=(err is None), status="SUCCEEDED" if (err is None) else "FAILED", details={"ok": err is None})

        outputs = {
            "questionnaire": questionnaire,
            "rounds": all_rounds,
            "final_report": final_report,
        }
        self.store.save_artifact(f"art_{_slug()}", run_id, "questionnaire_results", outputs)
        return outputs, rounds_completed, True



    # -------------------------
    # Recursive reasoning Delphi pipeline (3-stage)
    # -------------------------
    def _run_recursive_reasoning(
        self,
        run_id: str,
        spec: StudyRunSpec,
        config: DelphiConfig,
        agents: List[AgentProfile],
        master: MasterAgentConfig,
    ) -> Tuple[Dict[str, Any], int, bool]:
        """A fixed 3-round pipeline:

        Round 1: Pool participants' *understanding* of the problem/questions and their reasoning (no solutions).
        Round 2: Participants review the pooled understandings and propose a solution/answer with reasoning.
        Round 3: Participants review pooled solutions and propose a final solution with final reasoning.

        Master: Collates after R1 and R2, and produces a final synthesis report after R3.
        """
        questions = [q.strip() for q in (spec.questionnaire or []) if q.strip()]
        if not questions:
            raise ValueError("Recursive reasoning template requires spec.questionnaire (list of questions).")

        master_prof = master.model_dump()
        if config.ai_delphi_model == "iconic_minds" and getattr(config, "iconic_minds_scope_guardrails", True):
            master_prof["system_prompt"] = prompts.apply_iconic_minds_guardrails(master_prof.get("system_prompt", ""))

        rounds: List[Dict[str, Any]] = []

        # -----------------
        # Round 1: understanding + reasoning only
        # -----------------
        def build_msgs_under(a: AgentProfile):
            return prompts.prompt_recursive_understanding(
                topic=spec.topic,
                problem_statement=spec.problem_statement,
                questions=questions,
                round_index=1,
            )

        _, resp1, quorum_ok = self._parallel_json_stage(
            run_id,
            "Round 1 - Understanding + reasoning (no solutions)",
            "recursive_understanding_round",
            agents,
            build_msgs_under,
            config,
        )
        if not quorum_ok:
            return {"error": "Quorum not reached in Round 1 (understanding)."}, 0, False

        understandings: List[Dict[str, Any]] = []
        for aid, obj in resp1.items():
            if not isinstance(obj, dict):
                continue
            understandings.append(
                {
                    "agent_id": aid,
                    "understanding": str(obj.get("understanding", "")).strip(),
                    "reasoning": str(obj.get("reasoning", "")).strip(),
                }
            )

        rounds.append(
            {
                "round": 1,
                "stage": "understanding",
                "responses": len(resp1),
                "understandings": understandings,
            }
        )

        # Master digest of understandings
        stage_id_u = f"stage_{_slug()}"
        self._stage_started(run_id, stage_id_u, "Collate Understandings", "recursive_understanding_digest")
        digest1: Dict[str, Any] = {
            "summary": "",
            "agreements": [],
            "disagreements": [],
            "missing_considerations": [],
            "clarification_questions": [],
        }
        try:
            msg = prompts.prompt_master_recursive_understanding_digest(
                topic=spec.topic,
                problem_statement=spec.problem_statement,
                questions=questions,
                understandings=understandings,
            )
            obj, raw, usage, err = self._chat_json(
                run_id,
                stage_id_u,
                "recursive_understanding_digest",
                "MASTER",
                master_prof,
                msg,
                retries=config.retries,
                config=config,
            )
            if err is None and isinstance(obj, dict):
                digest1 = {
                    "summary": str(obj.get("summary", "")).strip(),
                    "agreements": obj.get("agreements", []) if isinstance(obj.get("agreements", []), list) else [],
                    "disagreements": obj.get("disagreements", []) if isinstance(obj.get("disagreements", []), list) else [],
                    "missing_considerations": obj.get("missing_considerations", []) if isinstance(obj.get("missing_considerations", []), list) else [],
                    "clarification_questions": obj.get("clarification_questions", []) if isinstance(obj.get("clarification_questions", []), list) else [],
                }
        except Exception as e:
            self.store.log_event(f"evt_{_slug()}", run_id, "RECURSIVE_UNDERSTANDING_DIGEST_FAILED", {"error": str(e)})

        self._stage_finished(
            run_id,
            stage_id_u,
            "Collate Understandings",
            "recursive_understanding_digest",
            ok=True,
            status="SUCCEEDED",
            details={"responses": len(resp1)},
        )

        # -----------------
        # Round 2: propose solutions + reasoning
        # -----------------
        def build_msgs_solution(a: AgentProfile):
            return prompts.prompt_recursive_solution(
                topic=spec.topic,
                problem_statement=spec.problem_statement,
                questions=questions,
                understanding_digest=digest1,
                round_index=2,
            )

        _, resp2, quorum_ok = self._parallel_json_stage(
            run_id,
            "Round 2 - Proposed Solutions",
            "recursive_solution_round",
            agents,
            build_msgs_solution,
            config,
        )
        if not quorum_ok:
            return {"error": "Quorum not reached in Round 2 (solutions)."}, 1, False

        solutions: List[Dict[str, Any]] = []
        for aid, obj in resp2.items():
            if not isinstance(obj, dict):
                continue
            solutions.append(
                {
                    "agent_id": aid,
                    "solution": str(obj.get("solution", "")).strip(),
                    "reasoning": str(obj.get("reasoning", "")).strip(),
                }
            )

        rounds.append(
            {
                "round": 2,
                "stage": "solutions",
                "responses": len(resp2),
                "solutions": solutions,
            }
        )

        # Master digest of solutions
        stage_id_s = f"stage_{_slug()}"
        self._stage_started(run_id, stage_id_s, "Collate Proposed Solutions", "recursive_solution_digest")
        digest2: Dict[str, Any] = {
            "summary": "",
            "agreements": [],
            "disagreements": [],
            "missing_considerations": [],
            "clarification_questions": [],
        }
        try:
            msg = prompts.prompt_master_recursive_solution_digest(
                topic=spec.topic,
                problem_statement=spec.problem_statement,
                questions=questions,
                solutions=solutions,
            )
            obj, raw, usage, err = self._chat_json(
                run_id,
                stage_id_s,
                "recursive_solution_digest",
                "MASTER",
                master_prof,
                msg,
                retries=config.retries,
                config=config,
            )
            if err is None and isinstance(obj, dict):
                digest2 = {
                    "summary": str(obj.get("summary", "")).strip(),
                    "agreements": obj.get("agreements", []) if isinstance(obj.get("agreements", []), list) else [],
                    "disagreements": obj.get("disagreements", []) if isinstance(obj.get("disagreements", []), list) else [],
                    "missing_considerations": obj.get("missing_considerations", []) if isinstance(obj.get("missing_considerations", []), list) else [],
                    "clarification_questions": obj.get("clarification_questions", []) if isinstance(obj.get("clarification_questions", []), list) else [],
                }
        except Exception as e:
            self.store.log_event(f"evt_{_slug()}", run_id, "RECURSIVE_SOLUTION_DIGEST_FAILED", {"error": str(e)})

        self._stage_finished(
            run_id,
            stage_id_s,
            "Collate Proposed Solutions",
            "recursive_solution_digest",
            ok=True,
            status="SUCCEEDED",
            details={"responses": len(resp2)},
        )

        # -----------------
        # Round 3: final solution + final reasoning
        # -----------------
        def build_msgs_final(a: AgentProfile):
            return prompts.prompt_recursive_final(
                topic=spec.topic,
                problem_statement=spec.problem_statement,
                questions=questions,
                solution_digest=digest2,
                round_index=3,
            )

        _, resp3, quorum_ok = self._parallel_json_stage(
            run_id,
            "Round 3 - Final Solutions",
            "recursive_final_round",
            agents,
            build_msgs_final,
            config,
        )
        if not quorum_ok:
            return {"error": "Quorum not reached in Round 3 (final solutions)."}, 2, False

        finals: List[Dict[str, Any]] = []
        for aid, obj in resp3.items():
            if not isinstance(obj, dict):
                continue
            finals.append(
                {
                    "agent_id": aid,
                    "final_solution": str(obj.get("final_solution", "")).strip(),
                    "final_reasoning": str(obj.get("final_reasoning", "")).strip(),
                }
            )

        rounds.append(
            {
                "round": 3,
                "stage": "final",
                "responses": len(resp3),
                "final_solutions": finals,
            }
        )

        # Master synthesis
        stage_id_fin = f"stage_{_slug()}"
        self._stage_started(run_id, stage_id_fin, "Final Synthesis", "final_synthesis")
        final_report: Dict[str, Any] = {
            "summary": "",
            "recommended_answer": "",
            "agreements": [],
            "disagreements": [],
            "convergences": [],
            "divergences": [],
            "open_questions": [],
        }

        try:
            msg = prompts.prompt_master_recursive_final_synthesis(
                topic=spec.topic,
                problem_statement=spec.problem_statement,
                questions=questions,
                understanding_digest=digest1,
                solution_digest=digest2,
                final_solutions=finals,
            )
            obj, raw, usage, err = self._chat_json(
                run_id,
                stage_id_fin,
                "final_synthesis",
                "MASTER",
                master_prof,
                msg,
                retries=config.retries,
                config=config,
            )
            if err is None and isinstance(obj, dict):
                final_report = {
                    "summary": str(obj.get("summary", "")).strip(),
                    "recommended_answer": str(obj.get("recommended_answer", "")).strip(),
                    "agreements": obj.get("agreements", []) if isinstance(obj.get("agreements", []), list) else [],
                    "disagreements": obj.get("disagreements", []) if isinstance(obj.get("disagreements", []), list) else [],
                    "convergences": obj.get("convergences", []) if isinstance(obj.get("convergences", []), list) else [],
                    "divergences": obj.get("divergences", []) if isinstance(obj.get("divergences", []), list) else [],
                    "open_questions": obj.get("open_questions", []) if isinstance(obj.get("open_questions", []), list) else [],
                }
        except Exception as e:
            self.store.log_event(f"evt_{_slug()}", run_id, "RECURSIVE_FINAL_SYNTHESIS_FAILED", {"error": str(e)})

        self._stage_finished(
            run_id,
            stage_id_fin,
            "Final Synthesis",
            "final_synthesis",
            ok=True,
            status="SUCCEEDED",
            details={"responses": len(resp3)},
        )

        outputs = {
            "questionnaire": questions,
            "rounds": rounds,
            "understanding_digest": digest1,
            "solution_digest": digest2,
            "final_report": final_report,
        }
        self.store.save_artifact(f"art_{_slug()}", run_id, "recursive_reasoning_results", outputs)
        return outputs, 3, True


    # -------------------------
    # Forecasting Delphi pipeline
    # -------------------------
    def _run_forecasting(
        self,
        run_id: str,
        spec: StudyRunSpec,
        config: DelphiConfig,
        agents: List[AgentProfile],
        master: MasterAgentConfig,
    ) -> Tuple[Dict[str, Any], int, bool]:
        questions = [q.strip() for q in (spec.forecast_questions or []) if q.strip()]
        if not questions:
            return {"error": "No forecast questions provided."}, 0, False

        master_prof = master.model_dump()
        if config.ai_delphi_model == "iconic_minds" and config.iconic_minds_scope_guardrails:
            master_prof["system_prompt"] = prompts.apply_iconic_minds_guardrails(master_prof.get("system_prompt", ""))

        all_rounds: List[Dict[str, Any]] = []
        feedback_text: Optional[str] = None
        prev_aggs: Optional[Dict[int, ForecastAgg]] = None

        rounds_completed = 0
        quorum_ok = True

        for rnd in range(1, config.max_rounds + 1):
            def build_msgs(a: AgentProfile):
                return prompts.prompt_round_forecasting(
                    spec.topic,
                    spec.problem_statement,
                    questions,
                    round_index=rnd,
                    feedback=feedback_text,
                )

            stage_name = f"Round {rnd} - Forecasts"
            stage_id, resp, qok = self._parallel_json_stage(run_id, stage_name, "forecast_round", agents, build_msgs, config)
            if not qok:
                quorum_ok = False
                break

            # Collect forecasts per question
            by_q_probs: Dict[int, List[float]] = {i: [] for i in range(1, len(questions) + 1)}
            by_q_confs: Dict[int, List[int]] = {i: [] for i in range(1, len(questions) + 1)}
            by_q_rats: Dict[int, List[str]] = {i: [] for i in range(1, len(questions) + 1)}

            raw_by_agent: Dict[str, Any] = {}
            for aid, obj in resp.items():
                raw_by_agent[aid] = obj
                for f in obj.get("forecasts", []) or []:
                    try:
                        qi = int(f.get("question_index"))
                        p = float(f.get("probability"))
                        c = int(f.get("confidence", 3))
                        rat = str(f.get("rationale", "")).strip()
                    except Exception:
                        continue
                    if 1 <= qi <= len(questions):
                        p = max(0.0, min(100.0, p))
                        c = max(1, min(5, c))
                        by_q_probs[qi].append(p)
                        by_q_confs[qi].append(c)
                        if rat:
                            by_q_rats[qi].append(rat)

            # Aggregate
            aggs: Dict[int, ForecastAgg] = {}
            for qi in range(1, len(questions) + 1):
                aggs[qi] = aggregate_forecasts(
                    by_q_probs[qi],
                    by_q_confs[qi],
                    weight_by_confidence=config.forecast_weight_by_confidence,
                    beta_pooling=config.forecast_beta_pooling,
                    beta_draws=config.forecast_beta_draws,
                )

            table_md = forecast_markdown_table(questions, aggs)
            rationale_themes = "\n".join([f"Q{qi}: " + "; ".join(by_q_rats[qi][:8]) for qi in range(1, len(questions) + 1)])

            round_rec = {
                "round": rnd,
                "responses": raw_by_agent,
                "aggregates": {qi: aggs[qi].__dict__ for qi in aggs},
                "aggregate_table_md": table_md,
            }
            all_rounds.append(round_rec)
            rounds_completed = rnd

            # stopping: consensus/stability on IQR and posterior median
            consensus_now = True
            for qi, a in aggs.items():
                if math.isnan(a.iqr) or a.iqr > config.consensus_iqr_threshold:
                    consensus_now = False
                    break

            stability_now = False
            if prev_aggs is not None:
                stability_now = True
                for qi, a in aggs.items():
                    prev = prev_aggs.get(qi)
                    if prev is None or math.isnan(prev.median) or math.isnan(a.median):
                        stability_now = False
                        break
                    if abs(a.median - prev.median) > config.stability_median_threshold:
                        stability_now = False
                        break

            # Feedback generation (unless we're stopping)
            if rnd < config.max_rounds:
                if rnd >= config.min_rounds and (consensus_now or stability_now):
                    prev_aggs = aggs
                    break

                fb_stage = f"stage_{_slug()}"
                self._stage_started(run_id, fb_stage, f"Feedback after Round {rnd}", "priority_feedback")
                msgs = prompts.prompt_master_feedback_forecasting(rnd, table_md, rationale_themes)
                # include master instructions as additional context
                if spec.master_instructions.strip():
                    msgs = msgs + [{"role": "user", "content": f"Additional facilitator instructions: {spec.master_instructions.strip()}"}]
                fb_obj, raw, usage, err = self._chat_json(run_id, fb_stage, "forecast_feedback", "MASTER", master_prof, msgs, retries=config.retries, config=config)
                if err is None and fb_obj and isinstance(fb_obj.get("feedback"), str):
                    feedback_text = fb_obj["feedback"].strip()
                else:
                    feedback_text = "Please reconsider your forecasts in light of the aggregated distribution and rationales."
                self._stage_finished(run_id, fb_stage, f"Feedback after Round {rnd}", "priority_feedback", ok=(err is None), status="SUCCEEDED" if (err is None) else "FAILED", details={"ok": err is None})

            prev_aggs = aggs

        outputs = {
            "questions": questions,
            "rounds": all_rounds,
            "final_aggregates": all_rounds[-1]["aggregates"] if all_rounds else {},
            "final_table_md": all_rounds[-1]["aggregate_table_md"] if all_rounds else "",
        }
        self.store.save_artifact(f"art_{_slug()}", run_id, "forecasting_results", outputs)
        return outputs, rounds_completed, quorum_ok

    # -------------------------
    # Priority-ranking Delphi pipeline
    # -------------------------
    def _run_priority_ranking(
        self,
        run_id: str,
        spec: StudyRunSpec,
        config: DelphiConfig,
        agents: List[AgentProfile],
        master: MasterAgentConfig,
    ) -> Tuple[Dict[str, Any], int, bool]:
        # Stage 1: item elicitation or seed
        raw_items: List[str] = []
        if spec.seed_items:
            raw_items = [s.strip() for s in spec.seed_items if s.strip()]
            quorum_ok = True
        else:
            def build_msgs(a: AgentProfile):
                return prompts.prompt_round1_elicit_items(spec.topic, spec.problem_statement, spec.items_per_agent)

            _, resp, quorum_ok = self._parallel_json_stage(run_id, "Round 1 - Item Elicitation", "item_elicitation", agents, build_msgs, config)
            if not quorum_ok:
                return {"error": "Quorum not reached in elicitation."}, 0, False
            for _, obj in resp.items():
                for it in obj.get("items", []) or []:
                    txt = str(it.get("text", "")).strip()
                    if txt:
                        raw_items.append(txt)

        # Stage 2: consolidate items
        stage_id = f"stage_{_slug()}"
        self._stage_started(run_id, stage_id, "Consolidate Items", "item_consolidation")
        master_prof = master.model_dump()
        if config.ai_delphi_model == "iconic_minds" and config.iconic_minds_scope_guardrails:
            master_prof["system_prompt"] = prompts.apply_iconic_minds_guardrails(master_prof.get("system_prompt", ""))
        msg = prompts.prompt_master_consolidate_items(spec.topic, raw_items)
        if spec.master_instructions.strip():
            msg = msg + [{"role": "user", "content": f"Additional facilitator instructions: {spec.master_instructions.strip()}"}]
        obj, raw, usage, err = self._chat_json(run_id, stage_id, "item_consolidation", "MASTER", master_prof, msg, retries=config.retries, config=config)
        if err is None and obj is not None and isinstance(obj.get("items"), list):
            items = [str(x).strip() for x in obj["items"] if str(x).strip()]
        else:
            # fallback dedup
            seen = set()
            items = []
            for it in raw_items:
                key = re.sub(r"\s+", " ", it.lower()).strip()
                if key not in seen:
                    seen.add(key)
                    items.append(it.strip())
            items = items[:30]
        self._stage_finished(run_id, stage_id, "Consolidate Items", "item_consolidation", ok=True, status="SUCCEEDED", details={"n_items": len(items)})

        top_k = min(int(config.priority_top_k), len(items))
        all_rounds: List[Dict[str, Any]] = []
        feedback_text: Optional[str] = None
        prev_top: Optional[List[int]] = None
        rounds_completed = 0

        for rnd in range(1, config.max_rounds + 1):
            def build_msgs(a: AgentProfile):
                return prompts.prompt_round_rank_items(
                    spec.topic,
                    spec.problem_statement,
                    items,
                    top_k=top_k,
                    round_index=rnd,
                    feedback=feedback_text,
                )

            _, resp, qok = self._parallel_json_stage(run_id, f"Round {rnd} - Ranking", "priority_round", agents, build_msgs, config)
            if not qok:
                return {"error": "Quorum not reached in ranking."}, rounds_completed, False

            rankings: List[List[int]] = []
            rationales: List[str] = []
            raw_by_agent: Dict[str, Any] = {}
            for aid, obj in resp.items():
                raw_by_agent[aid] = obj
                r = obj.get("ranked_item_indices", []) or []
                try:
                    r = [int(x) for x in r][:top_k]
                except Exception:
                    r = []
                # sanitize
                r2 = []
                for x in r:
                    if 1 <= x <= len(items) and x not in r2:
                        r2.append(x)
                if r2:
                    rankings.append(r2)
                rat = str(obj.get("rationale", "")).strip()
                if rat:
                    rationales.append(rat)

            scores = compute_borda_scores(rankings, n_items=len(items))
            W = kendalls_w(rankings, n_items=len(items))
            top = top_k_from_scores(scores, k=top_k)
            overlap = jaccard(prev_top or [], top) if prev_top is not None else None

            table_md = borda_markdown_table(items, scores, k=min(10, len(items)))

            all_rounds.append({
                "round": rnd,
                "responses": raw_by_agent,
                "borda_scores": scores,
                "kendalls_w": W,
                "top_k": top,
                "top_k_overlap_prev": overlap,
                "borda_table_md": table_md,
            })
            rounds_completed = rnd

            # stopping rule: stability of top-k set
            if rnd >= config.min_rounds and prev_top is not None and overlap is not None and overlap >= 0.9:
                break

            # generate feedback
            if rnd < config.max_rounds:
                fb_stage = f"stage_{_slug()}"
                self._stage_started(run_id, fb_stage, f"Feedback after Round {rnd}", "priority_feedback")
                contested = "\n".join(rationales[:10])
                msgs = prompts.prompt_master_feedback_priority(rnd, table_md, contested)
                if spec.master_instructions.strip():
                    msgs = msgs + [{"role": "user", "content": f"Additional facilitator instructions: {spec.master_instructions.strip()}"}]
                fb_obj, raw, usage, err = self._chat_json(run_id, fb_stage, "priority_feedback", "MASTER", master_prof, msgs, retries=config.retries, config=config)
                if err is None and fb_obj and isinstance(fb_obj.get("feedback"), str):
                    feedback_text = fb_obj["feedback"].strip()
                else:
                    feedback_text = "Please reconsider your ranking in light of the aggregated panel priorities."
                self._stage_finished(run_id, fb_stage, f"Feedback after Round {rnd}", "priority_feedback", ok=(err is None), status="SUCCEEDED" if (err is None) else "FAILED", details={"ok": err is None})

            prev_top = top

        final = all_rounds[-1] if all_rounds else {}
        outputs = {
            "items": items,
            "rounds": all_rounds,
            "final_top_k": final.get("top_k", []),
            "final_kendalls_w": final.get("kendalls_w"),
            "final_borda_table_md": final.get("borda_table_md", ""),
        }
        self.store.save_artifact(f"art_{_slug()}", run_id, "priority_results", outputs)
        return outputs, rounds_completed, True

    # -------------------------
    # Sensemaking / problem scoping pipeline
    # -------------------------
    def _run_sensemaking(
        self,
        run_id: str,
        spec: StudyRunSpec,
        config: DelphiConfig,
        agents: List[AgentProfile],
        master: MasterAgentConfig,
    ) -> Tuple[Dict[str, Any], int, bool]:
        master_prof = master.model_dump()
        if config.ai_delphi_model == "iconic_minds" and config.iconic_minds_scope_guardrails:
            master_prof["system_prompt"] = prompts.apply_iconic_minds_guardrails(master_prof.get("system_prompt", ""))

        # Round 1: elicit
        def build_msgs(a: AgentProfile):
            return prompts.prompt_round_sensemaking_elicit(spec.topic, spec.problem_statement, round_index=1)

        _, resp, qok = self._parallel_json_stage(run_id, "Round 1 - Sensemaking", "sensemaking_round1", agents, build_msgs, config)
        if not qok:
            return {"error": "Quorum not reached in sensemaking."}, 0, False

        # Master consolidation
        stage_id = f"stage_{_slug()}"
        self._stage_started(run_id, stage_id, "Consolidate Sensemaking", "sensemaking_consolidation")
        raw_payloads = [json.dumps(r) for r in resp.values()]
        msgs = prompts.prompt_master_consolidate_sensemaking(spec.topic, raw_payloads)
        if spec.master_instructions.strip():
            msgs = msgs + [{"role": "user", "content": f"Additional facilitator instructions: {spec.master_instructions.strip()}"}]
        obj, raw, usage, err = self._chat_json(run_id, stage_id, "sensemaking_consolidation", "MASTER", master_prof, msgs, retries=config.retries, config=config)
        consolidated = obj if (err is None and obj) else {"glossary": [], "assumptions": [], "in_scope": [], "out_of_scope": [], "uncertainties": [], "notes": ""}
        self._stage_finished(run_id, stage_id, "Consolidate Sensemaking", "sensemaking_consolidation", ok=(err is None), status="SUCCEEDED" if (err is None) else "FAILED", details={"ok": err is None})

        # Round 2: validation (optional if max_rounds >=2)
        val_resps: Dict[str, Any] = {}
        if config.max_rounds >= 2:
            feedback = json.dumps(consolidated)

            def build_msgs2(a: AgentProfile):
                return prompts.prompt_round_sensemaking_elicit(spec.topic, spec.problem_statement, round_index=2, feedback=feedback)

            _, val_resp, qok2 = self._parallel_json_stage(run_id, "Round 2 - Sensemaking Validation", "sensemaking_validation", agents, build_msgs2, config)
            if qok2:
                val_resps = val_resp

            # final master consolidation
            stage_id2 = f"stage_{_slug()}"
            self._stage_started(run_id, stage_id2, "Final Sensemaking", "sensemaking_synthesis")
            raw_payloads2 = [json.dumps(r) for r in val_resps.values()] or []
            msgs2 = prompts.prompt_master_consolidate_sensemaking(spec.topic, raw_payloads2 + [json.dumps(consolidated)])
            if spec.master_instructions.strip():
                msgs2 = msgs2 + [{"role": "user", "content": f"Additional facilitator instructions: {spec.master_instructions.strip()}"}]
            obj2, raw2, usage2, err2 = self._chat_json(run_id, stage_id2, "sensemaking_synthesis", "MASTER", master_prof, msgs2, retries=config.retries, config=config)
            consolidated = obj2 if (err2 is None and obj2) else consolidated
            self._stage_finished(run_id, stage_id2, "Final Sensemaking", "sensemaking_synthesis", ok=(err2 is None), status="SUCCEEDED" if (err2 is None) else "FAILED", details={"ok": err2 is None})

        outputs = {
            "round1": resp,
            "round2": val_resps,
            "scope_map": consolidated,
        }
        self.store.save_artifact(f"art_{_slug()}", run_id, "sensemaking_results", outputs)
        return outputs, 2 if val_resps else 1, True

    # -------------------------
    # Idea generation pipeline (broad -> clustered)
    # -------------------------
    def _run_idea_generation(
        self,
        run_id: str,
        spec: StudyRunSpec,
        config: DelphiConfig,
        agents: List[AgentProfile],
        master: MasterAgentConfig,
    ) -> Tuple[Dict[str, Any], int, bool]:
        # Reuse item elicitation + master consolidation + optional clustering
        def build_msgs(a: AgentProfile):
            return prompts.prompt_round1_elicit_items(spec.topic, spec.problem_statement, spec.items_per_agent)

        _, resp, qok = self._parallel_json_stage(run_id, "Round 1 - Idea Elicitation", "idea_elicitation", agents, build_msgs, config)
        if not qok:
            return {"error": "Quorum not reached in idea elicitation."}, 0, False

        raw_items: List[str] = []
        for _, obj in resp.items():
            for it in obj.get("items", []) or []:
                txt = str(it.get("text", "")).strip()
                if txt:
                    raw_items.append(txt)

        stage_id = f"stage_{_slug()}"
        self._stage_started(run_id, stage_id, "Consolidate and Cluster Ideas", "idea_consolidation")
        master_prof = master.model_dump()
        if config.ai_delphi_model == "iconic_minds" and config.iconic_minds_scope_guardrails:
            master_prof["system_prompt"] = prompts.apply_iconic_minds_guardrails(master_prof.get("system_prompt", ""))

        user = (
            f"You are the Delphi facilitator. Topic: {spec.topic}.\n"
            "Task: Consolidate and cluster the proposed ideas. Merge duplicates; create 4-10 clusters/themes.\n\n"
            "Return ONLY JSON with schema: {\"clusters\": [{\"theme\":\"...\",\"items\":[\"...\",...]}, ...], \"all_items\":[\"...\", ...]}\n\n"
            + "Ideas:\n" + "\n".join([f"- {x}" for x in raw_items])
        )
        msgs = [{"role": "user", "content": user}]
        if spec.master_instructions.strip():
            msgs = msgs + [{"role": "user", "content": f"Additional facilitator instructions: {spec.master_instructions.strip()}"}]
        obj, raw, usage, err = self._chat_json(run_id, stage_id, "idea_consolidation", "MASTER", master_prof, msgs, retries=config.retries, config=config)
        clustered = obj if (err is None and obj) else {"clusters": [], "all_items": list(dict.fromkeys(raw_items))}
        self._stage_finished(run_id, stage_id, "Consolidate and Cluster Ideas", "idea_consolidation", ok=(err is None), status="SUCCEEDED" if (err is None) else "FAILED", details={"ok": err is None})

        outputs = {"raw": resp, "clustered": clustered}
        self.store.save_artifact(f"art_{_slug()}", run_id, "idea_generation_results", outputs)
        return outputs, 1, True

    # -------------------------
    # Criteria / standards development pipeline
    # -------------------------
    def _run_criteria_standards(
        self,
        run_id: str,
        spec: StudyRunSpec,
        config: DelphiConfig,
        agents: List[AgentProfile],
        master: MasterAgentConfig,
    ) -> Tuple[Dict[str, Any], int, bool]:
        # Treat as guideline statements with rating
        return self._run_policy_guidelines(run_id, spec, config, agents, master, mode="criteria")

    # -------------------------
    # Policy / guideline formation pipeline
    # -------------------------
    def _run_policy_guidelines(
        self,
        run_id: str,
        spec: StudyRunSpec,
        config: DelphiConfig,
        agents: List[AgentProfile],
        master: MasterAgentConfig,
        mode: str = "guidelines",
    ) -> Tuple[Dict[str, Any], int, bool]:
        statements: List[str] = [s.strip() for s in (spec.seed_statements or []) if s.strip()]

        master_prof = master.model_dump()
        if config.ai_delphi_model == "iconic_minds" and config.iconic_minds_scope_guardrails:
            master_prof["system_prompt"] = prompts.apply_iconic_minds_guardrails(master_prof.get("system_prompt", ""))

        # Round 1 elicitation if no seed statements
        if not statements:
            def build_msgs(a: AgentProfile):
                return prompts.prompt_round_guidelines_elicit(spec.topic, spec.problem_statement, spec.statements_per_agent, round_index=1)

            _, resp, qok = self._parallel_json_stage(run_id, f"Round 1 - {mode.title()} Elicitation", f"{mode}_elicitation", agents, build_msgs, config)
            if not qok:
                return {"error": "Quorum not reached in statement elicitation."}, 0, False
            raw_stmts: List[str] = []
            for _, obj in resp.items():
                for s in obj.get("statements", []) or []:
                    txt = str(s.get("text", "")).strip() if isinstance(s, dict) else str(s).strip()
                    if txt:
                        raw_stmts.append(txt)

            # consolidate
            stage_id = f"stage_{_slug()}"
            self._stage_started(run_id, stage_id, f"Consolidate {mode.title()}", f"{mode}_consolidation")
            msgs = prompts.prompt_master_consolidate_statements(spec.topic, raw_stmts)
            if spec.master_instructions.strip():
                msgs = msgs + [{"role": "user", "content": f"Additional facilitator instructions: {spec.master_instructions.strip()}"}]
            obj, raw, usage, err = self._chat_json(run_id, stage_id, f"{mode}_consolidation", "MASTER", master_prof, msgs, retries=config.retries, config=config)
            if err is None and obj and isinstance(obj.get("statements"), list):
                statements = [str(x).strip() for x in obj["statements"] if str(x).strip()]
            else:
                statements = list(dict.fromkeys(raw_stmts))[:30]
            self._stage_finished(run_id, stage_id, f"Consolidate {mode.title()}", f"{mode}_consolidation", ok=True, status="SUCCEEDED", details={"n": len(statements)})
        else:
            resp = {}

        # Round 2 rating
        def build_msgs2(a: AgentProfile):
            return prompts.prompt_round_guidelines_rating(spec.topic, spec.problem_statement, statements, round_index=2)

        _, rresp, qok2 = self._parallel_json_stage(run_id, f"Round 2 - {mode.title()} Rating", f"{mode}_rating", agents, build_msgs2, config)
        if not qok2:
            return {"error": "Quorum not reached in rating."}, 1, False

        # Aggregate acceptability/feasibility
        ratings_matrix: Dict[str, Dict[str, List[int]]] = {s: {"Acceptability": [], "Feasibility": []} for s in statements}
        critiques: Dict[str, List[str]] = {s: [] for s in statements}
        for _, obj in rresp.items():
            for r in obj.get("ratings", []) or []:
                try:
                    si = int(r.get("statement_index"))
                    acc = int(r.get("acceptability"))
                    fea = int(r.get("feasibility"))
                    crit = str(r.get("critique", "")).strip()
                    edit = str(r.get("edit_suggestion", "")).strip()
                except Exception:
                    continue
                if 1 <= si <= len(statements):
                    st_text = statements[si - 1]
                    ratings_matrix[st_text]["Acceptability"].append(acc)
                    ratings_matrix[st_text]["Feasibility"].append(fea)
                    if crit:
                        critiques[st_text].append(crit)
                    if edit:
                        critiques[st_text].append(f"Edit: {edit}")

        stats = compute_item_stats(ratings_matrix)
        div = divergence_items(stats, iqr_threshold=config.consensus_iqr_threshold)

        outputs = {
            "mode": mode,
            "statements": statements,
            "round1": resp,
            "round2": rresp,
            "stats": {k: {d: v.__dict__ for d, v in dm.items()} for k, dm in stats.items()},
            "divergence": div,
        }
        self.store.save_artifact(f"art_{_slug()}", run_id, f"{mode}_results", outputs)
        return outputs, 2, True

    # -------------------------
    # Risk register pipeline
    # -------------------------
    def _run_risk_register(
        self,
        run_id: str,
        spec: StudyRunSpec,
        config: DelphiConfig,
        agents: List[AgentProfile],
        master: MasterAgentConfig,
    ) -> Tuple[Dict[str, Any], int, bool]:
        master_prof = master.model_dump()
        if config.ai_delphi_model == "iconic_minds" and config.iconic_minds_scope_guardrails:
            master_prof["system_prompt"] = prompts.apply_iconic_minds_guardrails(master_prof.get("system_prompt", ""))

        def build_msgs(a: AgentProfile):
            return prompts.prompt_round_risk_elicit(spec.topic, spec.problem_statement, spec.risks_per_agent, round_index=1)

        _, resp, qok = self._parallel_json_stage(run_id, "Round 1 - Risk Elicitation", "risk_elicitation", agents, build_msgs, config)
        if not qok:
            return {"error": "Quorum not reached in risk elicitation."}, 0, False

        raw_risks: List[Dict[str, Any]] = []
        for _, obj in resp.items():
            for r in obj.get("risks", []) or []:
                if isinstance(r, dict) and str(r.get("risk", "")).strip():
                    raw_risks.append(r)

        # Consolidate
        stage_id = f"stage_{_slug()}"
        self._stage_started(run_id, stage_id, "Consolidate Risks", "risk_consolidation")
        msgs = prompts.prompt_master_consolidate_risks(spec.topic, [json.dumps(r) for r in raw_risks])
        if spec.master_instructions.strip():
            msgs = msgs + [{"role": "user", "content": f"Additional facilitator instructions: {spec.master_instructions.strip()}"}]
        obj, raw, usage, err = self._chat_json(run_id, stage_id, "risk_consolidation", "MASTER", master_prof, msgs, retries=config.retries, config=config)
        risks = obj.get("risks", []) if (err is None and obj and isinstance(obj.get("risks"), list)) else []
        if not risks:
            # fallback: take first unique risks
            seen = set()
            risks = []
            for r in raw_risks:
                key = re.sub(r"\s+", " ", str(r.get("risk", "")).lower()).strip()
                if key and key not in seen:
                    seen.add(key)
                    risks.append({"risk_id": f"R{len(risks)+1}", "risk": r.get("risk"), "causes": r.get("causes", []), "impacts": r.get("impacts", []), "mitigations": r.get("mitigations", [])})
            risks = risks[:30]
        self._stage_finished(run_id, stage_id, "Consolidate Risks", "risk_consolidation", ok=(err is None), status="SUCCEEDED" if (err is None) else "FAILED", details={"n": len(risks), "ok": err is None})

        # Round 2: rating
        def build_msgs2(a: AgentProfile):
            return prompts.prompt_round_risk_rating(spec.topic, spec.problem_statement, risks, round_index=2)

        _, rresp, qok2 = self._parallel_json_stage(run_id, "Round 2 - Risk Rating", "risk_rating", agents, build_msgs2, config)
        if not qok2:
            return {"error": "Quorum not reached in risk rating."}, 1, False

        ratings_matrix: Dict[str, Dict[str, List[int]]] = {}
        for r in risks:
            key = f"{r.get('risk_id','R?')}: {r.get('risk','')}"
            ratings_matrix[key] = {"Likelihood": [], "Impact": []}

        justifs: Dict[str, List[str]] = {k: [] for k in ratings_matrix}

        for _, obj in rresp.items():
            for rr in obj.get("ratings", []) or []:
                try:
                    ri = int(rr.get("risk_index"))
                    lik = int(rr.get("likelihood"))
                    imp = int(rr.get("impact"))
                    j = str(rr.get("justification", "")).strip()
                except Exception:
                    continue
                if 1 <= ri <= len(risks):
                    key = list(ratings_matrix.keys())[ri - 1]
                    ratings_matrix[key]["Likelihood"].append(max(1, min(5, lik)))
                    ratings_matrix[key]["Impact"].append(max(1, min(5, imp)))
                    if j:
                        justifs[key].append(j)

        stats = compute_item_stats(ratings_matrix)

        # Compute simple risk priority score = median(L)*median(I)
        rpn = {}
        for k, dmap in stats.items():
            rpn[k] = float(dmap["Likelihood"].median * dmap["Impact"].median)

        outputs = {
            "risks": risks,
            "round1": resp,
            "round2": rresp,
            "stats": {k: {d: v.__dict__ for d, v in dm.items()} for k, dm in stats.items()},
            "risk_priority": rpn,
        }
        self.store.save_artifact(f"art_{_slug()}", run_id, "risk_results", outputs)
        return outputs, 2, True

    # -------------------------
    # Measurement / instrument development pipeline
    # -------------------------
    def _run_instrument_development(
        self,
        run_id: str,
        spec: StudyRunSpec,
        config: DelphiConfig,
        agents: List[AgentProfile],
        master: MasterAgentConfig,
    ) -> Tuple[Dict[str, Any], int, bool]:
        constructs = [c.strip() for c in (spec.constructs or []) if c.strip()]
        if not constructs:
            return {"error": "No constructs provided for instrument development."}, 0, False

        master_prof = master.model_dump()
        if config.ai_delphi_model == "iconic_minds" and config.iconic_minds_scope_guardrails:
            master_prof["system_prompt"] = prompts.apply_iconic_minds_guardrails(master_prof.get("system_prompt", ""))

        # Round 1: item proposals
        def build_msgs(a: AgentProfile):
            return prompts.prompt_round_instrument_elicit(
                spec.topic,
                spec.problem_statement,
                constructs,
                spec.items_per_construct_per_agent,
                round_index=1,
            )

        _, resp, qok = self._parallel_json_stage(run_id, "Round 1 - Instrument Item Elicitation", "instrument_elicitation", agents, build_msgs, config)
        if not qok:
            return {"error": "Quorum not reached in instrument elicitation."}, 0, False

        raw_items: List[Dict[str, Any]] = []
        for _, obj in resp.items():
            for it in obj.get("items", []) or []:
                if isinstance(it, dict) and str(it.get("item_text", "")).strip():
                    raw_items.append(it)

        # Master consolidation
        stage_id = f"stage_{_slug()}"
        self._stage_started(run_id, stage_id, "Consolidate Instrument", "instrument_consolidation")
        msgs = prompts.prompt_master_consolidate_instrument(spec.topic, [json.dumps(x) for x in raw_items], constructs)
        if spec.master_instructions.strip():
            msgs = msgs + [{"role": "user", "content": f"Additional facilitator instructions: {spec.master_instructions.strip()}"}]
        obj, raw, usage, err = self._chat_json(run_id, stage_id, "instrument_consolidation", "MASTER", master_prof, msgs, retries=config.retries, config=config)
        instrument = obj.get("instrument") if (err is None and obj and isinstance(obj.get("instrument"), dict)) else {"constructs": []}
        self._stage_finished(run_id, stage_id, "Consolidate Instrument", "instrument_consolidation", ok=(err is None), status="SUCCEEDED" if (err is None) else "FAILED", details={"ok": err is None})

        # Round 2: rating
        def build_msgs2(a: AgentProfile):
            return prompts.prompt_round_instrument_rating(spec.topic, spec.problem_statement, instrument, round_index=2)

        _, rresp, qok2 = self._parallel_json_stage(run_id, "Round 2 - Instrument Item Rating", "instrument_rating", agents, build_msgs2, config)
        if not qok2:
            return {"error": "Quorum not reached in instrument rating."}, 1, False

        # Build ratings matrix by flattened item
        flat_items: List[Tuple[str, str]] = []  # (construct, text)
        for c in instrument.get("constructs", []) or []:
            cname = c.get("name", "")
            for it in c.get("items", []) or []:
                flat_items.append((cname, str(it)))

        ratings_matrix: Dict[str, Dict[str, List[int]]] = {}
        for cname, text in flat_items:
            key = f"[{cname}] {text}"
            ratings_matrix[key] = {"Relevance": [], "Clarity": []}

        edits: Dict[str, List[str]] = {k: [] for k in ratings_matrix}

        for _, obj in rresp.items():
            for rr in obj.get("ratings", []) or []:
                try:
                    ii = int(rr.get("item_index"))
                    rel = int(rr.get("relevance"))
                    cla = int(rr.get("clarity"))
                    edit = str(rr.get("edit_suggestion", "")).strip()
                except Exception:
                    continue
                if 1 <= ii <= len(flat_items):
                    key = list(ratings_matrix.keys())[ii - 1]
                    ratings_matrix[key]["Relevance"].append(max(1, min(5, rel)))
                    ratings_matrix[key]["Clarity"].append(max(1, min(5, cla)))
                    if edit:
                        edits[key].append(edit)

        stats = compute_item_stats(ratings_matrix)
        div = divergence_items(stats, iqr_threshold=config.consensus_iqr_threshold)

        outputs = {
            "constructs": constructs,
            "round1": resp,
            "instrument": instrument,
            "round2": rresp,
            "stats": {k: {d: v.__dict__ for d, v in dm.items()} for k, dm in stats.items()},
            "divergence": div,
            "edit_suggestions": edits,
        }
        self.store.save_artifact(f"art_{_slug()}", run_id, "instrument_results", outputs)
        return outputs, 2, True

    # -------------------------
    # Scenario building pipeline
    # -------------------------
    def _run_scenario_building(
        self,
        run_id: str,
        spec: StudyRunSpec,
        config: DelphiConfig,
        agents: List[AgentProfile],
        master: MasterAgentConfig,
    ) -> Tuple[Dict[str, Any], int, bool]:
        master_prof = master.model_dump()
        if config.ai_delphi_model == "iconic_minds" and config.iconic_minds_scope_guardrails:
            master_prof["system_prompt"] = prompts.apply_iconic_minds_guardrails(master_prof.get("system_prompt", ""))

        # Round 1: drivers
        def build_msgs(a: AgentProfile):
            return prompts.prompt_round_scenario_drivers(spec.topic, spec.problem_statement, round_index=1)

        _, resp, qok = self._parallel_json_stage(run_id, "Round 1 - Scenario Drivers", "scenario_drivers", agents, build_msgs, config)
        if not qok:
            return {"error": "Quorum not reached in scenario drivers."}, 0, False

        stage_id = f"stage_{_slug()}"
        self._stage_started(run_id, stage_id, "Generate Scenarios", "scenario_generation")
        msgs = prompts.prompt_master_generate_scenarios(spec.topic, spec.scenario_time_horizon, list(resp.values()), spec.n_scenarios)
        if spec.master_instructions.strip():
            msgs = msgs + [{"role": "user", "content": f"Additional facilitator instructions: {spec.master_instructions.strip()}"}]
        obj, raw, usage, err = self._chat_json(run_id, stage_id, "scenario_generation", "MASTER", master_prof, msgs, retries=config.retries, config=config)
        scenarios = obj.get("scenarios", []) if (err is None and obj and isinstance(obj.get("scenarios"), list)) else []
        self._stage_finished(run_id, stage_id, "Generate Scenarios", "scenario_generation", ok=(err is None), status="SUCCEEDED" if (err is None) else "FAILED", details={"n": len(scenarios), "ok": err is None})

        # Round 2: review
        def build_msgs2(a: AgentProfile):
            return prompts.prompt_round_scenario_review(spec.topic, scenarios, round_index=2)

        _, rresp, qok2 = self._parallel_json_stage(run_id, "Round 2 - Scenario Review", "scenario_review", agents, build_msgs2, config)
        if not qok2:
            return {"error": "Quorum not reached in scenario review."}, 1, False

        outputs = {
            "drivers": resp,
            "scenarios": scenarios,
            "reviews": rresp,
            "time_horizon": spec.scenario_time_horizon,
        }
        self.store.save_artifact(f"art_{_slug()}", run_id, "scenario_results", outputs)
        return outputs, 2, True