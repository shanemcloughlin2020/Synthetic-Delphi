from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import math
import statistics

import numpy as np


def median(values: List[float]) -> float:
    return float(statistics.median(values)) if values else float("nan")


def iqr(values: List[float]) -> float:
    """Interquartile range with linear interpolation."""
    if not values:
        return float("nan")
    xs = sorted(values)
    n = len(xs)

    def _percentile(p: float) -> float:
        if n == 1:
            return float(xs[0])
        k = (n - 1) * p
        f = math.floor(k)
        c = math.ceil(k)
        if f == c:
            return float(xs[int(k)])
        d0 = xs[f] * (c - k)
        d1 = xs[c] * (k - f)
        return float(d0 + d1)

    q1 = _percentile(0.25)
    q3 = _percentile(0.75)
    return float(q3 - q1)


@dataclass
class ItemDimStats:
    median: float
    iqr: float
    n: int


def compute_item_stats(
    ratings_matrix: Dict[str, Dict[str, List[int]]]
) -> Dict[str, Dict[str, ItemDimStats]]:
    """ratings_matrix[item_text][dimension] = list of integer scores"""
    out: Dict[str, Dict[str, ItemDimStats]] = {}
    for item, dims in ratings_matrix.items():
        out[item] = {}
        for dim, scores in dims.items():
            out[item][dim] = ItemDimStats(
                median=median([float(s) for s in scores]),
                iqr=iqr([float(s) for s in scores]),
                n=len(scores),
            )
    return out


def consensus_met(stats: Dict[str, Dict[str, ItemDimStats]], iqr_threshold: float) -> bool:
    for _, dims in stats.items():
        for _, st in dims.items():
            if math.isnan(st.iqr):
                return False
            if st.iqr > iqr_threshold:
                return False
    return True


def stability_met(
    prev_stats: Dict[str, Dict[str, ItemDimStats]],
    curr_stats: Dict[str, Dict[str, ItemDimStats]],
    median_delta_threshold: float,
) -> bool:
    """Require all shared items/dims to be within threshold."""
    for item, dims in curr_stats.items():
        if item not in prev_stats:
            return False
        for dim, st in dims.items():
            if dim not in prev_stats[item]:
                return False
            prev_med = prev_stats[item][dim].median
            if abs(st.median - prev_med) > median_delta_threshold:
                return False
    return True


def stats_markdown_table(stats: Dict[str, Dict[str, ItemDimStats]]) -> str:
    dims: List[str] = []
    for item in stats:
        for d in stats[item].keys():
            if d not in dims:
                dims.append(d)
    header = ["Item"]
    for d in dims:
        header += [f"{d} median", f"{d} IQR", f"{d} n"]
    lines = ["| " + " | ".join(header) + " |", "| " + " | ".join(["---"] * len(header)) + " |"]
    for item, dmap in stats.items():
        row = [item]
        for d in dims:
            st = dmap.get(d)
            if st is None:
                row += ["", "", ""]
            else:
                row += [f"{st.median:.2f}", f"{st.iqr:.2f}", str(st.n)]
        lines.append("| " + " | ".join(row) + " |")
    return "\n".join(lines)


# -------------------------
# Forecasting analytics
# -------------------------


@dataclass
class ForecastAgg:
    n: int
    mean: float
    median: float
    iqr: float
    weighted_mean: float
    alpha: Optional[float] = None
    beta: Optional[float] = None
    ci_low: Optional[float] = None
    ci_high: Optional[float] = None


def aggregate_forecasts(
    probabilities: List[float],
    confidences: Optional[List[int]] = None,
    *,
    weight_by_confidence: bool = True,
    beta_pooling: bool = True,
    beta_draws: int = 20000,
    rng_seed: int = 42,
) -> ForecastAgg:
    """Aggregate per-question probability forecasts.

    - probabilities are expected on 0-100 scale.
    - confidences are expected on 1-5 scale.
    """
    ps = [float(p) for p in probabilities if p is not None]
    if not ps:
        return ForecastAgg(n=0, mean=float("nan"), median=float("nan"), iqr=float("nan"), weighted_mean=float("nan"))

    # central tendency / dispersion
    m = float(sum(ps) / len(ps))
    med = median(ps)
    iq = iqr(ps)

    # weights
    if confidences and weight_by_confidence:
        ws = [max(1.0, float(c)) for c in confidences[: len(ps)]]
    else:
        ws = [1.0] * len(ps)

    wmean = float(sum(w * p for w, p in zip(ws, ps)) / max(1e-9, sum(ws)))

    agg = ForecastAgg(n=len(ps), mean=m, median=med, iqr=iq, weighted_mean=wmean)

    if beta_pooling:
        # Beta pooling on 0-1 scale using weighted pseudo-counts
        p01 = [min(0.999999, max(0.000001, p / 100.0)) for p in ps]
        alpha = 1.0 + sum(w * p for w, p in zip(ws, p01))
        beta = 1.0 + sum(w * (1.0 - p) for w, p in zip(ws, p01))
        agg.alpha = alpha
        agg.beta = beta

        draws = int(beta_draws)
        draws = max(1000, min(draws, 200000))
        rng = np.random.default_rng(rng_seed)
        samples = rng.beta(alpha, beta, size=draws)
        q_low, q_med, q_hi = np.quantile(samples, [0.025, 0.5, 0.975])
        agg.ci_low = float(q_low * 100.0)
        agg.ci_high = float(q_hi * 100.0)
        # use posterior median as median if available
        agg.median = float(q_med * 100.0)

    return agg


def forecast_markdown_table(questions: List[str], aggs: Dict[int, ForecastAgg]) -> str:
    header = ["Q#", "Question", "n", "mean", "median", "IQR", "w-mean", "95% CI"]
    lines = ["| " + " | ".join(header) + " |", "| " + " | ".join(["---"] * len(header)) + " |"]
    for qi, q in enumerate(questions, start=1):
        a = aggs.get(qi)
        if not a or a.n == 0:
            lines.append(f"| {qi} | {q} | 0 |  |  |  |  |  |")
            continue
        ci = ""
        if a.ci_low is not None and a.ci_high is not None:
            ci = f"{a.ci_low:.1f}–{a.ci_high:.1f}"
        lines.append(
            "| "
            + " | ".join(
                [
                    str(qi),
                    q.replace("\n", " ")[:80],
                    str(a.n),
                    f"{a.mean:.1f}",
                    f"{a.median:.1f}",
                    f"{a.iqr:.1f}",
                    f"{a.weighted_mean:.1f}",
                    ci,
                ]
            )
            + " |"
        )
    return "\n".join(lines)


# -------------------------
# Priority-setting analytics
# -------------------------


def compute_borda_scores(rankings: List[List[int]], n_items: int) -> Dict[int, float]:
    """Compute simple Borda scores from ranked item indices.

    Each rater provides an ordered list of item indices (1..n_items).
    Ranked items receive points (n_items - rank + 1); unranked receive 0.
    """
    scores: Dict[int, float] = {i: 0.0 for i in range(1, n_items + 1)}
    for r in rankings:
        for rank, idx in enumerate(r, start=1):
            if 1 <= idx <= n_items:
                scores[idx] += float(n_items - rank + 1)
    return scores


def kendalls_w(rankings: List[List[int]], n_items: int) -> float:
    """Approximate Kendall's W for agreement.

    For incomplete rankings, unranked items are assigned rank n_items (worst).
    Ties are not handled explicitly.
    """
    m = len(rankings)
    if m < 2 or n_items < 2:
        return float("nan")

    rank_matrix = np.zeros((m, n_items), dtype=float)
    for i, r in enumerate(rankings):
        ranks = [float(n_items)] * n_items
        for rank, idx in enumerate(r, start=1):
            if 1 <= idx <= n_items:
                ranks[idx - 1] = float(rank)
        rank_matrix[i, :] = np.array(ranks, dtype=float)

    R = np.sum(rank_matrix, axis=0)
    Rbar = m * (n_items + 1) / 2.0
    S = float(np.sum((R - Rbar) ** 2))
    denom = (m**2) * (n_items**3 - n_items)
    if denom <= 0:
        return float("nan")
    W = 12.0 * S / denom
    return float(max(0.0, min(1.0, W)))


def top_k_from_scores(scores: Dict[int, float], k: int) -> List[int]:
    return [idx for idx, _ in sorted(scores.items(), key=lambda x: (-x[1], x[0]))[:k]]


def jaccard(a: List[int], b: List[int]) -> float:
    sa, sb = set(a), set(b)
    if not sa and not sb:
        return 1.0
    return float(len(sa & sb) / max(1, len(sa | sb)))


def borda_markdown_table(items: List[str], scores: Dict[int, float], k: int = 10) -> str:
    header = ["Rank", "Item", "Borda score"]
    lines = ["| " + " | ".join(header) + " |", "| " + " | ".join(["---"] * len(header)) + " |"]
    ordered = sorted(scores.items(), key=lambda x: (-x[1], x[0]))
    for rank, (idx, sc) in enumerate(ordered[:k], start=1):
        it = items[idx - 1] if 1 <= idx <= len(items) else f"Item {idx}"
        lines.append(f"| {rank} | {it} | {sc:.1f} |")
    return "\n".join(lines)


# -------------------------
# Convergence / divergence helpers
# -------------------------


def divergence_items(stats: Dict[str, Dict[str, ItemDimStats]], iqr_threshold: float) -> Dict[str, List[str]]:
    """Return items with dimensions whose IQR exceeds threshold."""
    out: Dict[str, List[str]] = {}
    for item, dmap in stats.items():
        for dim, st in dmap.items():
            if not math.isnan(st.iqr) and st.iqr > iqr_threshold:
                out.setdefault(item, []).append(dim)
    return out
