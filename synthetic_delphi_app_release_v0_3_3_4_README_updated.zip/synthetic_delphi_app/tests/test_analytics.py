from synthetic_delphi.analytics import iqr, median, compute_item_stats, consensus_met, stability_met


def test_iqr_basic():
    assert iqr([1, 2, 3, 4]) >= 0.0
    assert median([1, 2, 3]) == 2.0


def test_consensus_and_stability():
    matrix1 = {"Item A": {"Importance": [5, 5, 5]}, "Item B": {"Importance": [4, 4, 4]}}
    stats1 = compute_item_stats(matrix1)
    assert consensus_met(stats1, iqr_threshold=0.1)

    matrix2 = {"Item A": {"Importance": [5, 5, 5]}, "Item B": {"Importance": [4, 4, 4]}}
    stats2 = compute_item_stats(matrix2)
    assert stability_met(stats1, stats2, median_delta_threshold=0.01)
