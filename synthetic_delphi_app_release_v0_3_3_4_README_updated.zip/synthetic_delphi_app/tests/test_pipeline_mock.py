from synthetic_delphi import (
    AgentProfile,
    MasterAgentConfig,
    DelphiConfig,
    StudyRunSpec,
    SQLiteStore,
    DelphiStudyRunner,
    MockProvider,
    RatingDimension,
)


def test_item_rating_pipeline_with_mock(tmp_path):
    db = tmp_path / "test.sqlite3"
    store = SQLiteStore(path=str(db))
    provider = MockProvider()
    runner = DelphiStudyRunner(store=store, provider=provider)

    agents = [
        AgentProfile(agent_id="a1", name="A1", provider="mock", base_url="mock", model="mock", api_key=None),
        AgentProfile(agent_id="a2", name="A2", provider="mock", base_url="mock", model="mock", api_key=None),
        AgentProfile(agent_id="a3", name="A3", provider="mock", base_url="mock", model="mock", api_key=None),
    ]
    master = MasterAgentConfig(provider="mock", base_url="mock", model="mock", api_key=None)

    cfg = DelphiConfig(template="item_rating", max_rounds=2, min_rounds=2, quorum_fraction=0.5, stage_deadline_s=30, retries=0)
    spec = StudyRunSpec(
        title="Test",
        topic="Future of X",
        problem_statement="",
        items_per_agent=3,
        rating_dimensions=[RatingDimension(name="Importance", scale_min=1, scale_max=7)],
    )

    result = runner.run(spec=spec, config=cfg, agents=agents, master=master)
    assert result.template == "item_rating"
    assert result.rounds_completed >= 1
    assert "items" in result.outputs
    assert len(result.outputs["items"]) > 0


def test_questionnaire_pipeline_with_mock(tmp_path):
    db = tmp_path / "test2.sqlite3"
    store = SQLiteStore(path=str(db))
    provider = MockProvider()
    runner = DelphiStudyRunner(store=store, provider=provider)

    agents = [
        AgentProfile(agent_id="a1", name="A1", provider="mock", base_url="mock", model="mock", api_key=None),
        AgentProfile(agent_id="a2", name="A2", provider="mock", base_url="mock", model="mock", api_key=None),
    ]
    master = MasterAgentConfig(provider="mock", base_url="mock", model="mock", api_key=None)

    cfg = DelphiConfig(template="questionnaire_ai_delphi", max_rounds=2, min_rounds=2, quorum_fraction=0.5, stage_deadline_s=30, retries=0)
    spec = StudyRunSpec(
        title="Test",
        topic="Future of Y",
        questionnaire=["What will change?", "What should we do?"],
    )

    result = runner.run(spec=spec, config=cfg, agents=agents, master=master)
    assert result.template == "questionnaire_ai_delphi"
    assert result.rounds_completed >= 1
    assert "final_report" in result.outputs


def test_all_templates_run_with_mock(tmp_path):
    """Smoke test: every shipped template should execute with the MockProvider."""

    templates = [
        ("item_rating", {"items_per_agent": 3, "rating_dimensions": [RatingDimension(name="Importance", scale_min=1, scale_max=7)]}),
        ("questionnaire_ai_delphi", {"questionnaire": ["Q1?", "Q2?"]}),
        ("recursive_reasoning", {"questionnaire": ["Q1?", "Q2?"], "include_final_synthesis": True}),
        ("forecasting", {"forecast_questions": ["Will X happen by 2030?"]}),
        ("priority_ranking", {"items_per_agent": 3}),
        ("sensemaking", {}),
        ("idea_generation", {"items_per_agent": 5}),
        ("criteria_standards", {"statements_per_agent": 5}),
        ("policy_guidelines", {"statements_per_agent": 5}),
        ("risk_register", {"risks_per_agent": 5}),
        ("scenario_building", {"n_scenarios": 3, "scenario_time_horizon": "5 years"}),
        ("instrument_development", {"constructs": ["Trust", "Transparency"], "items_per_construct_per_agent": 2}),
    ]

    for i, (tpl, extra_spec) in enumerate(templates, start=1):
        db = tmp_path / f"smoke_{i}.sqlite3"
        store = SQLiteStore(path=str(db))
        provider = MockProvider()
        runner = DelphiStudyRunner(store=store, provider=provider)

        agents = [
            AgentProfile(agent_id="a1", name="A1", provider="mock", base_url="mock", model="mock", api_key=None),
            AgentProfile(agent_id="a2", name="A2", provider="mock", base_url="mock", model="mock", api_key=None),
            AgentProfile(agent_id="a3", name="A3", provider="mock", base_url="mock", model="mock", api_key=None),
        ]
        master = MasterAgentConfig(provider="mock", base_url="mock", model="mock", api_key=None)

        cfg = DelphiConfig(template=tpl, max_rounds=2, min_rounds=2, quorum_fraction=0.5, stage_deadline_s=30, retries=0)
        spec = StudyRunSpec(title="Test", topic="Topic", **extra_spec)

        result = runner.run(spec=spec, config=cfg, agents=agents, master=master)
        assert result.template == tpl
        assert result.rounds_completed >= 1
