from synthetic_delphi import (
    AgentProfile,
    MasterAgentConfig,
    DelphiConfig,
    StudyRunSpec,
    SQLiteStore,
    DelphiStudyRunner,
    MockProvider,
)


def _make_runner(tmp_path):
    db = tmp_path / "test_extra.sqlite3"
    store = SQLiteStore(path=str(db))
    provider = MockProvider()
    runner = DelphiStudyRunner(store=store, provider=provider)

    agents = [
        AgentProfile(agent_id="a1", name="A1", provider="mock", base_url="mock", model="mock", api_key=None),
        AgentProfile(agent_id="a2", name="A2", provider="mock", base_url="mock", model="mock", api_key=None),
        AgentProfile(agent_id="a3", name="A3", provider="mock", base_url="mock", model="mock", api_key=None),
    ]
    master = MasterAgentConfig(provider="mock", base_url="mock", model="mock", api_key=None)
    return runner, agents, master


def test_forecasting_pipeline_with_mock(tmp_path):
    runner, agents, master = _make_runner(tmp_path)
    cfg = DelphiConfig(template="forecasting", max_rounds=2, min_rounds=1, quorum_fraction=0.5, stage_deadline_s=30, retries=0)
    spec = StudyRunSpec(
        title="Test",
        topic="Forecast",
        forecast_questions=["Will X happen by 2030?", "Will Y exceed Z?"],
    )
    result = runner.run(spec=spec, config=cfg, agents=agents, master=master)
    assert result.template == "forecasting"
    assert "final_table_md" in result.outputs


def test_priority_ranking_pipeline_with_mock(tmp_path):
    runner, agents, master = _make_runner(tmp_path)
    cfg = DelphiConfig(template="priority_ranking", max_rounds=2, min_rounds=1, quorum_fraction=0.5, stage_deadline_s=30, retries=0, priority_top_k=3)
    spec = StudyRunSpec(
        title="Test",
        topic="Priorities",
        seed_items=["A", "B", "C", "D"],
    )
    result = runner.run(spec=spec, config=cfg, agents=agents, master=master)
    assert result.template == "priority_ranking"
    assert "final_top_k" in result.outputs
    assert len(result.outputs["final_top_k"]) == 3


def test_policy_guidelines_pipeline_with_mock(tmp_path):
    runner, agents, master = _make_runner(tmp_path)
    cfg = DelphiConfig(template="policy_guidelines", max_rounds=2, min_rounds=1, quorum_fraction=0.5, stage_deadline_s=30, retries=0)
    spec = StudyRunSpec(
        title="Test",
        topic="Guidelines",
        problem_statement="",
        statements_per_agent=3,
    )
    result = runner.run(spec=spec, config=cfg, agents=agents, master=master)
    assert result.template == "policy_guidelines"
    assert "stats" in result.outputs


def test_risk_register_pipeline_with_mock(tmp_path):
    runner, agents, master = _make_runner(tmp_path)
    cfg = DelphiConfig(template="risk_register", max_rounds=2, min_rounds=1, quorum_fraction=0.5, stage_deadline_s=30, retries=0)
    spec = StudyRunSpec(
        title="Test",
        topic="Risks",
        risks_per_agent=2,
    )
    result = runner.run(spec=spec, config=cfg, agents=agents, master=master)
    assert result.template == "risk_register"
    assert "risk_priority" in result.outputs


def test_instrument_development_pipeline_with_mock(tmp_path):
    runner, agents, master = _make_runner(tmp_path)
    cfg = DelphiConfig(template="instrument_development", max_rounds=2, min_rounds=1, quorum_fraction=0.5, stage_deadline_s=30, retries=0)
    spec = StudyRunSpec(
        title="Test",
        topic="Instrument",
        constructs=["Construct 1"],
        items_per_construct_per_agent=2,
    )
    result = runner.run(spec=spec, config=cfg, agents=agents, master=master)
    assert result.template == "instrument_development"
    assert "instrument" in result.outputs


def test_scenario_building_pipeline_with_mock(tmp_path):
    runner, agents, master = _make_runner(tmp_path)
    cfg = DelphiConfig(template="scenario_building", max_rounds=2, min_rounds=1, quorum_fraction=0.5, stage_deadline_s=30, retries=0)
    spec = StudyRunSpec(
        title="Test",
        topic="Scenarios",
        scenario_time_horizon="5 years",
        n_scenarios=3,
    )
    result = runner.run(spec=spec, config=cfg, agents=agents, master=master)
    assert result.template == "scenario_building"
    assert "scenarios" in result.outputs
